package dev.azure.client.gui.click.buttons;

import dev.azure.client.gui.click.Panel;
import dev.azure.client.gui.click.buttons.settings.*;
import dev.azure.client.gui.click.implement.Component;
import dev.azure.client.modules.Module;
import dev.azure.client.modules.client.ColorModule;
import dev.azure.client.gui.font.FontManager;
import dev.azure.client.settings.Setting;
import dev.azure.client.settings.implement.*;
import dev.azure.client.utilities.render.RenderUtils;

import java.awt.*;
import java.util.ArrayList;

public class ModuleButton extends Component {
    public Module module;
    public Panel panel;
    public int offset;
    private boolean isHovered;
    private final ArrayList<Component> components;
    public boolean open;

    public ModuleButton(final Module module, final Panel panel, final int offset) {
        this.module = module;
        this.panel = panel;
        this.offset = offset;
        this.components = new ArrayList<>();
        this.open = false;
        int tempY = offset + 16;

        if (this.module.getSettings() != null && !this.module.getSettings().isEmpty()) {
            for (final Setting setting : this.module.getSettings()) {
                if (setting instanceof BooleanSetting) {
                    components.add(new BooleanButton((BooleanSetting) setting, this, tempY));
                    tempY += 16;
                }

                if (setting instanceof ModeSetting) {
                    components.add(new ModeButton((ModeSetting) setting, this, tempY));
                    tempY += 16;
                }

                if (setting instanceof IntegerSetting) {
                    components.add(new IntegerButton((IntegerSetting) setting, this, tempY));
                    tempY += 16;
                }

                if (setting instanceof DoubleSetting) {
                    components.add(new DoubleButton((DoubleSetting) setting, this, tempY));
                    tempY += 16;
                }

                if (setting instanceof StringSetting) {
                    components.add(new StringButton((StringSetting) setting, this, tempY));
                    tempY += 16;
                }
            }
        }

        components.add(new BindButton(this, tempY));
    }

    public ArrayList<Component> getSubComponents() {
        return components;
    }

    @Override
    public void renderComponent() {
        RenderUtils.drawRect(panel.getX(), panel.getY() + offset + 1, panel.getX() + panel.getWidth(), panel.getY() + 14 + offset, new Color(0, 0, 0, 135).getRGB());
        RenderUtils.drawRect(panel.getX(), panel.getY() + offset, panel.getX() + panel.getWidth(), panel.getY() + offset + 1, new Color(0, 0, 0, 135).getRGB());
        RenderUtils.drawRect(panel.getX() + 86, panel.getY() + offset + 1, panel.getX() + panel.getWidth() - 2, panel.getY() + offset + 13, module.isEnabled() ? ColorModule.getColor().getRGB() : new Color(0, 0, 0, 135).getRGB());
        FontManager.drawString(module.getName(), panel.getX() + 3, panel.getY() + offset + 3, module.isEnabled() ? ColorModule.getColor().getRGB() : -1);

        if (open && !components.isEmpty()) {
            for (final Component component : components) {
                component.renderComponent();
            }
        }
    }

    @Override
    public void setOffset(final int offset) {
        this.offset = offset;
        int tempY = offset + 14;
        for (final Component component : components) {
            component.setOffset(tempY);
            tempY += 14;
        }
    }

    @Override
    public int getHeight() {
        if (open) {
            return 14 * (components.size() + 1);
        }

        return 14;
    }

    @Override
    public void updateComponent(final int mouseX, final int mouseY) {
        isHovered = isMouseOnButton(mouseX, mouseY);
        if (!components.isEmpty()) {
            for (final Component component : components) {
                component.updateComponent(mouseX, mouseY);
            }
        }
    }

    @Override
    public void mouseClicked(final int mouseX, final int mouseY, final int button) {
        if (isMouseOnButton(mouseX, mouseY) && button == 0) {
            module.toggle();
        }

        if (isMouseOnButton(mouseX, mouseY) && button == 1) {
            open = !open;
            panel.refresh();
        }

        for (final Component component : components) {
            component.mouseClicked(mouseX, mouseY, button);
        }
    }

    @Override
    public void mouseReleased(final int mouseX, final int mouseY, final int button) {
        for (final Component component : components) {
            component.mouseReleased(mouseX, mouseY, button);
        }
    }

    @Override
    public void keyTyped(final char typedChar, final int key) {
        for (final Component component : components) {
            component.keyTyped(typedChar, key);
        }
    }

    public boolean isMouseOnButton(final int x, final int y) {
        return x > panel.getX() && x < panel.getX() + panel.getWidth() && y > panel.getY() + offset && y < panel.getY() + 14 + offset;
    }
}
