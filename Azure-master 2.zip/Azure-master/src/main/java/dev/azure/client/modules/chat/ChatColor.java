package dev.azure.client.modules.chat;

import dev.azure.client.modules.Category;
import dev.azure.client.modules.Module;
import dev.azure.client.modules.ModuleManager;
import dev.azure.client.settings.implement.ModeSetting;

public class ChatColor extends Module {
    public ChatColor() {
        super("ChatColor", "Chat Color", "Automatically puts a color sign at the start of your message.", Category.CHAT);
        addSettings(mode, color, format);
    }

    public static ModeSetting mode = new ModeSetting("Mode", "Color", "Color", "Format");
    public static ModeSetting color = new ModeSetting("Color", "Aqua", "Dark Red", "Red", "Gold", "Green", "Aqua", "Blue", "Purple", "Gray");
    public static ModeSetting format = new ModeSetting("Format", "Italic", "Underline", "Strike", "Italic");

    public static String getColor() {
        if (ModuleManager.isModuleEnabled("ChatColor")) {
            if (mode.getValue().equals("Color")) {
                switch (color.getValue()) {
                    case "Dark Red": {
                        return "@ ";
                    }
                    case "Red": {
                        return "& ";
                    }
                    case "Gold": {
                        return "$ ";
                    }
                    case "Green": {
                        return "> ";
                    }
                    case "Aqua": {
                        return "^ ";
                    }
                    case "Blue": {
                        return "! ";
                    }
                    case "Purple": {
                        return "? ";
                }
                    case "Gray": {
                        return ". ";
                    }
                    default: {
                        return "";
                    }
                }
            } else if (mode.getValue().equalsIgnoreCase("Format")) {
                switch (format.getValue()) {
                    case "Underline": {
                        return "_ ";
                    }
                    case "Strike": {
                        return "~ ";
                    }
                    case "Italic": {
                        return "* ";
                    }
                    default: {
                        return "";
                    }
                }
            } else {
                return "";
            }
        } else {
            return "";
        }
    }
}
