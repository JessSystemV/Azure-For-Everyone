package dev.azure.client.modules.client;

import dev.azure.client.gui.font.FontRenderer;
import dev.azure.client.modules.Category;
import dev.azure.client.modules.Module;
import dev.azure.client.settings.implement.BooleanSetting;
import dev.azure.client.settings.implement.StringSetting;
import dev.azure.client.utilities.chat.ChatUtils;
import dev.azure.client.utilities.chat.CommandUtils;
import dev.azure.event.implement.SetValueEvent;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;

import java.awt.*;

public class FontModule extends Module {
    public FontModule() {
        super("Font", "Font", "Manages the client's font renderer.", Category.CLIENT);
        addSettings(fontName, antiAlias, fractionalMetrics, shadow);
    }

    public static StringSetting fontName = new StringSetting("Name", "Verdana");
    public static BooleanSetting antiAlias = new BooleanSetting("AntiAlias", true);
    public static BooleanSetting fractionalMetrics = new BooleanSetting("FractionalMetrics", true);
    public static BooleanSetting shadow = new BooleanSetting("Shadow", true);

    public static boolean isFontCorrect(final String name) {
        for (final String string : GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames()) {
            if (string.equals(name)) {
                return true;
            }
        }

        return false;
    }

    @SuppressWarnings("unused")
    @EventHandler
    private final Listener<SetValueEvent> valueListener = new Listener<>(event -> {
        if (event.getName().equals(fontName.getName())) {
            if (isFontCorrect(fontName.getValue())) {
                FontRenderer.clientFont.setFont(new Font(fontName.getValue(), Font.PLAIN, 18));
                ChatUtils.sendMessage("Set font to " + CommandUtils.getPartTwo() + "\"" + fontName.getValue() + "\"" + CommandUtils.getPartOne() + "!", true);
            } else {
                ChatUtils.sendMessage("That font doesn't exist.", true);
                fontName.resetValue();
            }
        }

        if (event.getName().equals(antiAlias.getName())) {
            FontRenderer.clientFont.setAntiAlias(antiAlias.getValue());
        }

        if (event.getName().equals(fractionalMetrics.getName())) {
            FontRenderer.clientFont.setFractionalMetrics(fractionalMetrics.getValue());
        }
    });
}
