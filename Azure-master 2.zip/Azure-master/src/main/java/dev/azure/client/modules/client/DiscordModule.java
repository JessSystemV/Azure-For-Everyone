package dev.azure.client.modules.client;

import dev.azure.client.DiscordPresence;
import dev.azure.client.modules.Category;
import dev.azure.client.modules.Module;
import dev.azure.client.settings.implement.BooleanSetting;
import dev.azure.client.settings.implement.StringSetting;

public class DiscordModule extends Module {
    public DiscordModule() {
        super("DiscordRPC", "Discord RPC", "Let's you have an awesome Azure Discord RPC.", Category.CLIENT);
        addSettings(status, server, customState, state);
    }

    public static BooleanSetting status = new BooleanSetting("Status", true);
    public static BooleanSetting server = new BooleanSetting("Server", false);
    public static BooleanSetting customState = new BooleanSetting("CustomState", false);
    public static StringSetting state = new StringSetting("State", "Azure Client is cool");

    public void onEnable() {
        DiscordPresence.start();
    }

    public void onDisable() {
        DiscordPresence.stop();
    }
}
