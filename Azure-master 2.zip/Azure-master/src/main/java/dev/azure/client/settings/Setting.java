package dev.azure.client.settings;

public abstract class Setting {
    public String name;
    public boolean visible;

    public Setting(String name, boolean visible) {
        this.name = name;
        this.visible = visible;
    }

    public String getName() {
        return name;
    }

    public boolean isVisible() {
        return visible;
    }

    public void setVisible(boolean visible) {
        this.visible = visible;
    }
}
