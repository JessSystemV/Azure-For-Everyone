package dev.azure.client.settings.implement;

import dev.azure.client.modules.Module;
import dev.azure.client.settings.Setting;

public class DoubleSetting extends Setting {
    private double value;
    private final double minimum;
    private final double maximum;

    public DoubleSetting(String name, final double value, final double minimum, final double maximum) {
        super(name, true);
        this.value = value;
        this.minimum = minimum;
        this.maximum = maximum;
    }

    public DoubleSetting(String name, final double value, final double minimum, final double maximum, boolean visible) {
        super(name, visible);
        this.value = value;
        this.minimum = minimum;
        this.maximum = maximum;
    }

    public double getValue() {
        return value;
    }

    public void setValue(final double value) {
        this.value = Math.max(minimum, Math.min(maximum, value));
    }

    public double getMinimum() {
        return minimum;
    }

    public double getMaximum() {
        return maximum;
    }
}
