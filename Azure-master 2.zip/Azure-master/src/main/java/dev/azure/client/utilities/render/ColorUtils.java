package dev.azure.client.utilities.render;

import dev.azure.client.utilities.Utility;

import java.awt.*;

public class ColorUtils implements Utility {
    public static int getRainbow(float delay, float saturation, float brightness) {
        float hue = (System.currentTimeMillis() % (int) (delay * 1000)) / (delay * 1000);
        return Color.HSBtoRGB(hue, saturation, brightness);
    }
}