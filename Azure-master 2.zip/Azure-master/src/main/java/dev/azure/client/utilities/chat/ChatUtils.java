package dev.azure.client.utilities.chat;

import com.mojang.realmsclient.gui.ChatFormatting;
import dev.azure.client.modules.client.CommandModule;
import dev.azure.client.utilities.Utility;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.Style;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.event.HoverEvent;

public class ChatUtils implements Utility {
    public static void sendMessage(final String message, final boolean watermark) {
        if (mc.player == null || mc.world == null) return;
        final ITextComponent component = new TextComponentString((watermark ? CommandUtils.getColor(CommandModule.symbolColor.getValue(), CommandModule.symbolLight.getValue()) + CommandModule.symbolOne.getValue() + CommandUtils.getColor(CommandModule.watermarkColor.getValue(), CommandModule.watermarkLight.getValue()) + "Azure" + CommandUtils.getColor(CommandModule.symbolColor.getValue(), CommandModule.symbolLight.getValue()) + CommandModule.symbolTwo.getValue() + " " + CommandUtils.getColor(CommandModule.partOneColor.getValue(), CommandModule.partOneLight.getValue()) + message : CommandUtils.getColor(CommandModule.partOneColor.getValue(), CommandModule.partOneLight.getValue()) + message)).setStyle(new Style().setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new TextComponentString(CommandUtils.getColor(CommandModule.watermarkColor.getValue(), CommandModule.watermarkLight.getValue()) + "Azure Chat Manager"))));
        mc.ingameGUI.getChatGUI().printChatMessageWithOptionalDeletion(component, 256);
    }

    public static void sendMessage(final String message, final boolean watermark, final int id) {
        if (mc.player == null || mc.world == null) return;
        try {
            final ITextComponent component = new TextComponentString((watermark ? CommandUtils.getColor(CommandModule.symbolColor.getValue(), CommandModule.symbolLight.getValue()) + CommandModule.symbolOne.getValue() + CommandUtils.getColor(CommandModule.watermarkColor.getValue(), CommandModule.watermarkLight.getValue()) + "Azure" + CommandUtils.getColor(CommandModule.symbolColor.getValue(), CommandModule.symbolLight.getValue()) + CommandModule.symbolTwo.getValue() + " " + CommandUtils.getColor(CommandModule.partOneColor.getValue(), CommandModule.partOneLight.getValue()) + message : CommandUtils.getColor(CommandModule.partOneColor.getValue(), CommandModule.partOneLight.getValue()) + message)).setStyle(new Style().setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new TextComponentString(CommandUtils.getColor(CommandModule.watermarkColor.getValue(), CommandModule.watermarkLight.getValue()) + "Azure Chat Manager"))));
            mc.ingameGUI.getChatGUI().printChatMessageWithOptionalDeletion(component, id);
        } catch (NullPointerException exception) {
            exception.printStackTrace();
        }
    }

    public static void sendNormalMessage(final String message, final boolean watermark) {
        if (mc.player == null || mc.world == null) return;
        final ITextComponent component = new TextComponentString((watermark ? CommandUtils.getColor(CommandModule.symbolColor.getValue(), CommandModule.symbolLight.getValue()) + CommandModule.symbolOne.getValue() + CommandUtils.getColor(CommandModule.watermarkColor.getValue(), CommandModule.watermarkLight.getValue()) + "Azure" + CommandUtils.getColor(CommandModule.symbolColor.getValue(), CommandModule.symbolLight.getValue()) + CommandModule.symbolTwo.getValue() + " " + CommandUtils.getColor(CommandModule.partOneColor.getValue(), CommandModule.partOneLight.getValue()) + message : CommandUtils.getColor(CommandModule.partOneColor.getValue(), CommandModule.partOneLight.getValue()) + message)).setStyle(new Style().setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new TextComponentString(CommandUtils.getColor(CommandModule.watermarkColor.getValue(), CommandModule.watermarkLight.getValue()) + "Azure Chat Manager"))));
        mc.ingameGUI.getChatGUI().printChatMessage(component);
    }

    public static void sendRawMessage(String message) {
        if (mc.player == null || mc.world == null) return;
        final ITextComponent component = new TextComponentString(message);
        mc.ingameGUI.getChatGUI().printChatMessage(component);
    }
}
