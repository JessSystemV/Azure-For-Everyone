package dev.azure.client.modules.combat;

import dev.azure.client.gui.font.FontManager;
import dev.azure.client.modules.Category;
import dev.azure.client.modules.Module;
import dev.azure.client.settings.implement.BooleanSetting;
import dev.azure.client.settings.implement.DoubleSetting;
import dev.azure.client.settings.implement.IntegerSetting;
import dev.azure.client.settings.implement.ModeSetting;
import dev.azure.client.social.SocialManager;
import dev.azure.client.utilities.entity.EntityUtils;
import dev.azure.client.utilities.entity.InventoryUtils;
import dev.azure.client.utilities.entity.RotationUtils;
import dev.azure.client.utilities.math.MathUtils;
import dev.azure.event.implement.MotionEvent;
import dev.azure.event.status.Stage;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.inventory.ClickType;
import net.minecraft.item.ItemAppleGold;
import net.minecraft.network.play.client.CPacketAnimation;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.util.EnumHand;

import java.util.Date;

public class Aura extends Module {
    public Aura() {
        super("Aura", "Aura", "Automatically hits your enemies.", Category.COMBAT);
        addSettings(delay, randomDelay, iterations, ticksExisted, timing, rotation, weaponOnly, autoSwitch, switchDelay, range, throughWalls, wallsRange, bypass, bypassDelay, silentSwing, silentText, fakeItem, packetHit, logoutDisable, deathDisable, players, animals, mobs, invisibles, vehicles, projectiles);
    }

    private float yaw;
    private float pitch;
    private boolean isRotating;

    public static Entity target = null;
    public static boolean isAttacking = false;

    long killLast = new Date().getTime();
    long swapOneLast = new Date().getTime();
    long swapTwoLast = new Date().getTime();
    long swapThreeLast = new Date().getTime();

    IntegerSetting delay = new IntegerSetting("Delay", 4, 0, 40);
    IntegerSetting randomDelay = new IntegerSetting("RandomDelay", 0, 0, 40);
    IntegerSetting iterations = new IntegerSetting("Iterations", 1, 1, 10);
    IntegerSetting ticksExisted = new IntegerSetting("TicksExisted", 20, 0, 150);
    ModeSetting timing = new ModeSetting("Timing", "Attack", "Attack", "Swing");

    BooleanSetting rotation = new BooleanSetting("Rotation", true);

    BooleanSetting weaponOnly = new BooleanSetting("WeaponOnly", false);
    BooleanSetting autoSwitch = new BooleanSetting("AutoSwitch", false);
    IntegerSetting switchDelay = new IntegerSetting("SwitchDelay", 0, 0, 20);

    DoubleSetting range = new DoubleSetting("Range", 5.0, 0.1, 6.0);
    BooleanSetting throughWalls = new BooleanSetting("ThroughWalls", true);
    DoubleSetting wallsRange = new DoubleSetting("WallsRange", 3.5, 0.1, 6.0);

    BooleanSetting bypass = new BooleanSetting("Bypass", false);
    IntegerSetting bypassDelay = new IntegerSetting("BypassDelay", 20, 0, 50);

    BooleanSetting silentSwing = new BooleanSetting("SilentSwing", false);
    BooleanSetting silentText = new BooleanSetting("SilentText", false);
    public static BooleanSetting fakeItem = new BooleanSetting("FakeItem", false);
    BooleanSetting packetHit = new BooleanSetting("PacketHit", true);

    BooleanSetting logoutDisable = new BooleanSetting("LogoutDisable", true);
    BooleanSetting deathDisable = new BooleanSetting("DeathDisable", true);

    BooleanSetting players = new BooleanSetting("Players", true);
    BooleanSetting animals = new BooleanSetting("Animals", false);
    BooleanSetting mobs = new BooleanSetting("Mobs", true);
    BooleanSetting invisibles = new BooleanSetting("Invisibles", false);
    BooleanSetting vehicles = new BooleanSetting("Vehicles", false);
    BooleanSetting projectiles = new BooleanSetting("Projectiles", false);

    @SuppressWarnings("unused")
    @EventHandler
    private final Listener<MotionEvent> onMotion = new Listener<>(event -> {
        if (event.getStage() == Stage.PRE && rotation.getValue()) {
            if (isRotating) RotationUtils.setPlayerRotations(yaw, pitch);
            doKillAura();
        }
    });

    public void onTick() {
        target = getTarget();

        if (isAttacking && fakeItem.getValue()) {
            int slot = InventoryUtils.findItem(Items.DIAMOND_SWORD, 0, 36);
            if (slot != -1) {
                mc.entityRenderer.itemRenderer.itemStackMainHand = mc.player.inventory.getStackInSlot(slot);
            }
        }

        if (target == null && isAttacking) {
            isAttacking = false;
            mc.entityRenderer.itemRenderer.itemStackMainHand = mc.player.getHeldItemMainhand();
        }

        if (!rotation.getValue()) {
            doKillAura();
        }
    }

    public void onRender() {
        ScaledResolution resolution = new ScaledResolution(mc);

        if (isAttacking && silentSwing.getValue() && silentText.getValue()) {
            FontManager.drawCenteredString("Silent Attacking", resolution.getScaledWidth() / 2.0f, resolution.getScaledHeight() / 2.0f + 10, -1);
        }
    }

    public void doKillAura() {
        if (mc.player == null || mc.world == null || mc.player.isDead || mc.player.getHealth() <= 0) return;
        if (target == null) return;

        isAttacking = true;

        int fishingSlot = InventoryUtils.findItem(Items.FISHING_ROD, 0, 36);
        int swordSlot = InventoryUtils.findItem(Items.DIAMOND_SWORD, 0, 36);

        if (bypass.getValue() && !AutoTotem.shouldPrepare) {
            if (new Date().getTime() >= swapOneLast + (bypassDelay.getValue() * 10L)) {
                swapOneLast = new Date().getTime();
                itemSwitch(36);
            }
            if (new Date().getTime() >= swapTwoLast + (bypassDelay.getValue() * 10L)) {
                swapTwoLast = new Date().getTime();
                itemSwitch(37);
            }
            if (new Date().getTime() >= swapThreeLast + (bypassDelay.getValue() * 10L)) {
                swapThreeLast = new Date().getTime();
                itemSwitch(36);
            }
        }

        int delay = (int) (((this.delay.getValue() * 10) + ((randomDelay.getValue() * 10) * Math.random())));

        if (new Date().getTime() >= killLast + delay && !AutoTotem.shouldPrepare) {
            killLast = new Date().getTime();
            setYawPitch(target);
            for (int i = 0; i < iterations.getValue(); i++) {
                switch (timing.getValue()) {
                    case "Attack": {
                        attack(target);
                        swingItem();
                        break;
                    }

                    case "Swing": {
                        swingItem();
                        attack(target);
                        break;
                    }
                }
            }
        }
    }

    public void attack(Entity entity) {
        if (packetHit.getValue()) {
            mc.player.connection.sendPacket(new CPacketUseEntity(entity));
        } else {
            mc.playerController.attackEntity(mc.player, entity);
        }
    }

    public void swingItem() {
        if (silentSwing.getValue()) {
            mc.player.connection.sendPacket(new CPacketAnimation(EnumHand.MAIN_HAND));
        } else {
            mc.player.swingArm(EnumHand.MAIN_HAND);
        }
    }

    private void setYawPitch(Entity entity) {
        float[] angle = MathUtils.angle(mc.player.getPositionEyes(mc.getRenderPartialTicks()), entity.getPositionEyes(mc.getRenderPartialTicks()));
        this.yaw = angle[0];
        this.pitch = angle[1];
        this.isRotating = true;
    }

    public void itemSwitch(int slot) {
        mc.playerController.windowClick(mc.player.inventoryContainer.windowId, slot, 0, ClickType.SWAP, mc.player);
    }

    public Entity getTarget() {
        if (mc.player == null || mc.world == null || mc.player.isDead || mc.player.getHealth() <= 0) return null;
        for (Entity entity : mc.world.loadedEntityList) {
            if (!isEntityValid(entity)) continue;
            return entity;
        }
        return null;
    }

    public boolean isEntityValid(Entity entity) {
        if (!EntityUtils.isAlive(entity)) return false;
        if (entity == mc.player && entity.getName().equals(mc.player.getName())) return false;
        if (((EntityLivingBase) entity).getHealth() <= 0.0f) return false;
        if (SocialManager.isFriend(entity.getName())) return false;
        if (!projectiles.getValue() && EntityUtils.isProjectile(entity)) return false;
        if (!vehicles.getValue() && EntityUtils.isVehicle(entity)) return false;
        if (!mobs.getValue() && EntityUtils.isMobAggressive(entity)) return false;
        if (!animals.getValue() && EntityUtils.isPassive(entity)) return false;
        if (!invisibles.getValue() && entity.isInvisible()) return false;
        if (!players.getValue() && entity instanceof EntityPlayer && entity.ticksExisted < ticksExisted.getValue())
            return false;
        if (!(mc.player.getDistance(entity) <= range.getValue())) return false;
        return mc.player.canEntityBeSeen(entity) || !throughWalls.getValue() || mc.player.getDistance(entity) <= wallsRange.getValue();
    }

    public void onEnable() {
        isAttacking = false;
        isRotating = false;
        target = null;
    }

    public void onDisable() {
        isAttacking = false;
        isRotating = false;
        target = null;
    }

    public void onLogout() {
        if (logoutDisable.getValue()) {
            this.disable();
        }
    }
}
