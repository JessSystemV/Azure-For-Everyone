package dev.azure.client.modules.player;

import dev.azure.client.modules.Category;
import dev.azure.client.modules.Module;
import dev.azure.event.implement.PacketEvent;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.network.play.client.CPacketKeepAlive;

public class PingSpoof extends Module {
    public PingSpoof() {
        super("PingSpoof", "Ping Spoof", "Spoofs your ping.", Category.PLAYER);
        addSettings();
    }

    @SuppressWarnings("unused")
    @EventHandler
    private final Listener<PacketEvent.Send> sendListener = new Listener<>(event -> {
        if (event.isPre()) {
            if (event.getPacket() instanceof CPacketKeepAlive) {
                event.setCancelled(true);
            }
        }
    });
}
