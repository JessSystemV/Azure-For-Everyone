package dev.azure.client.modules.render;

import dev.azure.client.modules.Category;
import dev.azure.client.modules.Module;
import dev.azure.client.modules.ModuleManager;
import dev.azure.client.modules.combat.Aura;
import dev.azure.client.settings.implement.BooleanSetting;

public class Animations extends Module {
    public Animations() {
        super("Animations", "Animations", "Makes your items not be able to move below the screen.", Category.RENDER);
        addSettings(items);
    }

    BooleanSetting items = new BooleanSetting("Items", true);

    public void onTick() {
        if (items.getValue() && mc.entityRenderer.itemRenderer.equippedProgressMainHand != 1.0f) {
            mc.entityRenderer.itemRenderer.equippedProgressMainHand = 1.0f;
            if (!ModuleManager.isModuleEnabled("Aura") || (ModuleManager.isModuleEnabled("Aura") && !Aura.fakeItem.getValue() || !Aura.isAttacking)) {
                mc.entityRenderer.itemRenderer.itemStackMainHand = mc.player.getHeldItemMainhand();
            }
        }

        if (items.getValue() && mc.entityRenderer.itemRenderer.equippedProgressOffHand != 1.0f) {
            mc.entityRenderer.itemRenderer.equippedProgressOffHand = 1.0f;
            mc.entityRenderer.itemRenderer.itemStackOffHand = mc.player.getHeldItemOffhand();
        }
    }
}
