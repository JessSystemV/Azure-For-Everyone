package dev.azure.client.modules.combat;

import dev.azure.client.modules.Category;
import dev.azure.client.modules.Module;
import dev.azure.client.settings.implement.IntegerSetting;
import dev.azure.client.utilities.entity.InventoryUtils;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.init.Items;
import net.minecraft.inventory.ClickType;
import net.minecraft.item.ItemStack;

import java.util.Date;

public class AutoTotem extends Module {
    public AutoTotem() {
        super("AutoTotem", "Auto Totem", "Automatically swaps your offhand with a new totem stack.", Category.COMBAT);
        addSettings(delay, switchCount, prepareCount, minimumCount);
    }

    public static boolean shouldPrepare = false;
    long selectLast = new Date().getTime();
    long swapLast = new Date().getTime();
    long replaceLast = new Date().getTime();

    IntegerSetting delay = new IntegerSetting("Delay", 1, 0, 20);
    IntegerSetting switchCount = new IntegerSetting("SwitchCount", 5, 0, 64);
    IntegerSetting prepareCount = new IntegerSetting("PrepareCount", 3, 0, 6);
    IntegerSetting minimumCount = new IntegerSetting("MinCount", 24, 1, 64);

    public void onTick() {
        if (mc.player.getHeldItemOffhand().getCount() <= switchCount.getValue() + prepareCount.getValue()) {
            shouldPrepare = true;
        }

        if (mc.player.getHeldItemOffhand().getCount() > switchCount.getValue() + prepareCount.getValue()) {
            shouldPrepare = false;
        }

        if ((mc.player.getHeldItemOffhand().getItem() == Items.TOTEM_OF_UNDYING && mc.player.getHeldItemOffhand().getCount() <= switchCount.getValue()) || mc.player.getHeldItemOffhand().isEmpty()) {
            final int slot = InventoryUtils.findWindowItem(Items.TOTEM_OF_UNDYING, minimumCount.getValue(), 9, 44);

            if (slot == -1) return;
            if (mc.currentScreen instanceof GuiContainer) mc.player.closeScreen();

            if (mc.player.inventoryContainer.getSlot(slot).getStack().getItem() != Items.TOTEM_OF_UNDYING) return;
            if (mc.player.inventoryContainer.getSlot(slot).getStack().getCount() <= minimumCount.getValue()) return;

            if (new Date().getTime() >= selectLast + delay.getValue()) {
                selectLast = new Date().getTime();
                mc.playerController.windowClick(mc.player.inventoryContainer.windowId, 45, 8, ClickType.SWAP, mc.player);
            }

            if (new Date().getTime() >= swapLast + 300) {
                swapLast = new Date().getTime();
                mc.playerController.windowClick(mc.player.inventoryContainer.windowId, slot, 8, ClickType.SWAP, mc.player);
            }

            if (new Date().getTime() >= replaceLast + 100) {
                replaceLast = new Date().getTime();
                mc.playerController.windowClick(mc.player.inventoryContainer.windowId, 45, 8, ClickType.SWAP, mc.player);
            }

            shouldPrepare = false;
        }
    }
}
