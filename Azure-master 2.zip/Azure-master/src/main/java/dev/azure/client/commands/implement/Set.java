package dev.azure.client.commands.implement;

import com.mojang.realmsclient.gui.ChatFormatting;
import dev.azure.client.commands.Command;
import dev.azure.client.modules.Module;
import dev.azure.client.modules.ModuleManager;
import dev.azure.client.settings.Setting;
import dev.azure.client.settings.implement.*;
import dev.azure.client.utilities.chat.ChatUtils;
import dev.azure.client.utilities.chat.CommandUtils;

public class Set extends Command {
    public Set() {
        super("Set", "Sets a setting's value using commands.", "set <module> <setting> <value>", "setting", "s");
    }

    @Override
    public void onCommand(String[] args, String command) {
        if (args.length == 3) {
            for (Module module : ModuleManager.getModules()) {
                if (module.getName().equalsIgnoreCase(args[0])) {
                    for (Setting setting : module.getSettings()) {
                        if (!setting.getName().equalsIgnoreCase(args[1])) continue;

                        if (setting instanceof BooleanSetting) {
                            ((BooleanSetting) setting).setValue(Boolean.parseBoolean(args[2]));
                            ChatUtils.sendMessage(CommandUtils.getPartTwo() + setting.getName() + CommandUtils.getPartOne() + " has been set to " + CommandUtils.getPartTwo() + ((BooleanSetting) setting).getValue() + CommandUtils.getPartOne() + "!", true);
                        }

                        if (setting instanceof IntegerSetting) {
                            ((IntegerSetting) setting).setValue(Integer.parseInt(args[2]));
                            ChatUtils.sendMessage(CommandUtils.getPartTwo() + setting.getName() + CommandUtils.getPartOne() + " has been set to " + CommandUtils.getPartTwo() + ((IntegerSetting) setting).getValue() + CommandUtils.getPartOne() + "!", true);
                        }

                        if (setting instanceof DoubleSetting) {
                            ((DoubleSetting) setting).setValue(Double.parseDouble(args[2]));
                            ChatUtils.sendMessage(CommandUtils.getPartTwo() + setting.getName() + CommandUtils.getPartOne() + " has been set to " + CommandUtils.getPartTwo() + ((DoubleSetting) setting).getValue() + ChatFormatting.RESET + CommandUtils.getPartOne() + "!", true);
                        }

                        if (setting instanceof ModeSetting) {
                            if (!((ModeSetting) setting).getModes().contains(args[2])) {
                                ChatUtils.sendMessage("Invalid input.", true);
                            } else {
                                ((ModeSetting) setting).setValue(args[2]);
                                ChatUtils.sendMessage(CommandUtils.getPartTwo() + setting.getName() + CommandUtils.getPartOne() + " has been set to " + CommandUtils.getPartTwo() + ((ModeSetting) setting).getValue() + ChatFormatting.RESET + CommandUtils.getPartOne() + "!", true);
                            }
                        }

                        if (setting instanceof StringSetting) {
                            if (args[2].length() <= 0) {
                                ChatUtils.sendMessage("Invalid input.", true);
                            } else {
                                ((StringSetting) setting).setValue(args[2].replace("_", " "));
                                ChatUtils.sendMessage(CommandUtils.getPartTwo() + setting.getName() + CommandUtils.getPartOne() + " has been set to " + CommandUtils.getPartTwo() + ((StringSetting) setting).getValue() + ChatFormatting.RESET + CommandUtils.getPartOne() + "!", true);
                            }
                        }
                    }
                }
            }
        } else {
            ChatUtils.sendMessage(getSyntax(), true);
        }
    }
}
