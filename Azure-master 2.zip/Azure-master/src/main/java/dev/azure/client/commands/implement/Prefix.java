package dev.azure.client.commands.implement;

import dev.azure.client.commands.Command;
import dev.azure.client.commands.CommandManager;
import dev.azure.client.utilities.chat.ChatUtils;
import dev.azure.client.utilities.chat.CommandUtils;

public class Prefix extends Command {
    public Prefix() {
        super("Prefix", "Sets your command prefix.", "prefix <prefix>", "commandprefix", "cmdprefix", "commandp", "cmdp");
    }

    @Override
    public void onCommand(String[] args, String command) {
        if (args.length == 1) {
            if (args[0].length() > 1) {
                ChatUtils.sendMessage("The prefix must not be longer than 1 character.", true);
            } else {
                CommandManager.setPrefix(args[0]);
                ChatUtils.sendMessage("Prefix set to \"" + CommandUtils.getPartTwo() + CommandManager.getPrefix() + CommandUtils.getPartOne() + "\"!", true);
            }
        }
    }
}
