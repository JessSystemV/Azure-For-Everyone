package dev.azure.client.commands.implement;

import dev.azure.client.commands.Command;
import dev.azure.client.manager.TotemManager;
import dev.azure.client.utilities.chat.ChatUtils;
import net.minecraft.entity.player.EntityPlayer;

public class Totems extends Command {
    public Totems() {
        super("Totems", "Let's you reset someone's totem pops or the whole list.", "totems clear | reset <name>", "totem", "tot", "pops", "pop");
    }

    @Override
    public void onCommand(String[] args, String command) {
        if (args.length == 1) {
            if (args[0].equalsIgnoreCase("clear")) {
                TotemManager.clearList();
                ChatUtils.sendMessage("Successfully cleared all totem pops.", true);
            } else {
                ChatUtils.sendMessage(getSyntax(), true);
            }
        } else if (args.length == 2) {
            if (args[0].equalsIgnoreCase("reset")) {
                for (EntityPlayer player : TotemManager.getPopList().keySet()) {
                    if (!player.getName().equalsIgnoreCase(args[1])) continue;
                    if (TotemManager.getTotemPops(player) <= 0) continue;

                    TotemManager.resetPops(player);
                }
            } else {
                ChatUtils.sendMessage(getSyntax(), true);
            }
        }
    }
}
