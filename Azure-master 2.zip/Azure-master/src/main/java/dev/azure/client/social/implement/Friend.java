package dev.azure.client.social.implement;

public class Friend {
    public String name;

    public Friend(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
