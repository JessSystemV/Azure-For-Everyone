package dev.azure.client.gui.click.buttons.settings;

import dev.azure.client.gui.click.buttons.ModuleButton;
import dev.azure.client.gui.click.implement.Component;
import dev.azure.client.gui.font.FontManager;
import dev.azure.client.modules.client.ColorModule;
import dev.azure.client.settings.implement.DoubleSetting;
import dev.azure.client.settings.implement.IntegerSetting;
import dev.azure.client.utilities.render.RenderUtils;

import java.awt.*;
import java.math.BigDecimal;
import java.math.RoundingMode;

public class DoubleButton extends Component {
    private boolean hovered;
    private final DoubleSetting setting;
    private final ModuleButton parent;
    private double renderWidth;
    private boolean dragging;
    private int offset;
    private int x;
    private int y;

    public DoubleButton(final DoubleSetting setting, final ModuleButton parent, final int offset) {
        this.setting = setting;
        this.parent = parent;
        this.x = parent.panel.getX();
        this.y = parent.panel.getY() + parent.offset;
        this.offset = offset;
        this.dragging = false;
    }

    @Override
    public void renderComponent() {
        RenderUtils.drawRect(getParentX(), getParentY() + offset + 1, getParentX() + getParentWidth(), getParentY() + 14 + offset, new Color(0, 0, 0, 135).getRGB());
        RenderUtils.drawRect(getParentX(), getParentY() + offset, getParentX() + getParentWidth(), getParentY() + 1 + offset, new Color(0, 0, 0, 135).getRGB());
        RenderUtils.drawRect(getParentX() + 2, getParentY() + offset + 1, getParentX() + getParentWidth() - 2, getParentY() + 13 + offset, ColorModule.getColor(35).getRGB());
        RenderUtils.drawRect(getParentX() + 2, getParentY() + offset + 1, getParentX() + (int) renderWidth, getParentY() + 13 + offset, ColorModule.getColor(100).getRGB());
        FontManager.drawString(setting.getName() + ": " + setting.getValue(), getParentX() + 4, getParentY() + offset + 3, -1);
    }

    @Override
    public void setOffset(final int offset) {
        this.offset = offset;
    }

    @Override
    public void updateComponent(final int mouseX, final int mouseY) {
        hovered = isMouseOnButtonD(mouseX, mouseY) || isMouseOnButtonI(mouseX, mouseY);
        x = parent.panel.getX();
        y = parent.panel.getY() + offset;
        final double diff = Math.min(100, Math.max(0, mouseX - x));
        final double max = setting.getMaximum();
        final double min = setting.getMinimum();
        renderWidth = 88.0f * (setting.getValue() - min) / (max - min);
        if (dragging) {
            if (diff == 0.0) {
                setting.setValue(setting.getMinimum());
            } else {
                final double newValue = roundToPlace(diff / 100.0 * (max - min) + min);
                setting.setValue(newValue);
            }
        }
    }

    private static double roundToPlace(final double value) {
        BigDecimal bd = new BigDecimal(value);
        bd = bd.setScale(2, RoundingMode.HALF_UP);
        return bd.doubleValue();
    }

    @Override
    public void mouseClicked(final int mouseX, final int mouseY, final int button) {
        if (this.isMouseOnButtonD(mouseX, mouseY) && button == 0 && this.parent.open) {
            this.dragging = true;
        }
        if (this.isMouseOnButtonI(mouseX, mouseY) && button == 0 && this.parent.open) {
            this.dragging = true;
        }
    }

    @Override
    public void mouseReleased(final int mouseX, final int mouseY, final int mouseButton) {
        this.dragging = false;
    }

    public boolean isMouseOnButtonD(final int x, final int y) {
        return x > this.x && x < this.x + (getParentWidth() / 2 + 1) && y > this.y && y < this.y + 14;
    }

    public boolean isMouseOnButtonI(final int x, final int y) {
        return x > this.x + getParentWidth() / 2 && x < this.x + getParentWidth() && y > this.y && y < this.y + 14;
    }

    public int getParentX() {
        return parent.panel.getX();
    }

    public int getParentY() {
        return parent.panel.getY();
    }

    public int getParentWidth() {
        return parent.panel.getWidth();
    }
}
