package dev.azure.client.settings.implement;

import dev.azure.client.Azure;
import dev.azure.client.settings.Setting;
import dev.azure.event.implement.SetValueEvent;

public class StringSetting extends Setting {
    private String value;
    private String previousValue = "PLACEHOLDER";

    public StringSetting(String name, String value) {
        super(name, true);
        this.value = value;
    }

    public StringSetting(String name, String value, boolean visible) {
        super(name, visible);
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.previousValue = this.value;
        this.value = value;
        Azure.EVENT_BUS.post(new SetValueEvent(this.getName()));
    }

    public void resetValue() {
        value = previousValue;
    }
}
