package dev.azure.client.modules.player;

import dev.azure.client.modules.Category;
import dev.azure.client.modules.Module;
import dev.azure.client.settings.implement.BooleanSetting;
import dev.azure.event.implement.PacketEvent;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.entity.Entity;
import net.minecraft.entity.monster.EntitySlime;
import net.minecraft.init.SoundEvents;
import net.minecraft.network.play.server.SPacketSoundEffect;

public class AntiCrash extends Module {
    public AntiCrash() {
        super("AntiCrash", "Anti Crash", "Prevents some very simple crashes from crashing your game.", Category.PLAYER);
        addSettings(slimes, offhand);
    }

    BooleanSetting slimes = new BooleanSetting("Slime", true);
    BooleanSetting offhand = new BooleanSetting("Offhand", true);

    public void onTick() {
        if (mc.world != null && slimes.getValue()) {
            for (Entity entity : mc.world.loadedEntityList) {
                if (entity instanceof EntitySlime) {
                    EntitySlime slime = (EntitySlime) entity;
                    if (slime.getSlimeSize() > 4) {
                        mc.world.removeEntity(entity);
                    }
                }
            }
        }
    }

    @SuppressWarnings("unused")
    @EventHandler
    private final Listener<PacketEvent.Receive> receiveListener = new Listener<>(event -> {
        if (event.isPre()) {
            if (offhand.getValue()) {
                if (event.getPacket() instanceof SPacketSoundEffect) {
                    if (((SPacketSoundEffect) event.getPacket()).getSound() == SoundEvents.ITEM_ARMOR_EQUIP_GENERIC) {
                        event.setCancelled(true);
                    }
                }
            }
        }
    });
}
