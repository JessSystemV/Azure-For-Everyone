package dev.azure.client.modules.player;

import dev.azure.client.modules.Category;
import dev.azure.client.modules.Module;
import dev.azure.client.settings.implement.BooleanSetting;
import dev.azure.client.settings.implement.DoubleSetting;
import dev.azure.client.settings.implement.ModeSetting;
import dev.azure.event.implement.BlockEvent;
import dev.azure.event.status.Stage;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;

public class SpeedMine extends Module {
    public SpeedMine() {
        super("SpeedMine", "Speed Mine", "Makes you mine faster.", Category.PLAYER);
        addSettings(mode, amount, reset);
    }

    private IBlockState currentBlockState = null;
    private BlockPos currentPos = null;

    ModeSetting mode = new ModeSetting("Mode", "Damage", "Packet", "Instant", "Damage");
    DoubleSetting amount = new DoubleSetting("Amount", 0.7, 0, 1);
    BooleanSetting reset = new BooleanSetting("Reset", true);

    public void onTick() {
        if (currentPos != null && (!mc.world.getBlockState(currentPos).equals(currentBlockState) || mc.world.getBlockState(currentPos).getBlock() == Blocks.AIR)) {
            currentPos = null;
            currentBlockState = null;
        }

        if (reset.getValue() && mc.gameSettings.keyBindUseItem.isKeyDown()) {
            mc.playerController.isHittingBlock = false;
        }
    }

    @SuppressWarnings("unused")
    @EventHandler
    private final Listener<BlockEvent> blockEventListener = new Listener<>(event -> {
        if (event.getStage() == Stage.PRE && reset.getValue() && mc.playerController.curBlockDamageMP > 0.1f) {
            mc.playerController.isHittingBlock = true;
        }

        if (event.getStage() == Stage.POST) {
            if (canBreak(event.pos)) {
                if (reset.getValue()) {
                    mc.playerController.isHittingBlock = false;
                }

                if (mode.getValue().equalsIgnoreCase("Packet")) {
                    if (currentPos == null) {
                        currentPos = event.pos;
                        currentBlockState = mc.world.getBlockState(currentPos);
                    }
                    mc.player.swingArm(EnumHand.MAIN_HAND);
                    mc.player.connection.sendPacket(new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, event.pos, event.facing));
                    mc.player.connection.sendPacket(new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, event.pos, event.facing));
                    event.setCancelled(true);
                }

                if (mode.getValue().equalsIgnoreCase("Damage")) {
                    if (mc.playerController.curBlockDamageMP >= amount.getValue()) {
                        mc.playerController.curBlockDamageMP = 1.0f;
                    }
                }

                if (mode.getValue().equalsIgnoreCase("Instant")) {
                    mc.player.swingArm(EnumHand.MAIN_HAND);
                    mc.player.connection.sendPacket(new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, event.pos, event.facing));
                    mc.player.connection.sendPacket(new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, event.pos, event.facing));
                    mc.playerController.onPlayerDestroyBlock(event.pos);
                    mc.world.setBlockToAir(event.pos);
                }
            }
        }
    });

    public static boolean canBreak(final BlockPos pos) {
        final IBlockState blockState = mc.world.getBlockState(pos);
        final Block block = blockState.getBlock();
        return block.getBlockHardness(blockState, mc.world, pos) != -1.0f;
    }
}
