package dev.azure.client.modules.hud;

import dev.azure.client.gui.font.FontManager;
import dev.azure.client.modules.Category;
import dev.azure.client.modules.Module;
import dev.azure.client.modules.ModuleManager;
import dev.azure.client.modules.client.ColorModule;
import dev.azure.client.settings.implement.ModeSetting;
import dev.azure.client.settings.implement.StringSetting;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.opengl.GL11;

import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Month;
import java.time.Year;
import java.time.temporal.TemporalAdjusters;
import java.util.Calendar;
import java.util.Date;

public class Welcomer extends Module {
    public Welcomer() {
        super("Welcomer", "Welcomer", "Puts a nice little message on your screen that greets you.", Category.HUD);
        addSettings(mode, message, extra, position);
    }

    public static ModeSetting mode = new ModeSetting("Mode", "Shorter", "Shorter", "Short", "Holiday", "Time", "Hebrew", "Long", "Custom");
    public static StringSetting message = new StringSetting("Message", "Hello, playername!");
    public static StringSetting extra = new StringSetting("Extra", ">:)");
    public static ModeSetting position = new ModeSetting("Position", "Center", "Left", "Center", "Right");

    public void onRender() {
        if (mc.player == null) return;
        FontManager.drawString(getWelcomeMessage() + (extra.getValue().equals("") ? "" : " " + extra.getValue()), getX(), getY(), ColorModule.getColor().getRGB());
    }

    public float getX() {
        switch (position.getValue()) {
            case "Center": {
                ScaledResolution resolution = new ScaledResolution(mc);
                return resolution.getScaledWidth() / 2.0f - (FontManager.getStringWidth(getWelcomeMessage() + (extra.getValue().equals("") ? "" : " " + extra.getValue())) / 2.0f);
            }
            case "Right": {
                ScaledResolution resolution = new ScaledResolution(mc);
                return resolution.getScaledWidth() - FontManager.getStringWidth(getWelcomeMessage() + (extra.getValue().equals("") ? "" : " " + extra.getValue())) - 2;
            }
            default: {
                return 2.0f;
            }
        }
    }

    public float getY() {
        if (ModuleManager.isModuleEnabled("Watermark")) {
            if (Watermark.secondLine.getValue()) {
                if (position.equals("Left")) {
                    return 22.0f;
                } else {
                    return 2.0f;
                }
            } else {
                if (position.equals("Left")) {
                    return 12.0f;
                } else {
                    return 2.0f;
                }
            }
        } else {
            return 2.0f;
        }
    }

    public String getTimeOfDay() {
        Calendar calendar = Calendar.getInstance();
        int timeOfDay = calendar.get(Calendar.HOUR_OF_DAY);
        if (timeOfDay < 12) {
            return "Good morning";
        } else if (timeOfDay < 16) {
            return "Good afternoon";
        } else if (timeOfDay < 21) {
            return "Good evening";
        } else {
            return "Good night";
        }
    }

    public String getHoliday() {
        final int month = Integer.parseInt(new SimpleDateFormat("MM").format(new Date()));
        final int day = Integer.parseInt(new SimpleDateFormat("dd").format(new Date()));
        switch (month) {
            case 1: {
                if (day == 1) {
                    return "Happy New Years";
                }
            }
            case 2: {
                if (day == 14) {
                    return "Happy Valentines Day";
                }
                break;
            }
            case 10: {
                if (day == 31) {
                    return "Happy Halloween";
                }
                break;
            }
            case 11: {
                final LocalDate thanksGiving = Year.of(Integer.parseInt(new SimpleDateFormat("yyyy").format(new Date()))).atMonth(Month.NOVEMBER).atDay(1).with(TemporalAdjusters.lastInMonth(DayOfWeek.WEDNESDAY));
                if (thanksGiving.getDayOfMonth() == day) {
                    return "Happy Thanksgiving";
                }
            }
            case 12: {
                if (day == 25) {
                    return "Merry Christmas";
                }
                break;
            }
        }
        return "No holiday is currently going on";
    }

    public String getWelcomeMessage() {
        switch (mode.getValue()) {
            case "Short":
                return "Greetings, " + mc.player.getName() + "!";
            case "Time":
                return getTimeOfDay() + ", " + mc.player.getName() + "!";
            case "Holiday":
                return getHoliday() + ", " + mc.player.getName() + "!";
            case "Hebrew":
                return "Shalom, " + mc.player.getName() + "!";
            case "Long":
                return "Welcome to Azure, " + mc.player.getName() + "!";
            case "Custom":
                String msg = message.getValue();
                msg = msg.replace("playername", mc.player.getName());
                return msg;
            default:
                return "Hello, " + mc.player.getName() + "!";
        }
    }
}
