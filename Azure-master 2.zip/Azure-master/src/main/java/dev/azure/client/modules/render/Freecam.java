package dev.azure.client.modules.render;

import dev.azure.client.modules.Category;
import dev.azure.client.modules.Module;
import dev.azure.client.settings.implement.BooleanSetting;
import dev.azure.client.settings.implement.DoubleSetting;
import dev.azure.client.settings.implement.ModeSetting;
import dev.azure.client.utilities.math.MathUtils;
import dev.azure.client.utilities.render.CameraEntity;
import dev.azure.event.implement.MoveEvent;
import dev.azure.event.implement.PacketEvent;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.entity.Entity;
import net.minecraft.network.play.client.*;
import net.minecraft.network.play.server.SPacketRespawn;
import net.minecraft.network.play.server.SPacketSetPassengers;
import net.minecraft.util.math.Vec3d;

public class Freecam extends Module {
    public Freecam() {
        super("Freecam", "Freecam", "Let's you move anywhere without actually moving.", Category.RENDER);
        addSettings(mode, speed, cancelPackets);
    }

    private Entity riding;
    private EntityOtherPlayerMP camera;
    private Vec3d position;
    private float yaw;
    private float pitch;

    public static ModeSetting mode = new ModeSetting("Mode", "Camera", "Normal", "Camera");
    public static DoubleSetting speed = new DoubleSetting("Speed", 1.0, 0.0, 10.0);
    public static BooleanSetting cancelPackets = new BooleanSetting("CancelPackets", true);

    public void onEnable() {
        if (mc.world == null) return;

        if (mode.equals("Normal")) {
            riding = null;

            if (mc.player.getRidingEntity() != null) {
                this.riding = mc.player.getRidingEntity();
                mc.player.dismountRidingEntity();
            }

            camera = new EntityOtherPlayerMP(mc.world, mc.getSession().getProfile());
            camera.copyLocationAndAnglesFrom(mc.player);
            camera.prevRotationYaw = mc.player.rotationYaw;
            camera.rotationYawHead = mc.player.rotationYawHead;
            camera.inventory.copyInventory(mc.player.inventory);
            mc.world.addEntityToWorld(-69, camera);

            if (riding != null) {
                camera.startRiding(riding);
            }

            position = mc.player.getPositionVector();
            yaw = mc.player.rotationYaw;
            pitch = mc.player.rotationPitch;

            mc.player.noClip = true;
        } else {
            CameraEntity.setCameraState(true);
        }
    }

    public void onDisable() {
        if (mc.world == null) return;

        if (mode.getValue().equals("Normal")) {
            if (riding != null) {
                if (camera != null) {
                    camera.dismountRidingEntity();
                }

                mc.player.startRiding(riding, true);
                riding = null;
            }

            if (camera != null) {
                mc.world.removeEntity(camera);
            }

            if (position != null) {
                mc.player.setPosition(position.x, position.y, position.z);
            }

            mc.player.rotationYaw = this.yaw;
            mc.player.rotationPitch = this.pitch;
            mc.player.noClip = false;
            mc.player.setVelocity(0, 0, 0);
        } else {
            CameraEntity.setCameraState(false);
        }
    }

    public void onTick() {
        if (mode.equals("Camera")) {
            CameraEntity.movementTick(mc.player.movementInput.sneak, mc.player.movementInput.jump);
        }

        if (mode.equals("Normal")) {
            mc.player.noClip = true;
            mc.player.setVelocity(0, 0, 0);
            final double[] direction = MathUtils.directionSpeed(speed.getValue());

            if (mc.player.movementInput.moveStrafe != 0 || mc.player.movementInput.moveForward != 0) {
                mc.player.motionX = direction[0];
                mc.player.motionZ = direction[1];
            } else {
                mc.player.motionX = 0;
                mc.player.motionZ = 0;
            }

            mc.player.setSprinting(false);
            if (mc.gameSettings.keyBindJump.isKeyDown()) {
                mc.player.motionY += speed.getValue();
            }

            if (mc.gameSettings.keyBindSneak.isKeyDown()) {
                mc.player.motionY -= speed.getValue();
            }

            if (mc.player.isRiding()) {
                mc.player.dismountRidingEntity();
            }
        }
    }

    @SuppressWarnings("unused")
    @EventHandler
    private final Listener<MoveEvent> onMove = new Listener<>(event -> {
        if (mode.equals("Normal")) {
            mc.player.noClip = true;
        }
    });

    @SuppressWarnings("unused")
    @EventHandler
    private final Listener<PacketEvent.Receive> receiveListener = new Listener<>(event -> {
        if (event.isPre()) {
            if (event.getPacket() instanceof SPacketRespawn) {
                disable();
                return;
            }

            if (event.getPacket() instanceof SPacketSetPassengers && mode.equals("Normal")) {
                SPacketSetPassengers packet = (SPacketSetPassengers) event.getPacket();
                Entity entity = mc.world.getEntityByID(packet.getEntityId());

                if (entity != null) {
                    for (int id : packet.getPassengerIds()) {
                        if (id == mc.player.getEntityId()) {
                            riding = entity;
                            break;
                        }
                    }
                }
            }
        }
    });

    @SuppressWarnings("unused")
    @EventHandler
    private final Listener<PacketEvent.Send> sendListener = new Listener<>(event -> {
        if (event.isPre()) {
            if (mode.equals("Normal")) {
                if (cancelPackets.getValue()) {
                    if ((event.getPacket() instanceof CPacketUseEntity) || (event.getPacket() instanceof CPacketPlayerTryUseItem) || (event.getPacket() instanceof CPacketPlayerTryUseItemOnBlock) || (event.getPacket() instanceof CPacketPlayer) || (event.getPacket() instanceof CPacketVehicleMove) || (event.getPacket() instanceof CPacketChatMessage)) {
                        event.setCancelled(true);
                    }
                }
            } else if (mode.equals("Camera")) {
                if (event.getPacket() instanceof CPacketUseEntity) {
                    CPacketUseEntity packet = (CPacketUseEntity) event.getPacket();
                    if (packet.getEntityFromWorld(mc.world) == mc.player) {
                        event.setCancelled(true);
                    }
                }
            }
        }
    });
}
