package dev.azure.client.modules;

import dev.azure.client.modules.chat.*;
import dev.azure.client.modules.client.*;
import dev.azure.client.modules.combat.*;
import dev.azure.client.modules.hud.Watermark;
import dev.azure.client.modules.hud.Welcomer;
import dev.azure.client.modules.movement.*;
import dev.azure.client.modules.player.*;
import dev.azure.client.modules.render.*;
import dev.azure.client.modules.world.BuildHeight;
import dev.azure.client.modules.world.Burrow;
import dev.azure.client.modules.world.Weather;
import dev.azure.event.implement.RenderEvent;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL32;

import java.util.ArrayList;
import java.util.stream.Collectors;

public class ModuleManager {
    public static ArrayList<Module> modules;

    public void initialize() {
        modules = new ArrayList<>();

        // Combat
        modules.add(new AntiRestock());
        modules.add(new Aura());
        modules.add(new AutoTotem());
        modules.add(new Criticals());
        modules.add(new Offhand());

        // Player
        modules.add(new AntiCrash());
        modules.add(new FakePlayer());
        modules.add(new PingSpoof());
        modules.add(new MiddleClick());
        modules.add(new NoEntityTrace());
        modules.add(new NoHandShake());
        modules.add(new NoSoundLag());
        modules.add(new PortalTweaks());
        modules.add(new Reach());
        modules.add(new SpeedMine());
        modules.add(new Swing());
        modules.add(new XCarry());

        // Movement
        modules.add(new Blink());
        modules.add(new ElytraFly());
        modules.add(new NoSlow());
        modules.add(new ReverseStep());
        modules.add(new Sprint());
        modules.add(new Step());
        modules.add(new Timer());
        modules.add(new Velocity());

        // Render
        modules.add(new Animations());
        modules.add(new AspectRatio());
        modules.add(new EnchantColor());
        modules.add(new Freecam());
        modules.add(new FullBright());
        modules.add(new ItemPhysics());
        modules.add(new ViewClip());
        modules.add(new ViewModel());

        // Chat
        modules.add(new Alerts());
        modules.add(new AutoGG());
        modules.add(new AutoHash());
        modules.add(new AutoReply());
        modules.add(new ChatColor());
        modules.add(new CustomChat());
        modules.add(new Highlight());
        modules.add(new Suffix());

        // World
        modules.add(new BuildHeight());
        modules.add(new Burrow());
        modules.add(new Weather());

        // Client
        modules.add(new ClickGuiModule());
        modules.add(new ColorModule());
        modules.add(new CommandModule());
        modules.add(new DiscordModule());
        modules.add(new FontModule());

        // HUD
        modules.add(new Watermark());
        modules.add(new Welcomer());
    }

    public static void renderWorld(RenderWorldLastEvent event) {
        Minecraft.getMinecraft().profiler.startSection("azure");
        Minecraft.getMinecraft().profiler.startSection("setup");

        GL11.glHint(GL11.GL_LINE_SMOOTH_HINT, GL11.GL_NICEST);
        GlStateManager.tryBlendFuncSeparate(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA, GL11.GL_ZERO, GL11.GL_ONE);
        GlStateManager.shadeModel(GL11.GL_SMOOTH);
        GlStateManager.depthMask(false);
        GlStateManager.enableBlend();
        GlStateManager.disableDepth();
        GlStateManager.disableTexture2D();
        GlStateManager.disableLighting();
        GlStateManager.disableCull();
        GlStateManager.enableAlpha();
        GL11.glEnable(GL11.GL_LINE_SMOOTH);
        GL11.glEnable(GL32.GL_DEPTH_CLAMP);

        RenderEvent renderEvent = new RenderEvent(event.getPartialTicks());
        Minecraft.getMinecraft().profiler.endSection();

        modules.stream().filter(Module::isEnabled).forEach(module -> {
            Minecraft.getMinecraft().profiler.startSection(module.getName());
            module.onWorldRender(renderEvent);
            Minecraft.getMinecraft().profiler.endSection();
        });

        Minecraft.getMinecraft().profiler.startSection("release");

        GL11.glDisable(GL32.GL_DEPTH_CLAMP);
        GL11.glDisable(GL11.GL_LINE_SMOOTH);
        GlStateManager.enableAlpha();
        GlStateManager.enableCull();
        GlStateManager.enableLighting();
        GlStateManager.enableTexture2D();
        GlStateManager.enableDepth();
        GlStateManager.disableBlend();
        GlStateManager.depthMask(true);
        GlStateManager.glLineWidth(1.0f);
        GlStateManager.shadeModel(GL11.GL_FLAT);
        GL11.glHint(GL11.GL_LINE_SMOOTH_HINT, GL11.GL_DONT_CARE);

        Minecraft.getMinecraft().profiler.endSection();
        Minecraft.getMinecraft().profiler.endSection();
    }

    public static ArrayList<Module> getModules() {
        return modules;
    }

    public static ArrayList<Module> getModules(Category category) {
        return (ArrayList<Module>) modules.stream().filter(module -> module.getCategory().equals(category)).collect(Collectors.toList());
    }

    public static boolean isModuleEnabled(String name) {
        Module module = getModules().stream().filter(m -> m.isEnabled() && m.getName().equals(name)).findFirst().orElse(null);

        if (module == null) {
            return false;
        } else {
            return module.isEnabled();
        }
    }
}