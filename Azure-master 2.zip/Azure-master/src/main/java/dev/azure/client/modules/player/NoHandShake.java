package dev.azure.client.modules.player;

import dev.azure.client.modules.Category;
import dev.azure.client.modules.Module;
import dev.azure.event.implement.PacketEvent;
import io.netty.buffer.Unpooled;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.client.CPacketCustomPayload;
import net.minecraftforge.fml.common.network.internal.FMLProxyPacket;

public class NoHandShake extends Module {
    public NoHandShake() {
        super("NoHandShake", "No HandShake", "Makes the server think you're playing on vanilla.", Category.PLAYER);
        addSettings();
    }

    @SuppressWarnings("unused")
    @EventHandler
    private final Listener<PacketEvent.Send> sendListener = new Listener<>(event -> {
        if (event.isPre()) {
            if (event.getPacket() instanceof FMLProxyPacket && !mc.isSingleplayer()) {
                event.setCancelled(true);
            }

            if (event.getPacket() instanceof CPacketCustomPayload && ((CPacketCustomPayload) event.getPacket()).getChannelName().equals("MC|Brand")) {
                CPacketCustomPayload packet = (CPacketCustomPayload) event.getPacket();
                packet.data = new PacketBuffer(Unpooled.buffer()).writeString("vanilla");
            }
        }
    });
}
