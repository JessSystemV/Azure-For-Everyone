package dev.azure.client.modules.combat;

import dev.azure.client.modules.Category;
import dev.azure.client.modules.Module;
import dev.azure.client.settings.implement.DoubleSetting;
import dev.azure.client.settings.implement.IntegerSetting;
import dev.azure.client.utilities.world.BlockUtils;
import dev.azure.event.implement.PacketEvent;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.block.BlockShulkerBox;
import net.minecraft.item.ItemShulkerBox;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;
import java.util.List;

public class AntiRestock extends Module {
    public AntiRestock() {
        super("AntiRestock", "Anti Restock", "Prevents your enemies from restocking.", Category.COMBAT);
        addSettings(range, retryDelay);
    }

    private int ticks;
    private final List<BlockPos> retries = new ArrayList<>();
    private final List<BlockPos> selfPlaced = new ArrayList<>();

    DoubleSetting range = new DoubleSetting("Range", 5.0, 0.1, 6.0);
    IntegerSetting retryDelay = new IntegerSetting("RetryDelay", 10, 0, 20);

    public void onTick() {
        if (ticks++ < retryDelay.getValue()) {
            ticks = 0;
            retries.clear();
        }

        final List<BlockPos> sphere = BlockUtils.getSphere((float) range.getValue());

        for (final BlockPos pos : sphere) {
            if (retries.contains(pos) || selfPlaced.contains(pos)) continue;
            if (mc.world.getBlockState(pos).getBlock() instanceof BlockShulkerBox) {
                mc.player.swingArm(EnumHand.MAIN_HAND);
                mc.player.connection.sendPacket(new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, pos, EnumFacing.UP));
                mc.player.connection.sendPacket(new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, pos, EnumFacing.UP));
                retries.add(pos);
            }
        }
    }

    @SuppressWarnings("unused")
    @EventHandler
    private final Listener<PacketEvent.Send> sendListener = new Listener<>(event -> {
        if (event.isPre()) {
            if (event.getPacket() instanceof CPacketPlayerTryUseItemOnBlock) {
                final CPacketPlayerTryUseItemOnBlock packet = (CPacketPlayerTryUseItemOnBlock) event.getPacket();
                if (mc.player.getHeldItem(packet.getHand()).getItem() instanceof ItemShulkerBox) {
                    selfPlaced.add(packet.getPos().offset(packet.getDirection()));
                }
            }
        }
    });
}
