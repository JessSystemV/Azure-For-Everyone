package dev.azure.client;

import dev.azure.client.commands.CommandManager;
import dev.azure.client.configuration.LoadConfiguration;
import dev.azure.client.gui.click.ClickGUI;
import dev.azure.client.modules.ModuleManager;
import dev.azure.client.social.SocialManager;
import dev.azure.event.EventProcessor;
import me.zero.alpine.bus.EventBus;
import me.zero.alpine.bus.EventManager;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.opengl.Display;

@Mod(modid = Azure.MOD_ID, name = Azure.MOD_NAME, version = Azure.VERSION)
public class Azure {
    public static final String MOD_ID = "azure";
    public static final String MOD_NAME = "Azure";
    public static final String VERSION = "v1.0.5";
    public static final String BUILD = "120";

    public static Logger log = LogManager.getLogger("Azure");
    public static EventBus EVENT_BUS = new EventManager();

    public EventProcessor eventProcessor;
    public ModuleManager moduleManager;
    public CommandManager commandManager;
    public SocialManager socialManager;
    public ClickGUI clickGUI;

    @Mod.Instance(MOD_ID)
    public static Azure INSTANCE;

    public Azure() {
        INSTANCE = this;
    }

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {

    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        log.info("Starting initialization process for Azure " + VERSION + ".");
        log.info("Azure is currently on Build " + BUILD + ".");

        Display.setTitle("Azure " + VERSION);

        moduleManager = new ModuleManager();
        moduleManager.initialize();

        commandManager = new CommandManager();
        commandManager.initialize();

        socialManager = new SocialManager();
        socialManager.initialize();

        eventProcessor = new EventProcessor();
        eventProcessor.initialize();

        clickGUI = new ClickGUI();

        LoadConfiguration.loadConfig();

        log.info("Finished initialization process for Azure " + VERSION + ".");
    }

    @Mod.EventHandler
    public void postInit(FMLPostInitializationEvent event) {

    }
}
