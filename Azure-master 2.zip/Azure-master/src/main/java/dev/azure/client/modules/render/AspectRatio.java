package dev.azure.client.modules.render;

import dev.azure.client.modules.Category;
import dev.azure.client.modules.Module;
import dev.azure.client.settings.implement.DoubleSetting;
import dev.azure.event.implement.AspectEvent;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;

public class AspectRatio extends Module {
    public AspectRatio() {
        super("AspectRatio", "Aspect Ratio", "Changes your aspect ratio.", Category.RENDER);
        addSettings(value);
    }

    DoubleSetting value = new DoubleSetting("Value", 1.0, 0.1, 3.0);

    @SuppressWarnings("unused")
    @EventHandler
    private final Listener<AspectEvent> onAspect = new Listener<>(event -> {
        event.setAspect((float) value.getValue());
    });
}
