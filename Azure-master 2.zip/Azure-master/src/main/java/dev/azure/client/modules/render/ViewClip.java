package dev.azure.client.modules.render;

import dev.azure.client.modules.Category;
import dev.azure.client.modules.Module;
import dev.azure.client.settings.implement.BooleanSetting;
import dev.azure.client.settings.implement.DoubleSetting;

public class ViewClip extends Module {
    public ViewClip() {
        super("ViewClip", "View Clip", "Makes your camera clip through blocks and extends it.", Category.RENDER);
        addSettings(extend, distance);
    }

    public static BooleanSetting extend = new BooleanSetting("Extend", false);
    public static DoubleSetting distance = new DoubleSetting("Distance", 1.0, 0.0, 10.0);
}
