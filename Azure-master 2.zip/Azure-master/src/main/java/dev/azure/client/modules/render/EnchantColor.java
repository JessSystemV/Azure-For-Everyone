package dev.azure.client.modules.render;

import dev.azure.client.modules.Category;
import dev.azure.client.modules.Module;
import dev.azure.client.modules.client.ColorModule;
import dev.azure.client.settings.implement.BooleanSetting;
import dev.azure.client.settings.implement.IntegerSetting;

import java.awt.*;

public class EnchantColor extends Module {
    public EnchantColor() {
        super("EnchantColor", "Enchant Color", "Let's you change the color of the enchanting glint.", Category.RENDER);
        addSettings(rainbow, red, green, blue);
    }

    public static BooleanSetting rainbow = new BooleanSetting("Rainbow", false);
    public static IntegerSetting red = new IntegerSetting("Red", 0, 0, 255);
    public static IntegerSetting green = new IntegerSetting("Green", 0, 0, 255);
    public static IntegerSetting blue = new IntegerSetting("Blue", 255, 0, 255);

    public static Color getColor() {
        if (ColorModule.sync.getValue()) {
            return ColorModule.getColor();
        } else {
            return new Color(red.getValue(), green.getValue(), blue.getValue());
        }
    }
}
