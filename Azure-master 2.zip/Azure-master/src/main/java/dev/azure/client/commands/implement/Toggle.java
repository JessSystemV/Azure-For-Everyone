package dev.azure.client.commands.implement;

import com.mojang.realmsclient.gui.ChatFormatting;
import dev.azure.client.commands.Command;
import dev.azure.client.modules.Module;
import dev.azure.client.modules.ModuleManager;
import dev.azure.client.utilities.chat.ChatUtils;
import dev.azure.client.utilities.chat.CommandUtils;

public class Toggle extends Command {
    public Toggle() {
        super("Toggle", "Toggles a module by name.", "toggle <module>", "t");
    }

    @Override
    public void onCommand(String[] args, String command) {
        if (args.length == 1) {
            boolean found = false;
            for (Module module : ModuleManager.getModules()) {
                if (module.getName().equalsIgnoreCase(args[0])) {
                    module.toggle();
                    ChatUtils.sendMessage(CommandUtils.getPartTwo() + module.getName() + CommandUtils.getPartOne() + " has been toggled " + (module.isEnabled() ? ChatFormatting.GREEN + "on" : ChatFormatting.RED + "off") + CommandUtils.getPartOne() + "!", true);
                    found = true;
                    break;
                }
            }

            if (!found) {
                ChatUtils.sendMessage("Could not find module.", true);
            }
        } else {
            ChatUtils.sendMessage(getSyntax(), true);
        }
    }
}
