package dev.azure.client.modules.client;

import dev.azure.client.Azure;
import dev.azure.client.modules.Category;
import dev.azure.client.modules.Module;

public class ClickGuiModule extends Module {
    public ClickGuiModule() {
        super("ClickGUI", "Click GUI", "The client's Click GUI.", Category.CLIENT);
        addSettings();
    }

    public void onEnable() {
        mc.displayGuiScreen(Azure.INSTANCE.clickGUI);
        this.disable();
    }
}
