package dev.azure.client.gui.font;

import dev.azure.client.modules.ModuleManager;
import dev.azure.client.utilities.Utility;

public class FontManager implements Utility {
    public static void drawString(String text, float x, float y, int color) {
        if (ModuleManager.isModuleEnabled("Font")) {
            FontRenderer.clientFont.drawStringWithShadow(text, x, y, color);
        } else {
            mc.fontRenderer.drawStringWithShadow(text, x, y, color);
        }
    }

    public static void drawCenteredString(String text, float x, float y, int color) {
        if (ModuleManager.isModuleEnabled("Font")) {
            FontRenderer.clientFont.drawStringWithShadow(text, x - getStringWidth(text) / 2.0f, y, color);
        } else {
            mc.fontRenderer.drawStringWithShadow(text, x - getStringWidth(text) / 2.0f, y, color);
        }
    }

    public static float getStringWidth(String text) {
        if (ModuleManager.isModuleEnabled("Font")) {
            return FontRenderer.clientFont.getStringWidth(text);
        } else {
            return mc.fontRenderer.getStringWidth(text);
        }
    }

    public static int getHeight() {
        if (ModuleManager.isModuleEnabled("Font")) {
            return FontRenderer.clientFont.getHeight();
        } else {
            return mc.fontRenderer.FONT_HEIGHT;
        }
    }
}
