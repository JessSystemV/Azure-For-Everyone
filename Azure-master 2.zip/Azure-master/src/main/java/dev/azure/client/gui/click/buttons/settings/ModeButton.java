package dev.azure.client.gui.click.buttons.settings;

import dev.azure.client.gui.click.buttons.ModuleButton;
import dev.azure.client.gui.click.implement.Component;
import dev.azure.client.gui.font.FontManager;
import dev.azure.client.modules.client.ColorModule;
import dev.azure.client.settings.implement.BooleanSetting;
import dev.azure.client.settings.implement.ModeSetting;
import dev.azure.client.utilities.render.RenderUtils;

import java.awt.*;

public class ModeButton extends Component {
    private boolean hovered;
    private int modeIndex;
    private final ModeSetting setting;
    private final ModuleButton parent;
    private int offset;
    private int x;
    private int y;

    public ModeButton(final ModeSetting setting, final ModuleButton parent, final int offset) {
        this.setting = setting;
        this.parent = parent;
        this.x = parent.panel.getX();
        this.y = parent.panel.getY() + parent.offset;
        this.offset = offset;
    }

    @Override
    public void renderComponent() {
        RenderUtils.drawRect(getParentX(), getParentY() + offset + 1, getParentX() + getParentWidth(), getParentY() + 14 + offset, new Color(0, 0, 0, 135).getRGB());
        RenderUtils.drawRect(getParentX(), getParentY() + offset, getParentX() + getParentWidth(), getParentY() + 1 + offset, new Color(0, 0, 0, 135).getRGB());
        RenderUtils.drawRect(getParentX() + 2, getParentY() + offset + 1, getParentX() + getParentWidth() - 2, getParentY() + 13 + offset, ColorModule.getColor(35).getRGB());
        FontManager.drawString(setting.getName() + ": " + setting.getValue(), getParentX() + 4, getParentY() + offset + 3, -1);
    }

    @Override
    public void setOffset(final int offset) {
        this.offset = offset;
    }

    @Override
    public void updateComponent(final int mouseX, final int mouseY) {
        hovered = isMouseOnButton(mouseX, mouseY);
        x = parent.panel.getX();
        y = parent.panel.getY() + offset;
    }

    @Override
    public void mouseClicked(final int mouseX, final int mouseY, final int button) {
        if (this.isMouseOnButton(mouseX, mouseY) && button == 0 && this.parent.open) {
            final int maxIndex = this.setting.getModes().size() - 1;
            ++this.modeIndex;
            if (this.modeIndex > maxIndex) {
                this.modeIndex = 0;
            }
            this.setting.setValue(this.setting.getModes().get(this.modeIndex));
        }
    }

    public boolean isMouseOnButton(final int x, final int y) {
        return x > this.x && x < this.x + 90 && y > this.y && y < this.y + 14;
    }

    public int getParentX() {
        return parent.panel.getX();
    }

    public int getParentY() {
        return parent.panel.getY();
    }

    public int getParentWidth() {
        return parent.panel.getWidth();
    }
}
