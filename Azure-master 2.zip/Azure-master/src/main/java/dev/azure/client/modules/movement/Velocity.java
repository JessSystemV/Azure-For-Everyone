package dev.azure.client.modules.movement;

import dev.azure.client.modules.Category;
import dev.azure.client.modules.Module;
import dev.azure.client.settings.implement.BooleanSetting;
import dev.azure.client.settings.implement.IntegerSetting;
import dev.azure.event.implement.CollisionEvent;
import dev.azure.event.implement.PacketEvent;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.EntityFishHook;
import net.minecraft.network.play.server.SPacketEntityStatus;
import net.minecraft.network.play.server.SPacketEntityVelocity;
import net.minecraft.network.play.server.SPacketExplosion;

public class Velocity extends Module {
    public Velocity() {
        super("Velocity", "Velocity", "Prevents you from taking knockback.", Category.MOVEMENT);
        addSettings(horizontal, vertical, explosions, bobbers, pushable, water);
    }

    IntegerSetting horizontal = new IntegerSetting("Horizontal", 0, 0, 100);
    IntegerSetting vertical = new IntegerSetting("Vertical", 0, 0, 100);

    BooleanSetting explosions = new BooleanSetting("Explosions", true);
    BooleanSetting bobbers = new BooleanSetting("Bobbers", true);
    BooleanSetting pushable = new BooleanSetting("Pushable", false);
    BooleanSetting water = new BooleanSetting("Water", true);

    @SuppressWarnings("unused")
    @EventHandler
    private final Listener<PacketEvent.Receive> receiveListener = new Listener<>(event -> {
        if (event.isPre()) {
            if (mc.player == null) return;

            if (event.getPacket() instanceof SPacketEntityStatus && bobbers.getValue()) {
                final SPacketEntityStatus packet = (SPacketEntityStatus) event.getPacket();
                if (packet.getOpCode() == 31) {
                    final Entity entity = packet.getEntity(mc.world);
                    if (entity instanceof EntityFishHook) {
                        final EntityFishHook fishHook = (EntityFishHook) entity;
                        if (fishHook.caughtEntity == mc.player) {
                            event.setCancelled(true);
                        }
                    }
                }
            }

            if (event.getPacket() instanceof SPacketEntityVelocity) {
                final SPacketEntityVelocity packet = (SPacketEntityVelocity) event.getPacket();
                if (packet.getEntityID() == mc.player.getEntityId()) {
                    if (horizontal.getValue() == 0 && vertical.getValue() == 0) {
                        event.setCancelled(true);
                        return;
                    }

                    if (horizontal.getValue() != 100) {
                        packet.motionX = packet.motionX / 100 * horizontal.getValue();
                        packet.motionZ = packet.motionZ / 100 * horizontal.getValue();
                    }

                    if (vertical.getValue() != 100) {
                        packet.motionY = packet.motionY / 100 * vertical.getValue();
                    }
                }
            }

            if (event.getPacket() instanceof SPacketExplosion && explosions.getValue()) {
                final SPacketExplosion packet = (SPacketExplosion) event.getPacket();

                if (horizontal.getValue() == 0 && vertical.getValue() == 0) {
                    event.setCancelled(true);
                    return;
                }

                if (horizontal.getValue() != 100) {
                    packet.motionX = packet.motionX / 100 * horizontal.getValue();
                    packet.motionZ = packet.motionZ / 100 * horizontal.getValue();
                }

                if (vertical.getValue() != 100) {
                    packet.motionY = packet.motionY / 100 * vertical.getValue();
                }
            }
        }
    });

    @SuppressWarnings("unused")
    @EventHandler
    private final Listener<CollisionEvent> onCollision = new Listener<>(event -> {
        if (pushable.getValue()) return;
        event.setCancelled(true);
    });

    @SuppressWarnings("unused")
    @EventHandler
    private final Listener<CollisionEvent.Water> onWaterCollision = new Listener<>(event -> {
        if (!water.getValue()) return;
        event.setCancelled(true);
    });

    @SuppressWarnings("unused")
    @EventHandler
    private final Listener<CollisionEvent.Blocks> onBlockCollision = new Listener<>(event -> {
        if (pushable.getValue()) return;
        event.setCancelled(true);
    });
}
