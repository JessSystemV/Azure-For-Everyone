package dev.azure.client.modules.combat;

import dev.azure.client.modules.Category;
import dev.azure.client.modules.Module;
import dev.azure.client.settings.implement.BooleanSetting;
import dev.azure.client.settings.implement.IntegerSetting;
import dev.azure.client.social.SocialManager;
import dev.azure.client.utilities.entity.InventoryUtils;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.init.Items;
import net.minecraft.inventory.ClickType;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;

public class Offhand extends Module {
    public Offhand() {
        super("Offhand", "Offhand", "Let's you have a crystal or apple in your offhand without dying.", Category.COMBAT);
        addSettings(health, fallDistance, enemyRange, crystalCheck);
    }

    IntegerSetting health = new IntegerSetting("Health", 16, 1, 36);
    IntegerSetting fallDistance = new IntegerSetting("FallDistance", 30, 1, 60);
    IntegerSetting enemyRange = new IntegerSetting("EnemyRange", 11, 1, 30);
    BooleanSetting crystalCheck = new BooleanSetting("CrystalCheck", true);

    public void onTick() {
        if (mc.currentScreen instanceof GuiContainer || mc.world == null || mc.player == null) return;

        if (!shouldTotem()) {
            if (!(mc.player.getHeldItemOffhand() != ItemStack.EMPTY && mc.player.getHeldItemOffhand().getItem() == Items.END_CRYSTAL)) {
                final int slot = InventoryUtils.findWindowItem(Items.END_CRYSTAL, 9, 44);
                if (slot != -1) {
                    mc.playerController.windowClick(0, slot, 0, ClickType.PICKUP, mc.player);
                    mc.playerController.windowClick(0, 45, 0, ClickType.PICKUP, mc.player);
                    if (!(mc.player.inventoryContainer.getSlot(slot).getStack().isEmpty())) {
                        mc.playerController.windowClick(0, slot, 0, ClickType.THROW, mc.player);
                    }
                    mc.playerController.windowClick(0, slot, 0, ClickType.PICKUP, mc.player);
                }
            }
        } else if (!(mc.player.getHeldItemOffhand() != ItemStack.EMPTY && mc.player.getHeldItemOffhand().getItem() == Items.TOTEM_OF_UNDYING)) {
            final int slot = InventoryUtils.findWindowItem(Items.TOTEM_OF_UNDYING, 9, 44);
            if (slot != -1) {
                mc.playerController.windowClick(0, slot, 0, ClickType.PICKUP, mc.player);
                mc.playerController.windowClick(0, 45, 0, ClickType.PICKUP, mc.player);
                if (!(mc.player.inventoryContainer.getSlot(slot).getStack().isEmpty())) {
                    mc.playerController.windowClick(0, slot, 0, ClickType.THROW, mc.player);
                }
                mc.playerController.windowClick(0, slot, 0, ClickType.PICKUP, mc.player);
            }
        }
    }

    private boolean shouldTotem() {
        return (mc.player.getHealth() + mc.player.getAbsorptionAmount()) <= health.getValue() || mc.player.getItemStackFromSlot(EntityEquipmentSlot.CHEST).getItem() == Items.ELYTRA || !nearPlayers() || mc.player.fallDistance >= fallDistance.getValue() || (crystalCheck.getValue() && !isCrystalsAABBEmpty());
    }

    private boolean nearPlayers() {
        return mc.world.playerEntities.stream().anyMatch(entity -> entity != mc.player && entity.getEntityId() != -1488 && !SocialManager.isFriend(entity.getName()) && mc.player.getDistance(entity) <= enemyRange.getValue());
    }

    private boolean isEmpty(BlockPos pos) {
        return mc.world.getEntitiesWithinAABBExcludingEntity(null, new AxisAlignedBB(pos)).stream().noneMatch(entity -> entity instanceof EntityEnderCrystal);
    }

    private boolean isCrystalsAABBEmpty() {
        return isEmpty(mc.player.getPosition().add(1, 0, 0)) && isEmpty(mc.player.getPosition().add(-1, 0, 0)) && isEmpty(mc.player.getPosition().add(0, 0, 1)) && isEmpty(mc.player.getPosition().add(0, 0, -1)) && isEmpty(mc.player.getPosition());
    }
}