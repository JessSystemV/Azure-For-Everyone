package dev.azure.client.gui.click.buttons.settings;

import dev.azure.client.gui.click.buttons.ModuleButton;
import dev.azure.client.gui.click.implement.Component;
import dev.azure.client.gui.font.FontManager;
import dev.azure.client.modules.client.ColorModule;
import dev.azure.client.settings.implement.StringSetting;
import dev.azure.client.utilities.render.RenderUtils;
import net.minecraft.util.ChatAllowedCharacters;
import org.lwjgl.input.Keyboard;

import java.awt.*;
import java.awt.datatransfer.DataFlavor;
import java.util.Date;

public class StringButton extends Component {
    private boolean hovered;
    private String currentString = "";
    public boolean isListening;
    private final StringSetting setting;
    private final ModuleButton parent;
    private int offset;
    private int x;
    private int y;

    long idleLast = new Date().getTime();
    private boolean idling;

    public StringButton(final StringSetting setting, final ModuleButton parent, final int offset) {
        this.setting = setting;
        this.parent = parent;
        this.x = parent.panel.getX();
        this.y = parent.panel.getY() + parent.offset;
        this.offset = offset;
    }

    @Override
    public void renderComponent() {
        RenderUtils.drawRect(getParentX(), getParentY() + offset + 1, getParentX() + getParentWidth(), getParentY() + 14 + offset, new Color(0, 0, 0, 135).getRGB());
        RenderUtils.drawRect(getParentX(), getParentY() + offset, getParentX() + getParentWidth(), getParentY() + 1 + offset, new Color(0, 0, 0, 135).getRGB());
        RenderUtils.drawRect(getParentX() + 2, getParentY() + offset + 1, getParentX() + getParentWidth() - 2, getParentY() + 13 + offset, ColorModule.getColor(35).getRGB());

        if (isListening) {
            FontManager.drawString(currentString + getIdleSign(), getParentX() + 4, getParentY() + offset + 3, -1);
        } else {
            FontManager.drawString(setting.getName() + ": " + setting.getValue(), getParentX() + 4, getParentY() + offset + 3, -1);
        }
    }

    @Override
    public void setOffset(final int offset) {
        this.offset = offset;
    }

    @Override
    public void updateComponent(final int mouseX, final int mouseY) {
        hovered = isMouseOnButton(mouseX, mouseY);
        x = parent.panel.getX();
        y = parent.panel.getY() + offset;
    }

    @Override
    public void mouseClicked(final int mouseX, final int mouseY, final int button) {
        if (isMouseOnButton(mouseX, mouseY)) {
            isListening = !isListening;
        } else {
            isListening = false;
        }
    }

    @Override
    public void keyTyped(final char typedChar, final int key) {
        if (isListening) {
            if (key == 1) {
                return;
            }

            if (key == 28) {
                enterString();
            } else if (key == 14) {
                currentString = removeLastChar(currentString);
            } else if (key == 47 && (Keyboard.isKeyDown(157) || Keyboard.isKeyDown(29))) {
                try {
                    this.currentString = currentString + Toolkit.getDefaultToolkit().getSystemClipboard().getData(DataFlavor.stringFlavor);
                } catch (Exception exception) {
                    exception.printStackTrace();
                }
            } else if (ChatAllowedCharacters.isAllowedCharacter(typedChar)) {
                currentString = currentString + typedChar;
            }
        }
    }

    public static String removeLastChar(String str) {
        String output = "";
        if (str != null && str.length() > 0) {
            output = str.substring(0, str.length() - 1);
        }
        return output;
    }

    public boolean isMouseOnButton(final int x, final int y) {
        return x > this.x && x < this.x + 90 && y > this.y && y < this.y + 14;
    }

    public int getParentX() {
        return parent.panel.getX();
    }

    public int getParentY() {
        return parent.panel.getY();
    }

    public int getParentWidth() {
        return parent.panel.getWidth();
    }

    private void enterString() {
        if (!this.currentString.isEmpty()) {
            this.setting.setValue(this.currentString);
        }
        this.currentString = "";
    }

    public String getIdleSign() {
        if (new Date().getTime() >= idleLast + 100) {
            idleLast = new Date().getTime();
            idling = !idling;
        }
        if (this.idling) {
            return "_";
        }
        return "";
    }
}
