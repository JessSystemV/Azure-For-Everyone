package dev.azure.client.social;

import dev.azure.client.social.implement.Enemy;
import dev.azure.client.social.implement.Friend;

import java.util.ArrayList;

public class SocialManager {
    public static ArrayList<Friend> friends;
    public static ArrayList<Enemy> enemies;

    public void initialize() {
        friends = new ArrayList<>();
        enemies = new ArrayList<>();
    }

    public static ArrayList<Friend> getFriends() {
        return friends;
    }

    public static Friend getFriend(String name) {
        for (Friend friend : getFriends()) {
            if (friend.getName().equalsIgnoreCase(name)) {
                return friend;
            }
        }

        return null;
    }

    public static void addFriend(String name) {
        friends.add(new Friend(name));
    }

    public static void removeFriend(String name) {
        friends.remove(getFriend(name));
    }

    public static void clearFriends() {
        friends.clear();
    }

    public static boolean isFriend(String name) {
        for (Friend friend : getFriends()) {
            if (friend.getName().equalsIgnoreCase(name)) return true;
        }

        return false;
    }

    public static ArrayList<Enemy> getEnemies() {
        return enemies;
    }

    public static Enemy getEnemy(String name) {
        for (Enemy enemy : getEnemies()) {
            if (enemy.getName().equalsIgnoreCase(name)) {
                return enemy;
            }
        }

        return null;
    }

    public static void addEnemy(String name) {
        enemies.add(new Enemy(name));
    }

    public static void removeEnemy(String name) {
        enemies.remove(getEnemy(name));
    }

    public static void clearEnemies() {
        enemies.clear();
    }

    public static boolean isEnemy(String name) {
        for (Enemy enemy : getEnemies()) {
            if (enemy.getName().equalsIgnoreCase(name)) return true;
        }

        return false;
    }
}
