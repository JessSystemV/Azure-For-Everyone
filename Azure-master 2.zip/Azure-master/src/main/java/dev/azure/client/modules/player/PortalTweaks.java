package dev.azure.client.modules.player;

import dev.azure.client.modules.Category;
import dev.azure.client.modules.Module;
import dev.azure.client.settings.implement.BooleanSetting;
import dev.azure.event.implement.PacketEvent;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.network.play.client.CPacketConfirmTeleport;

public class PortalTweaks extends Module {
    public PortalTweaks() {
        super("PortalTweaks", "Portal Tweaks", "Tweaks how the nether portals work.", Category.PLAYER);
        addSettings(chat, godmode);
    }

    public static BooleanSetting chat = new BooleanSetting("Chat", true);
    public static BooleanSetting godmode = new BooleanSetting("GodMode", false);

    @SuppressWarnings("unused")
    @EventHandler
    private final Listener<PacketEvent.Send> sendListener = new Listener<>(event -> {
        if (event.isPre()) {
            if (godmode.getValue() && event.getPacket() instanceof CPacketConfirmTeleport) {
                event.setCancelled(true);
            }
        }
    });
}
