package dev.azure.client.gui.click.implement;

import net.minecraft.client.Minecraft;

public class Component {
    protected static final Minecraft mc = Minecraft.getMinecraft();

    public void updateComponent(final int mouseX, final int mouseY) {

    }

    public void renderComponent() {

    }

    public void setOffset(final int offset) {

    }

    public int getHeight() {
        return 0;
    }

    public int getParentHeight() {
        return 0;
    }

    public void mouseClicked(final int mouseX, final int mouseY, final int button) {

    }

    public void mouseReleased(final int mouseX, final int mouseY, final int button) {

    }

    public void keyTyped(final char typedChar, final int key) {

    }
}
