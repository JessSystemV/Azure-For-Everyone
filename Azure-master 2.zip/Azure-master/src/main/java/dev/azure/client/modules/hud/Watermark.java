package dev.azure.client.modules.hud;

import com.mojang.realmsclient.gui.ChatFormatting;
import dev.azure.client.Azure;
import dev.azure.client.gui.font.FontManager;
import dev.azure.client.modules.Category;
import dev.azure.client.modules.Module;
import dev.azure.client.modules.client.ColorModule;
import dev.azure.client.settings.implement.BooleanSetting;
import dev.azure.client.settings.implement.ModeSetting;
import dev.azure.client.settings.implement.StringSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.util.math.MathHelper;

import java.text.DecimalFormat;

public class Watermark extends Module {
    public Watermark() {
        super("Watermark", "Watermark", "Shows the watermark of the client.", Category.HUD);
        addSettings(version, versionColor, dash, edition, editionName, customName, name, build, fps, speed, secondLine);
    }

    DecimalFormat format = new DecimalFormat("#.#");

    public static BooleanSetting version = new BooleanSetting("Version", true);
    public static ModeSetting versionColor = new ModeSetting("VersionColor", "Normal", "Normal", "Gray", "White");
    public static BooleanSetting dash = new BooleanSetting("Dash", false);
    public static BooleanSetting edition = new BooleanSetting("Edition", false);
    public static StringSetting editionName = new StringSetting("EditionName", "Gamer Edition");
    public static BooleanSetting customName = new BooleanSetting("CustomName", false);
    public static StringSetting name = new StringSetting("Name", "Azure");
    public static BooleanSetting build = new BooleanSetting("Build", false);
    public static BooleanSetting fps = new BooleanSetting("FPS", false);
    public static BooleanSetting speed = new BooleanSetting("Speed", false);
    public static BooleanSetting secondLine = new BooleanSetting("SecondLine", false);

    public void onRender() {
        FontManager.drawString((customName.getValue() ? name.getValue() : "Azure") + (version.getValue() ? (versionColor.equals("Gray") ? ChatFormatting.GRAY : versionColor.equals("White") ? ChatFormatting.WHITE : "") + " " + (dash.getValue() ? "- " + Azure.VERSION : Azure.VERSION) : "") + ChatFormatting.RESET + (edition.getValue() ? " " + editionName.getValue() : "") + ChatFormatting.RESET + (build.getValue() ? " (" + ChatFormatting.GRAY + "B" + Azure.BUILD + ChatFormatting.RESET + ")" : "") + (fps.getValue() ? " (" + ChatFormatting.GRAY + "FPS: " + Minecraft.getDebugFPS() + ChatFormatting.RESET + ")" : "") + (speed.getValue() ? " (" + ChatFormatting.GRAY + format.format(MathHelper.sqrt(Math.pow(coordsDiff('x'), 2.0f) + Math.pow(coordsDiff('z'), 2.0)) / (mc.timer.tickLength / 1000.0f) * 3.6) + ChatFormatting.RESET + " KM/H)" : ""), 2, 2 + (secondLine.getValue() ? 10 : 0), ColorModule.getColor().getRGB());
    }

    public static double coordsDiff(final char s) {
        switch (s) {
            case 'x': {
                return mc.player.posX - mc.player.prevPosX;
            }
            case 'z': {
                return mc.player.posZ - mc.player.prevPosZ;
            }
            default: {
                return 0.0;
            }
        }
    }
}
