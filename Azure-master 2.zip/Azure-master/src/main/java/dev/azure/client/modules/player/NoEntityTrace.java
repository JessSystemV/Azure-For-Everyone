package dev.azure.client.modules.player;

import dev.azure.client.modules.Category;
import dev.azure.client.modules.Module;
import dev.azure.client.modules.ModuleManager;
import dev.azure.client.settings.implement.BooleanSetting;
import dev.azure.client.settings.implement.ModeSetting;
import net.minecraft.init.Items;

public class NoEntityTrace extends Module {
    public NoEntityTrace() {
        super("NoEntityTrace", "No Entity Trace", "Let's you mine through entities.", Category.PLAYER);
        addSettings(mode, pickaxe);
    }

    public static ModeSetting mode = new ModeSetting("Mode", "Static", "Static", "Dynamic");
    public static BooleanSetting pickaxe = new BooleanSetting("Pickaxe", true);

    public static boolean shouldBlock() {
        return ModuleManager.isModuleEnabled("NoEntityTrace") && (mode.getValue().equalsIgnoreCase("Static") || mc.playerController.isHittingBlock) && (!pickaxe.getValue() || mc.player.getHeldItemMainhand().getItem() == Items.DIAMOND_PICKAXE);
    }
}
