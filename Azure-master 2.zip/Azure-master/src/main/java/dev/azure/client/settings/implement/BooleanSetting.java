package dev.azure.client.settings.implement;

import dev.azure.client.Azure;
import dev.azure.client.settings.Setting;
import dev.azure.event.implement.SetValueEvent;

public class BooleanSetting extends Setting {
    private boolean value;

    public BooleanSetting(String name, final boolean value) {
        super(name, true);
        this.value = value;
    }

    public BooleanSetting(String name, final boolean value, boolean visible) {
        super(name, visible);
        this.value = value;
    }

    public boolean getValue() {
        return value;
    }

    public void setValue(final boolean value) {
        this.value = value;
        Azure.EVENT_BUS.post(new SetValueEvent(this.getName()));
    }
}
