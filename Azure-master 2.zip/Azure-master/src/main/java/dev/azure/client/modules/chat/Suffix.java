package dev.azure.client.modules.chat;

import dev.azure.client.modules.Category;
import dev.azure.client.modules.Module;
import dev.azure.client.modules.ModuleManager;
import dev.azure.client.settings.implement.BooleanSetting;
import dev.azure.client.settings.implement.ModeSetting;

public class Suffix extends Module {
    public Suffix() {
        super("Suffix", "Suffix", "Puts the client's name on every one of your messages.", Category.CHAT);
        addSettings(position, commands, exclamation);
    }

    public static ModeSetting position = new ModeSetting("Position", "Suffix", "Suffix", "Prefix", "Both");
    public static BooleanSetting commands = new BooleanSetting("Commands", false);
    public static BooleanSetting exclamation = new BooleanSetting("Exclamation", false);

    public static String getFirstModifier() {
        if (ModuleManager.isModuleEnabled("Suffix")) {
            if (position.getValue().equals("Suffix")) {
                return "";
            } else {
                return "\u1d00\u1d22\u1d1c\u0280\u1d07 \u226a ";
            }
        } else {
            return "";
        }
    }

    public static String getSecondModifier() {
        if (ModuleManager.isModuleEnabled("Suffix")) {
            if (position.getValue().equals("Prefix")) {
                return "";
            } else {
                return " \u226b \u1d00\u1d22\u1d1c\u0280\u1d07";
            }
        } else {
            return "";
        }
    }
}
