package dev.azure.client.modules.movement;

import dev.azure.client.modules.Category;
import dev.azure.client.modules.Module;
import dev.azure.client.settings.implement.DoubleSetting;

public class Timer extends Module {
    public Timer() {
        super("Timer", "Timer", "Makes your game slower or faster.", Category.MOVEMENT);
        addSettings(speed);
    }

    DoubleSetting speed = new DoubleSetting("Speed", 1.0, 0.1, 5.0);

    public void onEnable() {
        mc.timer.tickLength = (float) (50.0f / speed.getValue());
    }

    public void onDisable() {
        mc.timer.tickLength = 50.0f;
    }
}
