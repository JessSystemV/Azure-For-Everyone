package dev.azure.client.gui.click.buttons.settings;

import dev.azure.client.gui.click.buttons.ModuleButton;
import dev.azure.client.gui.click.implement.Component;
import dev.azure.client.gui.font.FontManager;
import dev.azure.client.modules.client.ColorModule;
import dev.azure.client.settings.implement.ModeSetting;
import dev.azure.client.utilities.render.RenderUtils;
import org.lwjgl.input.Keyboard;

import java.awt.*;

public class BindButton extends Component {
    private boolean hovered;
    private boolean binding;
    private final ModuleButton parent;
    private int offset;
    private int x;
    private int y;

    public BindButton(final ModuleButton parent, final int offset) {
        this.parent = parent;
        this.x = parent.panel.getX();
        this.y = parent.panel.getY() + parent.offset;
        this.offset = offset;
    }

    @Override
    public void renderComponent() {
        RenderUtils.drawRect(getParentX(), getParentY() + offset + 1, getParentX() + getParentWidth(), getParentY() + 14 + offset, new Color(0, 0, 0, 135).getRGB());
        RenderUtils.drawRect(getParentX(), getParentY() + offset, getParentX() + getParentWidth(), getParentY() + 1 + offset, new Color(0, 0, 0, 135).getRGB());
        RenderUtils.drawRect(getParentX() + 2, getParentY() + offset + 1, getParentX() + getParentWidth() - 2, getParentY() + 13 + offset, ColorModule.getColor(35).getRGB());
        FontManager.drawString(binding ? "Key..." : "Key: " + Keyboard.getKeyName(parent.module.getBind()).toUpperCase(), getParentX() + 4, getParentY() + offset + 3, -1);
    }

    @Override
    public void setOffset(final int offset) {
        this.offset = offset;
    }

    @Override
    public void updateComponent(final int mouseX, final int mouseY) {
        hovered = isMouseOnButton(mouseX, mouseY);
        x = parent.panel.getX();
        y = parent.panel.getY() + offset;
    }

    @Override
    public void mouseClicked(final int mouseX, final int mouseY, final int button) {
        if (this.isMouseOnButton(mouseX, mouseY) && button == 0 && this.parent.open) {
            this.binding = !this.binding;
        }
    }

    @Override
    public void keyTyped(final char typedChar, final int key) {
        if (this.binding) {
            if (key == 211) {
                this.parent.module.setBind(0);
            } else {
                if (key == Keyboard.KEY_ESCAPE) {
                    this.binding = false;
                } else {
                    this.parent.module.setBind(key);
                }
            }
            this.binding = false;
        }
    }

    public boolean isMouseOnButton(final int x, final int y) {
        return x > this.x && x < this.x + 90 && y > this.y && y < this.y + 14;
    }

    public int getParentX() {
        return parent.panel.getX();
    }

    public int getParentY() {
        return parent.panel.getY();
    }

    public int getParentWidth() {
        return parent.panel.getWidth();
    }
}
