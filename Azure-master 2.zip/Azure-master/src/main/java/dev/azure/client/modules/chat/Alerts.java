package dev.azure.client.modules.chat;

import dev.azure.client.modules.Category;
import dev.azure.client.modules.Module;
import dev.azure.client.modules.client.CommandModule;
import dev.azure.client.settings.implement.BooleanSetting;
import dev.azure.client.utilities.chat.ChatUtils;
import dev.azure.client.utilities.chat.CommandUtils;
import dev.azure.event.implement.LoginEvent;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderPearl;
import net.minecraft.entity.player.EntityPlayer;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class Alerts extends Module {
    public Alerts() {
        super("Alerts", "Alerts", "Alerts you in chat when a certain event happens.", Category.CHAT);
        addSettings(totems, pearls, visualRange, connections);
    }

    DecimalFormat format = new DecimalFormat("#.#");

    private final List<EntityPlayer> visualRecognizedPlayers = new ArrayList<>();
    private final ConcurrentHashMap<UUID, Integer> pearlRecognizedPlayers = new ConcurrentHashMap<>();

    public static BooleanSetting totems = new BooleanSetting("Totems", false);
    public static BooleanSetting pearls = new BooleanSetting("Pearls", false);
    public static BooleanSetting visualRange = new BooleanSetting("VisualRange", false);
    public static BooleanSetting connections = new BooleanSetting("Connections", false);

    public void onTick() {
        if (visualRange.getValue()) {
            if (mc.world.playerEntities.size() > 0) {
                for (EntityPlayer player : mc.world.playerEntities) {
                    if (player.getName().equals(mc.player.getName()) || visualRecognizedPlayers.contains(player))
                        continue;
                    visualRecognizedPlayers.add(player);
                    ChatUtils.sendMessage(CommandUtils.getPartTwo() + player.getName() + CommandUtils.getPartOne() + " has entered your visual range!", true, 257);
                    return;
                }
            }

            if (visualRecognizedPlayers.size() > 0) {
                for (EntityPlayer player : visualRecognizedPlayers) {
                    if (mc.world.playerEntities.contains(player)) continue;
                    visualRecognizedPlayers.remove(player);
                    ChatUtils.sendMessage(CommandUtils.getPartTwo() + player.getName() + CommandUtils.getPartOne() + " has left your visual range!", true, 257);
                    return;
                }
            }
        }

        if (pearls.getValue()) {
            for (final Entity entity : mc.world.loadedEntityList) {
                if (entity instanceof EntityEnderPearl) {
                    EntityPlayer closest = null;

                    for (final EntityPlayer player : mc.world.playerEntities) {
                        if (closest == null || entity.getDistance(player) < entity.getDistance(closest)) {
                            closest = player;
                        }
                    }

                    if (closest == null || closest.getDistance(entity) >= 2.0f || pearlRecognizedPlayers.containsKey(entity.getUniqueID()) || closest.getName().equals(mc.player.getName())) {
                        continue;
                    }

                    pearlRecognizedPlayers.put(entity.getUniqueID(), 200);
                    ChatUtils.sendMessage(CommandUtils.getPartTwo() + closest.getName() + CommandUtils.getPartOne() + " threw a pearl towards " + CommandUtils.getPartTwo() + getDirectionTitle(entity.getHorizontalFacing().getName()) + CommandUtils.getPartOne() + "!", CommandModule.watermark.getValue(), 258);
                }
            }

            pearlRecognizedPlayers.forEach((name, timeout) -> {
                if (timeout <= 0) {
                    pearlRecognizedPlayers.remove(name);
                } else {
                    pearlRecognizedPlayers.put(name, timeout - 1);
                }
            });
        }
    }

    @SuppressWarnings("unused")
    @EventHandler
    private final Listener<LoginEvent.Connect> onConnect = new Listener<>(event -> {
        if (connections.getValue()) {
            UUID uuid = event.getUuid();
            EntityPlayer entity = mc.world.getPlayerEntityByUUID(uuid);
            if (entity != null) {
                ChatUtils.sendMessage(CommandUtils.getPartTwo() + entity.getName() + CommandUtils.getPartOne() + " just logged in! " + CommandUtils.getPartTwo() + "(" + format.format(entity.posX) + ", " + format.format(entity.posY) + ", " + format.format(entity.posZ) + ")", CommandModule.watermark.getValue(), 259);
            }
        }
    });

    @SuppressWarnings("unused")
    @EventHandler
    private final Listener<LoginEvent.Disconnect> onDisconnect = new Listener<>(event -> {
        if (connections.getValue()) {
            EntityPlayer entity = event.getEntity();
            UUID uuid = event.getUuid();
            String name = event.getName();
            ChatUtils.sendMessage(CommandUtils.getPartTwo() + entity.getName() + CommandUtils.getPartOne() + " just logged out! " + CommandUtils.getPartTwo() + "(" + format.format(entity.posX) + ", " + format.format(entity.posY) + ", " + format.format(entity.posZ) + ")", CommandModule.watermark.getValue(), 295);
        }
    });

    public String getDirectionTitle(final String input) {
        if (input.equalsIgnoreCase("west")) return "east";
        if (input.equalsIgnoreCase("east")) return "west";
        return input;
    }
}