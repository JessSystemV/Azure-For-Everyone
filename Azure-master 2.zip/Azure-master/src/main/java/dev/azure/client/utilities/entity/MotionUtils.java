package dev.azure.client.utilities.entity;

import dev.azure.client.utilities.Utility;
import dev.azure.client.utilities.math.MathUtils;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.potion.Potion;

import java.util.Objects;

public class MotionUtils implements Utility {
    public static boolean isMoving(EntityLivingBase entity) {
        return (entity.moveForward != 0.0F || entity.moveStrafing != 0.0F);
    }

    public static void setSpeed(EntityLivingBase entity, double speed) {
        double[] dir = MathUtils.directionSpeed(speed);
        entity.motionX = dir[0];
        entity.motionZ = dir[1];
    }

    public static double getBaseMoveSpeed() {
        double baseSpeed = 0.2873D;
        if (mc.player != null && mc.player.isPotionActive(Objects.requireNonNull(Potion.getPotionById(1)))) {
            int amplifier = Objects.requireNonNull(mc.player.getActivePotionEffect(Objects.requireNonNull(Potion.getPotionById(1)))).getAmplifier();
            baseSpeed *= 1.0D + 0.2D * (amplifier + 1);
        }
        return baseSpeed;
    }
}
