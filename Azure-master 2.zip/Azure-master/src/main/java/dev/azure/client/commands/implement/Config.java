package dev.azure.client.commands.implement;

import dev.azure.client.commands.Command;
import dev.azure.client.configuration.LoadConfiguration;
import dev.azure.client.configuration.SaveConfiguration;
import dev.azure.client.utilities.chat.ChatUtils;

public class Config extends Command {
    public Config() {
        super("Config", "Saves or loads your configuration.", "config <save|load>", "configuration", "cfg");
    }

    @Override
    public void onCommand(String[] args, String command) {
        if (args.length == 1) {
            if (args[0].equalsIgnoreCase("load")) {
                LoadConfiguration.loadConfig();
                ChatUtils.sendMessage("Successfully loaded configuration!", true);
            } else if (args[0].equalsIgnoreCase("save")) {
                SaveConfiguration.saveConfig();
                ChatUtils.sendMessage("Successfully saved configuration!", true);
            } else {
                ChatUtils.sendMessage(getSyntax(), true);
            }
        } else {
            ChatUtils.sendMessage(getSyntax(), true);
        }
    }
}