package dev.azure.client.modules;

import com.mojang.realmsclient.gui.ChatFormatting;
import dev.azure.client.Azure;
import dev.azure.client.modules.client.CommandModule;
import dev.azure.client.settings.Setting;
import dev.azure.client.settings.implement.BooleanSetting;
import dev.azure.client.utilities.chat.ChatUtils;
import dev.azure.event.implement.RenderEvent;
import me.zero.alpine.listener.Listenable;
import net.minecraft.client.Minecraft;
import net.minecraftforge.common.MinecraftForge;

import java.util.ArrayList;
import java.util.Arrays;

public abstract class Module implements Listenable {
    protected static final Minecraft mc = Minecraft.getMinecraft();
    public ArrayList<Setting> settings = new ArrayList<>();

    public String name;
    public String tag;
    public String description;
    public Category category;
    public boolean enabled;
    public int bind;

    public BooleanSetting drawn = new BooleanSetting("Drawn", false);
    public BooleanSetting toggleMsg = new BooleanSetting("ToggleMSG", false);

    public Module(String name, String tag, String description, Category category) {
        this.name = name;
        this.tag = tag;
        this.description = description;
        this.category = category;
    }

    public boolean isDrawn() {
        return drawn.getValue();
    }

    public void setDrawn(boolean drawn) {
        this.drawn.setValue(drawn);
    }

    public String getName() {
        return name;
    }

    public String getTag() {
        return tag;
    }

    public String getDescription() {
        return description;
    }

    public Category getCategory() {
        return category;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public ArrayList<Setting> getSettings() {
        return settings;
    }

    public void enable() {
        setEnabled(true);
        onEnable();
        doToggleMessage(true);
        subscribe();
    }

    public void disable() {
        setEnabled(false);
        onDisable();
        doToggleMessage(false);
        unsubscribe();
    }

    public void doToggleMessage(boolean enable) {
        if (toggleMsg.getValue()) {
            if (enable) {
                ChatUtils.sendMessage(ChatFormatting.BOLD + getName() + ChatFormatting.GREEN + " enabled!", CommandModule.watermark.getValue());
            } else {
                ChatUtils.sendMessage(ChatFormatting.BOLD + getName() + ChatFormatting.RESET + "" + ChatFormatting.RED + " disabled!", CommandModule.watermark.getValue());
            }
        }
    }

    public void subscribe() {
        Azure.EVENT_BUS.subscribe(this);
        MinecraftForge.EVENT_BUS.register(this);
    }

    public void unsubscribe() {
        Azure.EVENT_BUS.unsubscribe(this);
        MinecraftForge.EVENT_BUS.unregister(this);
    }

    public void toggle() {
        onToggle();

        if (enabled) {
            disable();
        } else {
            enable();
        }
    }

    public int getBind() {
        return bind;
    }

    public void setBind(int bind) {
        this.bind = bind;
    }

    public void onTick() {

    }

    public void onRender() {

    }

    public void onWorldRender(RenderEvent event) {

    }

    public void onLogout() {

    }

    public void onEnable() {

    }

    public void onDisable() {

    }

    public void onToggle() {

    }

    protected void addSettings(Setting... settings) {
        this.settings.addAll(Arrays.asList(settings));

        this.settings.add(drawn);
        this.settings.add(toggleMsg);
    }
}