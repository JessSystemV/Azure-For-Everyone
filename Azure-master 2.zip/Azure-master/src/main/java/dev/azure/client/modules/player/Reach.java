package dev.azure.client.modules.player;

import dev.azure.client.modules.Category;
import dev.azure.client.modules.Module;
import dev.azure.client.settings.implement.DoubleSetting;

public class Reach extends Module {
    public Reach() {
        super("Reach", "Reach", "Increases your reach distance.", Category.PLAYER);
        addSettings(add);
    }

    public static DoubleSetting add = new DoubleSetting("Add", 0.5, 0.0, 3.0);
}
