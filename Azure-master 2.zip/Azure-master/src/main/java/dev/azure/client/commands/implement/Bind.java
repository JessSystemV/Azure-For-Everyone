package dev.azure.client.commands.implement;

import com.mojang.realmsclient.gui.ChatFormatting;
import dev.azure.client.commands.Command;
import dev.azure.client.modules.Module;
import dev.azure.client.modules.ModuleManager;
import dev.azure.client.utilities.chat.ChatUtils;
import dev.azure.client.utilities.chat.CommandUtils;
import org.lwjgl.input.Keyboard;

public class Bind extends Command {
    public Bind() {
        super("Bind", "Binds a module by name.", "bind <name> <key> | clear", "key", "keybind", "b");
    }

    @Override
    public void onCommand(String[] args, String command) {
        if (args.length == 2) {
            String name = args[0];
            String key = args[1];
            boolean found = false;

            for (Module module : ModuleManager.getModules()) {
                if (module.getName().equalsIgnoreCase(name)) {
                    module.setBind(Keyboard.getKeyIndex(key.toUpperCase()));
                    ChatUtils.sendMessage("Bound " + CommandUtils.getPartTwo() + module.getName() + CommandUtils.getPartOne() + " to " + CommandUtils.getPartTwo() + Keyboard.getKeyName(module.getBind()).toUpperCase() + CommandUtils.getPartOne() + ".", true);
                    found = true;
                    break;
                }
            }

            if (!found) {
                ChatUtils.sendMessage("Could not find module.", true);
            }
        } else if (args.length == 1) {
            if (args[0].equalsIgnoreCase("clear")) {
                for (Module module : ModuleManager.getModules()) {
                    module.setBind(Keyboard.KEY_NONE);
                }
                ChatUtils.sendMessage("Successfully cleared all binds.", true);
            } else {
                ChatUtils.sendMessage(getSyntax(), true);
            }
        } else {
            ChatUtils.sendMessage(getSyntax(), true);
        }
    }
}
