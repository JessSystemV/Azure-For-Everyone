package dev.azure.client.configuration;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.azure.client.commands.CommandManager;
import dev.azure.client.gui.font.FontRenderer;
import dev.azure.client.modules.Module;
import dev.azure.client.modules.ModuleManager;
import dev.azure.client.modules.client.FontModule;
import dev.azure.client.settings.Setting;
import dev.azure.client.settings.implement.*;
import dev.azure.client.social.SocialManager;
import sun.font.FontUtilities;

import java.awt.*;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Paths;

public class LoadConfiguration {
    public static final String mainFolder = "Azure/";
    public static final String moduleFolder = "Modules/";
    public static final String clientFolder = "Client/";

    public static void loadConfig() {
        try {
            loadModules();
            loadToggles();
            loadKeybinds();
            loadPrefix();
            loadFriends();
            loadEnemies();
        } catch (IOException exception) {
            exception.printStackTrace();
        }
    }

    private static void loadModules() throws IOException {
        for (Module module : ModuleManager.getModules()) {
            loadDirectModule(mainFolder + moduleFolder + module.getCategory().getLabel() + "/", module);
        }
    }

    private static void loadDirectModule(String moduleLocation, Module module) throws IOException {
        if (!Files.exists(Paths.get(moduleLocation + module.getName() + ".json"))) {
            return;
        }

        InputStream inputStream = Files.newInputStream(Paths.get(moduleLocation + module.getName() + ".json"));
        JsonObject moduleObject;

        try {
            moduleObject = new JsonParser().parse(new InputStreamReader(inputStream)).getAsJsonObject();
        } catch (IllegalStateException exception) {
            return;
        }

        if (moduleObject.get("Module") == null) {
            return;
        }

        JsonObject settingObject = moduleObject.get("Settings").getAsJsonObject();
        for (Setting setting : module.getSettings()) {
            JsonElement dataObject = settingObject.get(setting.getName());
            try {
                if (dataObject != null && dataObject.isJsonPrimitive()) {
                    if (setting instanceof BooleanSetting) {
                        ((BooleanSetting) setting).setValue(dataObject.getAsBoolean());
                    } else if (setting instanceof IntegerSetting) {
                        ((IntegerSetting) setting).setValue(dataObject.getAsInt());
                    } else if (setting instanceof DoubleSetting) {
                        ((DoubleSetting) setting).setValue(dataObject.getAsDouble());
                    } else if (setting instanceof ModeSetting) {
                        ((ModeSetting) setting).setValue(dataObject.getAsString());
                    } else if (setting instanceof StringSetting) {
                        ((StringSetting) setting).setValue(dataObject.getAsString());
                    }
                }
            } catch (NumberFormatException exception) {
                exception.printStackTrace();
            }
        }

        inputStream.close();
    }

    private static void loadToggles() throws IOException {
        String location = mainFolder + clientFolder;
        if (!Files.exists(Paths.get(location + "Modules.json"))) return;
        InputStream inputStream = Files.newInputStream(Paths.get(location + "Modules.json"));
        JsonObject moduleObject = new JsonParser().parse(new InputStreamReader(inputStream)).getAsJsonObject();
        if (moduleObject.get("Modules") == null) return;

        JsonObject enabledObject = moduleObject.get("Modules").getAsJsonObject();
        for (Module module : ModuleManager.getModules()) {
            JsonElement dataObject = enabledObject.get(module.getName());

            if (dataObject != null && dataObject.isJsonPrimitive()) {
                if (dataObject.getAsBoolean()) {
                    try {
                        module.enable();
                    } catch (NullPointerException exception) {
                        exception.printStackTrace();
                    }
                }
            }
        }

        inputStream.close();
    }

    private static void loadKeybinds() throws IOException {
        String location = mainFolder + clientFolder;
        if (!Files.exists(Paths.get(location + "Binds.json"))) return;
        InputStream inputStream = Files.newInputStream(Paths.get(location + "Binds.json"));
        JsonObject moduleObject = new JsonParser().parse(new InputStreamReader(inputStream)).getAsJsonObject();
        if (moduleObject.get("Modules") == null) return;

        JsonObject bindObject = moduleObject.get("Modules").getAsJsonObject();
        for (Module module : ModuleManager.getModules()) {
            JsonElement dataObject = bindObject.get(module.getName());

            if (dataObject != null && dataObject.isJsonPrimitive()) {
                module.setBind(dataObject.getAsInt());
            }
        }

        inputStream.close();
    }

    private static void loadPrefix() throws IOException {
        String location = mainFolder + clientFolder;
        if (!Files.exists(Paths.get(location + "Prefix.json"))) return;
        InputStream inputStream = Files.newInputStream(Paths.get(location + "Prefix.json"));
        JsonObject mainObject = new JsonParser().parse(new InputStreamReader(inputStream)).getAsJsonObject();
        if (mainObject.get("Prefix") == null) return;

        JsonElement prefixObject = mainObject.get("Prefix");
        if (prefixObject != null && prefixObject.isJsonPrimitive()) {
            CommandManager.setPrefix(prefixObject.getAsString());
        }

        inputStream.close();
    }

    private static void loadFriends() throws IOException {
        String location = mainFolder + clientFolder;
        if (!Files.exists(Paths.get(location + "Friends.json"))) return;
        InputStream inputStream = Files.newInputStream(Paths.get(location + "Friends.json"));
        JsonObject mainObject = new JsonParser().parse(new InputStreamReader(inputStream)).getAsJsonObject();
        if (mainObject.get("Friends") == null) return;

        JsonArray friendObject = mainObject.get("Friends").getAsJsonArray();
        friendObject.forEach(friend -> SocialManager.addFriend(friend.getAsString()));

        inputStream.close();
    }

    private static void loadEnemies() throws IOException {
        String location = mainFolder + clientFolder;
        if (!Files.exists(Paths.get(location + "Enemies.json"))) return;
        InputStream inputStream = Files.newInputStream(Paths.get(location + "Enemies.json"));
        JsonObject mainObject = new JsonParser().parse(new InputStreamReader(inputStream)).getAsJsonObject();
        if (mainObject.get("Enemies") == null) return;

        JsonArray enemyObject = mainObject.get("Enemies").getAsJsonArray();
        enemyObject.forEach(enemy -> SocialManager.addEnemy(enemy.getAsString()));

        inputStream.close();
    }

    private static void loadFont() throws IOException {
        String location = mainFolder + clientFolder;
        if (!Files.exists(Paths.get(location + "Font.json"))) return;
        InputStream inputStream = Files.newInputStream(Paths.get(location + "Font.json"));
        JsonObject mainObject = new JsonParser().parse(new InputStreamReader(inputStream)).getAsJsonObject();
        if (mainObject.get("Font") == null) return;

        JsonElement nameObject = mainObject.get("Font");
        if (nameObject != null && nameObject.isJsonPrimitive()) {
            FontRenderer.clientFont.setFont(new Font(nameObject.getAsString(), Font.PLAIN, 18));
            FontRenderer.clientFont.setFractionalMetrics(FontModule.fractionalMetrics.getValue());
            FontRenderer.clientFont.setAntiAlias(FontModule.antiAlias.getValue());
        }
    }
}
