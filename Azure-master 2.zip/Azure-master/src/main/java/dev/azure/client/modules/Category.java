package dev.azure.client.modules;

public enum Category {
    COMBAT("Combat"),
    PLAYER("Player"),
    MOVEMENT("Movement"),
    RENDER("Render"),
    CHAT("Chat"),
    WORLD("World"),
    CLIENT("Client"),
    HUD("HUD");

    public final String label;

    Category(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }
}
