package dev.azure.client.modules.world;

import dev.azure.client.modules.Category;
import dev.azure.client.modules.Module;
import dev.azure.event.Event;
import dev.azure.event.status.Stage;
import dev.azure.event.implement.PacketEvent;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.util.EnumFacing;

public class BuildHeight extends Module {
    public BuildHeight() {
        super("BuildHeight", "Build Height", "Let's you place at the build height.", Category.WORLD);
        addSettings();
    }

    @SuppressWarnings("unused")
    @EventHandler
    private final Listener<PacketEvent.Send> sendListener = new Listener<>(event -> {
        if (event.isPre()) {
            if (event.getPacket() instanceof CPacketPlayerTryUseItemOnBlock) {
                CPacketPlayerTryUseItemOnBlock packet = (CPacketPlayerTryUseItemOnBlock) event.getPacket();
                if (event.getStage() == Stage.PRE && packet.getPos().getY() >= 255 && packet.getDirection() == EnumFacing.UP) {
                    packet.placedBlockDirection = EnumFacing.DOWN;
                }
            }
        }
    });
}
