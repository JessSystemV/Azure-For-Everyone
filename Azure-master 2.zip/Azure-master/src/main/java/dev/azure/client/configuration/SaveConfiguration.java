package dev.azure.client.configuration;

import com.google.gson.*;
import dev.azure.client.commands.CommandManager;
import dev.azure.client.gui.font.FontRenderer;
import dev.azure.client.modules.Module;
import dev.azure.client.modules.ModuleManager;
import dev.azure.client.settings.Setting;
import dev.azure.client.settings.implement.*;
import dev.azure.client.social.SocialManager;
import dev.azure.client.social.implement.Enemy;
import dev.azure.client.social.implement.Friend;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;

public class SaveConfiguration {
    public static final String mainFolder = "Azure/";
    public static final String moduleFolder = "Modules/";
    public static final String clientFolder = "Client/";

    public static final String categoryCombat = "Combat/";
    public static final String categoryPlayer = "Player/";
    public static final String categoryMovement = "Movement/";
    public static final String categoryRender = "Render/";
    public static final String categoryChat = "Chat/";
    public static final String categoryWorld = "World/";
    public static final String categoryClient = "Client/";
    public static final String categoryHud = "HUD/";

    public static void saveConfig() {
        try {
            registerFiles();

            saveModules();
            saveToggles();
            saveKeybinds();
            savePrefix();
            saveFriends();
            saveEnemies();
            saveFont();
        } catch (IOException exception) {
            exception.printStackTrace();
        }
    }

    private static void registerFiles() throws IOException {
        if (!Files.exists(Paths.get(mainFolder))) {
            Files.createDirectories(Paths.get(mainFolder));
        }

        if (!Files.exists(Paths.get(mainFolder + moduleFolder))) {
            Files.createDirectories(Paths.get(mainFolder + moduleFolder));
        }

        if (!Files.exists(Paths.get(mainFolder + clientFolder))) {
            Files.createDirectories(Paths.get(mainFolder + clientFolder));
        }

        if (!Files.exists(Paths.get(mainFolder + moduleFolder + categoryCombat))) {
            Files.createDirectories(Paths.get(mainFolder + moduleFolder + categoryCombat));
        }

        if (!Files.exists(Paths.get(mainFolder + moduleFolder + categoryPlayer))) {
            Files.createDirectories(Paths.get(mainFolder + moduleFolder + categoryPlayer));
        }

        if (!Files.exists(Paths.get(mainFolder + moduleFolder + categoryMovement))) {
            Files.createDirectories(Paths.get(mainFolder + moduleFolder + categoryMovement));
        }

        if (!Files.exists(Paths.get(mainFolder + moduleFolder + categoryRender))) {
            Files.createDirectories(Paths.get(mainFolder + moduleFolder + categoryRender));
        }

        if (!Files.exists(Paths.get(mainFolder + moduleFolder + categoryChat))) {
            Files.createDirectories(Paths.get(mainFolder + moduleFolder + categoryChat));
        }

        if (!Files.exists(Paths.get(mainFolder + moduleFolder + categoryWorld))) {
            Files.createDirectories(Paths.get(mainFolder + moduleFolder + categoryWorld));
        }

        if (!Files.exists(Paths.get(mainFolder + moduleFolder + categoryClient))) {
            Files.createDirectories(Paths.get(mainFolder + moduleFolder + categoryClient));
        }

        if (!Files.exists(Paths.get(mainFolder + moduleFolder + categoryClient))) {
            Files.createDirectories(Paths.get(mainFolder + moduleFolder + categoryClient));
        }

        if (!Files.exists(Paths.get(mainFolder + moduleFolder + categoryHud))) {
            Files.createDirectories(Paths.get(mainFolder + moduleFolder + categoryHud));
        }
    }

    private static void registerFile(String location, String name) throws IOException {
        if (Files.exists(Paths.get(mainFolder + location + name + ".json"))) {
            File file = new File(mainFolder + location + name + ".json");
            file.delete();
        }

        Files.createFile(Paths.get(mainFolder + location + name + ".json"));
    }

    private static void saveModules() throws IOException {
        for (Module module : ModuleManager.getModules()) {
            saveDirectModule(module);
        }
    }

    private static void saveDirectModule(Module module) throws IOException {
        registerFile(moduleFolder + module.getCategory().getLabel() + "/", module.getName());

        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        OutputStreamWriter fileOutputStreamWriter = new OutputStreamWriter(new FileOutputStream(mainFolder + moduleFolder + module.getCategory().getLabel() + "/" + module.getName() + ".json"), StandardCharsets.UTF_8);
        JsonObject moduleObject = new JsonObject();
        JsonObject settingObject = new JsonObject();
        moduleObject.add("Module", new JsonPrimitive(module.getName()));

        for (Setting setting : module.getSettings()) {
            if (setting instanceof BooleanSetting) {
                settingObject.add(setting.getName(), new JsonPrimitive(((BooleanSetting) setting).getValue()));
            } else if (setting instanceof IntegerSetting) {
                settingObject.add(setting.getName(), new JsonPrimitive(((IntegerSetting) setting).getValue()));
            } else if (setting instanceof DoubleSetting) {
                settingObject.add(setting.getName(), new JsonPrimitive(((DoubleSetting) setting).getValue()));
            } else if (setting instanceof ModeSetting) {
                settingObject.add(setting.getName(), new JsonPrimitive(((ModeSetting) setting).getValue()));
            } else if (setting instanceof StringSetting) {
                settingObject.add(setting.getName(), new JsonPrimitive(((StringSetting) setting).getValue()));
            }
        }

        moduleObject.add("Settings", settingObject);
        String jsonString = gson.toJson(new JsonParser().parse(moduleObject.toString()));
        fileOutputStreamWriter.write(jsonString);
        fileOutputStreamWriter.close();
    }

    private static void saveToggles() throws IOException {
        registerFile(clientFolder, "Modules");

        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        OutputStreamWriter fileOutputStreamWriter = new OutputStreamWriter(new FileOutputStream(mainFolder + clientFolder + "Modules.json"), StandardCharsets.UTF_8);
        JsonObject moduleObject = new JsonObject();
        JsonObject enabledObject = new JsonObject();

        for (Module module : ModuleManager.getModules()) {
            enabledObject.add(module.getName(), new JsonPrimitive(module.isEnabled()));
        }

        moduleObject.add("Modules", enabledObject);
        String jsonString = gson.toJson(new JsonParser().parse(moduleObject.toString()));
        fileOutputStreamWriter.write(jsonString);
        fileOutputStreamWriter.close();
    }

    private static void saveKeybinds() throws IOException {
        registerFile(clientFolder, "Binds");

        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        OutputStreamWriter fileOutputStreamWriter = new OutputStreamWriter(new FileOutputStream(mainFolder + clientFolder + "Binds.json"), StandardCharsets.UTF_8);
        JsonObject moduleObject = new JsonObject();
        JsonObject bindObject = new JsonObject();

        for (Module module : ModuleManager.getModules()) {
            bindObject.add(module.getName(), new JsonPrimitive(module.getBind()));
        }

        moduleObject.add("Modules", bindObject);
        String jsonString = gson.toJson(new JsonParser().parse(moduleObject.toString()));
        fileOutputStreamWriter.write(jsonString);
        fileOutputStreamWriter.close();
    }

    private static void savePrefix() throws IOException {
        registerFile(clientFolder, "Prefix");

        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        OutputStreamWriter fileOutputStreamWriter = new OutputStreamWriter(new FileOutputStream(mainFolder + clientFolder + "Prefix.json"), StandardCharsets.UTF_8);
        JsonObject bindObject = new JsonObject();

        bindObject.add("Prefix", new JsonPrimitive(CommandManager.getPrefix()));

        String jsonString = gson.toJson(new JsonParser().parse(bindObject.toString()));
        fileOutputStreamWriter.write(jsonString);
        fileOutputStreamWriter.close();
    }

    private static void saveFriends() throws IOException {
        registerFile(clientFolder, "Friends");

        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        OutputStreamWriter fileOutputStreamWriter = new OutputStreamWriter(new FileOutputStream(mainFolder + clientFolder + "Friends.json"), StandardCharsets.UTF_8);
        JsonObject mainObject = new JsonObject();
        JsonArray friendArray = new JsonArray();

        for (Friend friend : SocialManager.getFriends()) {
            friendArray.add(friend.getName());
        }

        mainObject.add("Friends", friendArray);
        String jsonString = gson.toJson(new JsonParser().parse(mainObject.toString()));
        fileOutputStreamWriter.write(jsonString);
        fileOutputStreamWriter.close();
    }

    private static void saveEnemies() throws IOException {
        registerFile(clientFolder, "Enemies");

        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        OutputStreamWriter fileOutputStreamWriter = new OutputStreamWriter(new FileOutputStream(mainFolder + clientFolder + "Enemies.json"), StandardCharsets.UTF_8);
        JsonObject mainObject = new JsonObject();
        JsonArray enemyArray = new JsonArray();

        for (Enemy enemy : SocialManager.getEnemies()) {
            enemyArray.add(enemy.getName());
        }

        mainObject.add("Enemies", enemyArray);
        String jsonString = gson.toJson(new JsonParser().parse(mainObject.toString()));
        fileOutputStreamWriter.write(jsonString);
        fileOutputStreamWriter.close();
    }

    private static void saveFont() throws IOException {
        registerFile(clientFolder, "Font");

        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        OutputStreamWriter fileOutputStreamWriter = new OutputStreamWriter(new FileOutputStream(mainFolder + clientFolder + "Font.json"), StandardCharsets.UTF_8);
        JsonObject fontObject = new JsonObject();

        fontObject.add("Font", new JsonPrimitive(FontRenderer.clientFont.getFont().getName()));

        String jsonString = gson.toJson(new JsonParser().parse(fontObject.toString()));
        fileOutputStreamWriter.write(jsonString);
        fileOutputStreamWriter.close();
    }
}
