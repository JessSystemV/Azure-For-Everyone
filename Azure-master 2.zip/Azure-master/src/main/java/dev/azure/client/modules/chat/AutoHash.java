package dev.azure.client.modules.chat;

import dev.azure.client.modules.Category;
import dev.azure.client.modules.Module;
import dev.azure.client.modules.ModuleManager;

public class AutoHash extends Module {
    public AutoHash() {
        super("AutoHash", "Auto Hash", "Automatically puts a hash at the end of your message.", Category.CHAT);
        addSettings();
    }

    public static String getHash() {
        if (ModuleManager.isModuleEnabled("AutoHash")) {
            String chars = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
            StringBuilder randomChars = new StringBuilder();

            int var4 = 31;
            for (int var3 = 0; var3 <= var4; var3 += 2) {
                randomChars.append(chars.charAt((int) Math.floor(Math.random() * (double) chars.length())));
            }

            return " - " + randomChars;
        } else {
            return "";
        }
    }
}
