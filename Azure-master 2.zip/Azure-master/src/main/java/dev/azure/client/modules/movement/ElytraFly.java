package dev.azure.client.modules.movement;

import dev.azure.client.modules.Category;
import dev.azure.client.modules.Module;
import dev.azure.client.settings.implement.DoubleSetting;
import dev.azure.client.utilities.math.MathUtils;
import dev.azure.event.implement.MotionEvent;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;

public class ElytraFly extends Module {
    public ElytraFly() {
        super("ElytraFly", "Elytra Fly", "Makes flying with the Elytra easier.", Category.MOVEMENT);
        addSettings(horizontal, vertical);
    }

    private double elytraX = 0;
    private double elytraY = 0;
    private double elytraZ = 0;

    DoubleSetting horizontal = new DoubleSetting("Horizontal", 5.0, 0.1, 10.0);
    DoubleSetting vertical = new DoubleSetting("Vertical", 2.0, 0.1, 10.0);

    @SuppressWarnings("unused")
    @EventHandler
    private final Listener<MotionEvent> onMotion = new Listener<>(event -> {
        final double[] direction = MathUtils.directionSpeed(horizontal.getValue());
        if (mc.player.isElytraFlying()) {
            if (elytraX == 0) elytraX = mc.player.posX;
            if (elytraY == 0) elytraY = mc.player.posY;
            if (elytraZ == 0) elytraZ = mc.player.posZ;

            if (mc.player.movementInput.moveStrafe != 0.0f || mc.player.movementInput.moveForward != 0.0f) {
                elytraX = mc.player.posX + (direction[0] / 2);
                elytraZ = mc.player.posZ + (direction[1] / 2);
            }

            if (mc.gameSettings.keyBindJump.isKeyDown()) elytraY = mc.player.posY + vertical.getValue();
            if (mc.gameSettings.keyBindSneak.isKeyDown()) elytraY = mc.player.posY - vertical.getValue();

            mc.player.setPosition(elytraX, elytraY, elytraZ);
            mc.player.setVelocity(0.0, 0.0, 0.0);
        }

        elytraX = mc.player.posX;
        elytraY = mc.player.posY;
        elytraZ = mc.player.posZ;
    });

    public void onDisable() {
        elytraX = 0;
        elytraY = 0;
        elytraZ = 0;
    }
}
