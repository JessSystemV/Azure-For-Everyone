package dev.azure.client.modules.movement;

import dev.azure.client.modules.Category;
import dev.azure.client.modules.Module;
import dev.azure.client.settings.implement.DoubleSetting;

public class ReverseStep extends Module {
    public ReverseStep() {
        super("ReverseStep", "Reverse Step", "Makes you fall faster.", Category.MOVEMENT);
        addSettings(height);
    }

    DoubleSetting height = new DoubleSetting("Height", 2.5, 0.5, 5);

    public void onTick() {
        if (mc.world == null || mc.player == null || mc.player.isInWater() || mc.player.isInLava() || mc.player.isOnLadder() || mc.gameSettings.keyBindJump.isKeyDown()) {
            return;
        }

        if (mc.player != null && mc.player.onGround && !mc.player.isInWater() && !mc.player.isOnLadder()) {
            for (double y = 0.0; y < height.getValue() + 0.5; y += 0.01) {
                if (!mc.world.getCollisionBoxes(mc.player, mc.player.getEntityBoundingBox().offset(0.0, -y, 0.0)).isEmpty()) {
                    mc.player.motionY = -10.0;
                    break;
                }
            }
        }
    }
}
