package dev.azure.client.modules.render;

import dev.azure.client.modules.Category;
import dev.azure.client.modules.Module;
import dev.azure.client.settings.implement.DoubleSetting;

public class ItemPhysics extends Module {
    public ItemPhysics() {
        super("ItemPhysics", "Item Physics", "Make dropped items have physics.", Category.RENDER);
        addSettings(scale);
    }

    public static DoubleSetting scale = new DoubleSetting("Scale", 0.5, 0.1, 10.0);
}
