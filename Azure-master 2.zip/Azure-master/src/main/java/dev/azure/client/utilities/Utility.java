package dev.azure.client.utilities;

import net.minecraft.client.Minecraft;

public interface Utility {
    Minecraft mc = Minecraft.getMinecraft();
}
