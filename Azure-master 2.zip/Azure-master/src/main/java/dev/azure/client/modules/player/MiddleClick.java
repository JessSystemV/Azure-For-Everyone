package dev.azure.client.modules.player;

import dev.azure.client.modules.Category;
import dev.azure.client.modules.Module;
import dev.azure.client.settings.implement.ModeSetting;
import dev.azure.client.social.SocialManager;
import dev.azure.client.utilities.chat.ChatUtils;
import dev.azure.client.utilities.chat.CommandUtils;
import dev.azure.client.utilities.entity.InventoryUtils;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.ItemEnderPearl;
import net.minecraft.util.math.RayTraceResult;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import org.lwjgl.input.Mouse;

public class MiddleClick extends Module {
    public MiddleClick() {
        super("MiddleClick", "Middle Click", "Makes something happen when you click.", Category.PLAYER);
        addSettings(mode);
    }

    ModeSetting mode = new ModeSetting("Mode", "Friends", "Friends", "Pearl", "Both");

    @SuppressWarnings("unused")
    @EventHandler
    private final Listener<InputEvent.MouseInputEvent> onMouseInput = new Listener<>(event -> {
        if (mode.getValue().equalsIgnoreCase("Friends") || mode.getValue().equalsIgnoreCase("Both")) {
            if (mc.objectMouseOver.typeOfHit.equals(RayTraceResult.Type.ENTITY) && mc.objectMouseOver.entityHit instanceof EntityPlayer && Mouse.isButtonDown(2)) {
                if (SocialManager.isFriend(mc.objectMouseOver.entityHit.getName())) {
                    SocialManager.removeFriend(mc.objectMouseOver.entityHit.getName());
                    ChatUtils.sendMessage(CommandUtils.getPartTwo() + mc.objectMouseOver.entityHit.getName() + CommandUtils.getPartOne() + " has been unfriended!", true);
                } else {
                    SocialManager.addFriend(mc.objectMouseOver.entityHit.getName());
                    ChatUtils.sendMessage(CommandUtils.getPartTwo() + mc.objectMouseOver.entityHit.getName() + CommandUtils.getPartOne() + " has been friended!", true);
                }
            }
        }

        if (mode.getValue().equalsIgnoreCase("Pearl") || mode.getValue().equalsIgnoreCase("Both")) {
            RayTraceResult.Type type = mc.objectMouseOver.typeOfHit;

            if (type.equals(RayTraceResult.Type.MISS) && Mouse.isButtonDown(2)) {
                int oldSlot = mc.player.inventory.currentItem;
                int pearlSlot = InventoryUtils.findItem(Items.ENDER_PEARL, 36, 45);

                if (pearlSlot != -1) {
                    mc.player.inventory.currentItem = pearlSlot;
                    mc.rightClickMouse();
                    mc.player.inventory.currentItem = oldSlot;
                }
            }
        }
    });
}
