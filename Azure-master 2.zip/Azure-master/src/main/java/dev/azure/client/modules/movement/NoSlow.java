package dev.azure.client.modules.movement;

import dev.azure.client.gui.click.ClickGUI;
import dev.azure.client.modules.Category;
import dev.azure.client.modules.Module;
import dev.azure.client.settings.implement.BooleanSetting;
import dev.azure.client.settings.implement.DoubleSetting;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.client.gui.*;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.item.ItemShield;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.client.event.InputUpdateEvent;
import org.lwjgl.input.Keyboard;

public class NoSlow extends Module {
    public NoSlow() {
        super("NoSlow", "No Slow", "Removes the slowness effects from certain things.", Category.MOVEMENT);
        addSettings(guiMove, items, soulSand, endPortals, webs, webSpeed);
    }

    public static BooleanSetting guiMove = new BooleanSetting("GUIMove", true);
    public static BooleanSetting items = new BooleanSetting("Items", true);
    public static BooleanSetting soulSand = new BooleanSetting("SoulSand", true);
    public static BooleanSetting endPortals = new BooleanSetting("EndPortals", true);
    public static BooleanSetting webs = new BooleanSetting("Webs", false);
    public static DoubleSetting webSpeed = new DoubleSetting("WebSpeed", 2.0, 0.0, 100.0);

    public void onTick() {
        if (guiMove.getValue()) {
            if (mc.currentScreen instanceof GuiChat) return;

            if (mc.currentScreen != null) {
                if (Keyboard.isKeyDown(200)) {
                    updateRotationPitch(-5.0f);
                }

                if (Keyboard.isKeyDown(208)) {
                    updateRotationPitch(5.0f);
                }

                if (Keyboard.isKeyDown(205)) {
                    updateRotationYaw(5.0f);
                }

                if (Keyboard.isKeyDown(203)) {
                    updateRotationYaw(-5.0f);
                }
            }

            if (mc.currentScreen instanceof GuiOptions || mc.currentScreen instanceof GuiVideoSettings || mc.currentScreen instanceof GuiScreenOptionsSounds || mc.currentScreen instanceof GuiContainer || mc.currentScreen instanceof GuiIngameMenu || mc.currentScreen instanceof ClickGUI) {
                for (KeyBinding bind : new KeyBinding[]{mc.gameSettings.keyBindForward, mc.gameSettings.keyBindBack, mc.gameSettings.keyBindLeft, mc.gameSettings.keyBindRight, mc.gameSettings.keyBindJump, mc.gameSettings.keyBindSprint}) {
                    KeyBinding.setKeyBindState(bind.getKeyCode(), Keyboard.isKeyDown(bind.getKeyCode()));
                }
            } else if (mc.currentScreen == null) {
                for (KeyBinding bind : new KeyBinding[]{mc.gameSettings.keyBindForward, mc.gameSettings.keyBindBack, mc.gameSettings.keyBindLeft, mc.gameSettings.keyBindRight, mc.gameSettings.keyBindJump, mc.gameSettings.keyBindSprint}) {
                    if (Keyboard.isKeyDown(bind.getKeyCode())) continue;
                    KeyBinding.setKeyBindState(bind.getKeyCode(), false);
                }
            }
        }

        if (mc.player.isHandActive()) {
            if (mc.player.getHeldItem(mc.player.getActiveHand()).getItem() instanceof ItemShield) {
                if (mc.player.movementInput.moveStrafe != 0 || mc.player.movementInput.moveForward != 0 && mc.player.getItemInUseMaxCount() >= 8) {
                    mc.player.connection.sendPacket(new CPacketPlayerDigging(CPacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, mc.player.getHorizontalFacing()));
                }
            }
        }

        if (webs.getValue() && mc.player.isInWeb) {
            mc.player.motionX *= webSpeed.getValue();
            mc.player.motionY *= webSpeed.getValue();
            mc.player.motionZ *= webSpeed.getValue();
        }
    }

    public static void updateRotationPitch(float amount) {
        float rotation = mc.player.rotationPitch + amount;

        rotation = Math.max(rotation, -90.0f);
        rotation = Math.min(rotation, 90.0f);

        mc.player.rotationPitch = rotation;
    }

    public static void updateRotationYaw(float amount) {
        mc.player.rotationYaw = mc.player.rotationYaw + amount;
    }

    @SuppressWarnings("unused")
    @EventHandler
    private final Listener<InputUpdateEvent> inputListener = new Listener<>(event -> {
        if (items.getValue() && mc.player.isHandActive() && !mc.player.isRiding()) {
            event.getMovementInput().moveStrafe *= 5;
            event.getMovementInput().moveForward *= 5;
        }
    });
}
