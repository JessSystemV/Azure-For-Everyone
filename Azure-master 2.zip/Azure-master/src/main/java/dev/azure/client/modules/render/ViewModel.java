package dev.azure.client.modules.render;

import dev.azure.client.modules.Category;
import dev.azure.client.modules.Module;
import dev.azure.client.settings.implement.BooleanSetting;
import dev.azure.client.settings.implement.DoubleSetting;
import dev.azure.client.settings.implement.IntegerSetting;
import dev.azure.client.settings.implement.ModeSetting;

public class ViewModel extends Module {
    public ViewModel() {
        super("ViewModel", "View Model", "Let's you change the items position on your screen.", Category.RENDER);
        addSettings(selection, eatPause, alpha, sizeX, sizeY, sizeZ, posX, posY, posZ, rotationX, rotationY, rotationZ);
    }

    public static ModeSetting selection = new ModeSetting("Selection", "Both", "Mainhand", "Offhand", "Both");
    public static BooleanSetting eatPause = new BooleanSetting("EatPause", false);
    public static IntegerSetting alpha = new IntegerSetting("Alpha", 255, 0, 255);

    public static DoubleSetting sizeX = new DoubleSetting("SizeX", 1.0, 0.0, 5.0);
    public static DoubleSetting sizeY = new DoubleSetting("SizeY", 1.0, 0.0, 5.0);
    public static DoubleSetting sizeZ = new DoubleSetting("SizeZ", 1.0, 0.0, 5.0);

    public static DoubleSetting posX = new DoubleSetting("PositionX", 0.0, -2.0, 2.0);
    public static DoubleSetting posY = new DoubleSetting("PositionY", 0.0, -2.0, 2.0);
    public static DoubleSetting posZ = new DoubleSetting("PositionZ", 0.0, -2.0, 2.0);

    public static DoubleSetting rotationX = new DoubleSetting("RotationX", 1.0, 0.0, 2.0);
    public static DoubleSetting rotationY = new DoubleSetting("RotationY", 1.0, 0.0, 2.0);
    public static DoubleSetting rotationZ = new DoubleSetting("RotationZ", 1.0, 0.0, 2.0);

    public static boolean isRight(boolean offhand) {
        if (selection.equals("Mainhand")) {
            return !offhand;
        } else if (selection.equals("Offhand")) {
            return offhand;
        } else {
            return selection.equals("Both");
        }
    }
}
