package dev.azure.client.settings.implement;

import dev.azure.client.modules.Module;
import dev.azure.client.settings.Setting;

import java.util.Arrays;
import java.util.List;

public class ModeSetting extends Setting {
    private String value;
    private final List<String> modes;

    public ModeSetting(String name, String value, String... modes) {
        super(name, true);
        this.value = value;
        this.modes = Arrays.asList(modes);
    }

    public ModeSetting(String name, String value, boolean visible, String... modes) {
        super(name, visible);
        this.value = value;
        this.modes = Arrays.asList(modes);
    }

    public String getValue() {
        return value;
    }

    public void setValue(final String value) {
        this.value = value;
    }

    public boolean equals(String value) {
        return this.value.equalsIgnoreCase(value);
    }

    public List<String> getModes() {
        return modes;
    }
}
