package dev.azure.client.modules.client;

import dev.azure.client.modules.Category;
import dev.azure.client.modules.Module;
import dev.azure.client.settings.implement.BooleanSetting;
import dev.azure.client.settings.implement.ModeSetting;
import dev.azure.client.settings.implement.StringSetting;

public class CommandModule extends Module {
    public CommandModule() {
        super("Commands", "Commands", "Let's you customize how the chat sending works.", Category.CLIENT);
        addSettings(watermark, watermarkColor, watermarkLight, partOneColor, partOneLight, partTwoColor, partTwoLight, symbolOne, symbolTwo, symbolColor, symbolLight);
    }

    public static BooleanSetting watermark = new BooleanSetting("Watermark", true);
    public static ModeSetting watermarkColor = new ModeSetting("WatermarkColor", "Blue", "Black", "Blue", "Green", "Aqua", "Red", "Purple", "Yellow", "Gray");
    public static BooleanSetting watermarkLight = new BooleanSetting("WatermarkLight", true);

    public static ModeSetting partOneColor = new ModeSetting("PartOneColor", "White", "Black", "Blue", "Green", "Aqua", "Red", "Purple", "Yellow", "Gray");
    public static BooleanSetting partOneLight = new BooleanSetting("PartOneLight", false);

    public static ModeSetting partTwoColor = new ModeSetting("PartTwoColor", "Blue", "Black", "Blue", "Green", "Aqua", "Red", "Purple", "Yellow", "Gray");
    public static BooleanSetting partTwoLight = new BooleanSetting("PartTwoLight", false);

    public static StringSetting symbolOne = new StringSetting("SymbolOne", "<");
    public static StringSetting symbolTwo = new StringSetting("SymbolTwo", ">");

    public static ModeSetting symbolColor = new ModeSetting("SymbolColor", "Gray", "Black", "Blue", "Green", "Aqua", "Red", "Purple", "Yellow", "Gray");
    public static BooleanSetting symbolLight = new BooleanSetting("SymbolLight", false);
}
