package dev.azure.client.utilities.entity;

import dev.azure.client.utilities.Utility;
import net.minecraft.block.Block;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketHeldItemChange;

public class InventoryUtils implements Utility {
    public static int findItem(Item item, int minimum, int maximum) {
        for (int i = minimum; i <= maximum; i++) {
            ItemStack stack = mc.player.inventory.getStackInSlot(i);
            if (stack.getItem() == item) {
                return i;
            }
        }

        return -1;
    }

    public static int findWindowItem(Item item, int minimum, int maximum) {
        for (int i = minimum; i <= maximum; i++) {
            ItemStack stack = mc.player.inventoryContainer.getSlot(i).getStack();
            if (stack.getItem() == item) {
                return i;
            }
        }

        return -1;
    }

    public static int findWindowItem(Item item, int count, int minimum, int maximum) {
        for (int i = minimum; i <= maximum; i++) {
            ItemStack stack = mc.player.inventoryContainer.getSlot(i).getStack();
            if (stack.getItem() == item && stack.getCount() >= count) {
                return i;
            }
        }

        return -1;
    }

    public static int findBlock(Block block, int minimum, int maximum) {
        for (int i = minimum; i <= maximum; i++) {
            ItemStack stack = mc.player.inventory.getStackInSlot(i);
            if (stack.getItem() instanceof ItemBlock) {
                ItemBlock item = (ItemBlock) stack.getItem();
                if (item.getBlock() == block) {
                    return i;
                }
            }
        }

        return -1;
    }

    public static void switchToSlot(final int slot) {
        mc.player.connection.sendPacket(new CPacketHeldItemChange(slot));
        mc.player.inventory.currentItem = slot;
        mc.playerController.updateController();
    }
}
