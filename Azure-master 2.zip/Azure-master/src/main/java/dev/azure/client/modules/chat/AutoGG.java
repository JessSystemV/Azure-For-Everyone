package dev.azure.client.modules.chat;

import dev.azure.client.modules.Category;
import dev.azure.client.modules.Module;
import dev.azure.client.settings.implement.ModeSetting;
import dev.azure.client.settings.implement.StringSetting;
import dev.azure.event.implement.PacketEvent;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.play.client.CPacketChatMessage;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraftforge.event.entity.living.LivingDeathEvent;

import java.util.concurrent.ConcurrentHashMap;

public class AutoGG extends Module {
    public AutoGG() {
        super("AutoGG", "Auto GG", "Sends a message automatically when you kill someone.", Category.CHAT);
        addSettings(mode, message);
    }

    int delay = 0;
    private static final ConcurrentHashMap<String, Integer> targets = new ConcurrentHashMap<>();

    ModeSetting mode = new ModeSetting("Mode", "Normal", "Normal", "Custom");
    StringSetting message = new StringSetting("Message", "You just got destroyed by Azure, playername!");

    public void onTick() {
        for (Entity entity : mc.world.loadedEntityList) {
            if (entity instanceof EntityPlayer) {
                EntityPlayer player = (EntityPlayer) entity;
                if (player.getHealth() <= 0 && targets.containsKey(player.getName())) {
                    announce(player.getName());
                }
            }
        }

        targets.forEach((name, timeout) -> {
            if (timeout <= 0) {
                targets.remove(name);
            } else {
                targets.put(name, timeout - 1);
            }
        });

        delay++;
    }

    public void announce(String name) {
        if (delay < 150) return;

        delay = 0;
        targets.remove(name);
        String message;

        if (mode.getValue().equals("Custom")) {
            String temp = this.message.getValue();
            temp = temp.replace("playername", name);
            message = temp;
        } else {
            message = "You just got destroyed by Azure, " + name + "!";
        }

        mc.player.connection.sendPacket(new CPacketChatMessage(message));
    }

    @SuppressWarnings("unused")
    @EventHandler
    private final Listener<LivingDeathEvent> deathListener = new Listener<>(event -> {
        if (mc.player == null) return;

        EntityLivingBase entity = event.getEntityLiving();
        if (entity == null) return;

        if (entity instanceof EntityPlayer) {
            EntityPlayer player = (EntityPlayer) entity;

            if (player.getHealth() <= 0) {
                if (targets.containsKey(player.getName())) {
                    announce(player.getName());
                }
            }
        }
    });

    @SuppressWarnings("unused")
    @EventHandler
    private final Listener<PacketEvent.Send> sendListener = new Listener<>(event -> {
        if (event.isPre()) {
            if (mc.player == null) return;

            if (event.getPacket() instanceof CPacketUseEntity) {
                CPacketUseEntity packet = (CPacketUseEntity) event.getPacket();
                if (packet.getAction().equals(CPacketUseEntity.Action.ATTACK)) {
                    Entity target = packet.getEntityFromWorld(mc.world);
                    if (target instanceof EntityPlayer) {
                        targets.put(target.getName(), 20);
                    }
                }
            }
        }
    });
}
