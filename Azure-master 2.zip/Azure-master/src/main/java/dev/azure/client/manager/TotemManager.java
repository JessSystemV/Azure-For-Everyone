package dev.azure.client.manager;

import dev.azure.client.modules.ModuleManager;
import dev.azure.client.modules.chat.Alerts;
import dev.azure.client.modules.client.CommandModule;
import dev.azure.client.utilities.Utility;
import dev.azure.client.utilities.chat.ChatUtils;
import dev.azure.client.utilities.chat.CommandUtils;
import net.minecraft.entity.player.EntityPlayer;

import java.util.ConcurrentModificationException;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class TotemManager implements Utility {
    private static Map<EntityPlayer, Integer> popList = new ConcurrentHashMap<>();
    private static final Set<EntityPlayer> toAnnounce = new HashSet<>();

    public static void onTick() {
        try {
            if (ModuleManager.isModuleEnabled("Alerts")) {
                if (Alerts.totems.getValue()) {
                    for (EntityPlayer player : toAnnounce) {
                        if (player == null) continue;
                        int playerNumber = 1;
                        for (char character : player.getName().toCharArray()) {
                            playerNumber += character;
                            playerNumber *= 10;
                        }
                        ChatUtils.sendMessage(CommandUtils.getPartTwo() + player.getName() + CommandUtils.getPartOne() + " popped " + CommandUtils.getPartTwo() + getTotemPops(player) + CommandUtils.getPartOne() + " totems!", CommandModule.watermark.getValue(), 256 - playerNumber);
                        toAnnounce.remove(player);
                        break;
                    }
                }
            }
        } catch (ConcurrentModificationException exception) {
            exception.printStackTrace();
        }
    }

    public static void onLogout() {
        onOwnLogout(true);
    }

    public static void onTotemPop(EntityPlayer player) {
        popTotem(player);
        if (!player.equals(mc.player)) {
            toAnnounce.add(player);
        }
    }

    public static void onDeath(EntityPlayer player) {
        if (ModuleManager.isModuleEnabled("Alerts")) {
            if (Alerts.totems.getValue()) {
                if (getTotemPops(player) != 0 && !player.equals(mc.player)) {
                    int playerNumber = 1;
                    for (char character : player.getName().toCharArray()) {
                        playerNumber += character;
                        playerNumber *= 10;
                    }
                    ChatUtils.sendMessage(CommandUtils.getPartTwo() + player.getName() + CommandUtils.getPartOne() + " died after popping " + CommandUtils.getPartTwo() + getTotemPops(player) + CommandUtils.getPartOne() + " totems!", CommandModule.watermark.getValue(), playerNumber);
                    toAnnounce.remove(player);
                }
                resetPops(player);
            }
        }
    }

    public static void onLogout(EntityPlayer player, boolean clearOnLogout) {
        if (clearOnLogout) {
            resetPops(player);
        }
    }

    public static void onOwnLogout(boolean clearOnLogout) {
        if (clearOnLogout) {
            clearList();
        }
    }

    public static void clearList() {
        popList = new ConcurrentHashMap<>();
    }

    public static Map<EntityPlayer, Integer> getPopList() {
        return popList;
    }

    public static void resetPops(EntityPlayer player) {
        setTotemPops(player, 0);
    }

    public static void popTotem(EntityPlayer player) {
        popList.merge(player, 1, Integer::sum);
    }

    public static void setTotemPops(EntityPlayer player, int amount) {
        popList.put(player, amount);
    }

    public static int getTotemPops(EntityPlayer player) {
        Integer pops = popList.get(player);
        if (pops == null) {
            return 0;
        }
        return pops;
    }
}