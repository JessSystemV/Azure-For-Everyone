package dev.azure.client.modules.movement;

import dev.azure.client.modules.Category;
import dev.azure.client.modules.Module;
import dev.azure.client.settings.implement.BooleanSetting;
import dev.azure.event.implement.PacketEvent;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayer;

import java.util.concurrent.ConcurrentLinkedQueue;

public class Blink extends Module {
    public Blink() {
        super("Blink", "Blink", "Let's you move around freely without others seeing you, while also teleporting you after you're done.", Category.MOVEMENT);
        addSettings(ghostPlayer);
    }

    private EntityOtherPlayerMP entity;
    private final ConcurrentLinkedQueue<Packet<?>> packets = new ConcurrentLinkedQueue<>();

    BooleanSetting ghostPlayer = new BooleanSetting("GhostPlayer", true);

    public void onEnable() {
        if (mc.player == null || mc.world == null) {
            disable();
        } else if (ghostPlayer.getValue()) {
            entity = new EntityOtherPlayerMP(mc.world, mc.getSession().getProfile());
            entity.copyLocationAndAnglesFrom(mc.player);
            entity.inventory.copyInventory(mc.player.inventory);
            entity.rotationYaw = mc.player.rotationYaw;
            entity.rotationYawHead = mc.player.rotationYawHead;
            mc.world.addEntityToWorld(667, entity);
        }
    }

    public void onTick() {
        if (!ghostPlayer.getValue() && entity != null && mc.world != null) {
            mc.world.removeEntity(entity);
        }
    }

    public void onDisable() {
        if (entity != null && mc.world != null) {
            mc.world.removeEntity(entity);
        }

        if (packets.size() > 0 && mc.player != null) {
            for (Packet<?> packet : packets) {
                mc.player.connection.sendPacket(packet);
            }

            packets.clear();
        }
    }

    @SuppressWarnings("unused")
    @EventHandler
    private final Listener<PacketEvent.Send> sendListener = new Listener<>(event -> {
        if (mc.player != null && mc.player.isEntityAlive() && event.getPacket() instanceof CPacketPlayer) {
            packets.add(event.getPacket());
            event.setCancelled(true);
        }
    });
}
