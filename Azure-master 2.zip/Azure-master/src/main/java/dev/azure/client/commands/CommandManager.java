package dev.azure.client.commands;

import dev.azure.client.commands.implement.*;

import java.util.ArrayList;

public class CommandManager {
    public static String prefix = ".";
    public static ArrayList<Command> commands;

    public void initialize() {
        commands = new ArrayList<>();

        commands.add(new Set());
        commands.add(new Toggle());
        commands.add(new Prefix());
        commands.add(new Config());
        commands.add(new Bind());
        commands.add(new FriendCommand());
        commands.add(new EnemyCommand());
        commands.add(new Totems());
    }

    public static ArrayList<Command> getCommands() {
        return commands;
    }

    public static String getPrefix() {
        return prefix;
    }

    public static void setPrefix(String prefix) {
        CommandManager.prefix = prefix;
    }
}
