package dev.azure.client.utilities.entity;

import dev.azure.client.utilities.Utility;

public class PositionUtils implements Utility {
    private static double x;
    private static double y;
    private static double z;
    private static boolean onGround;

    public static void updatePosition() {
        x = mc.player.posX;
        y = mc.player.posY;
        z = mc.player.posZ;
        onGround = mc.player.onGround;
    }

    public static void restorePosition() {
        mc.player.posX = x;
        mc.player.posY = y;
        mc.player.posZ = z;
        mc.player.onGround = onGround;
    }

}