package dev.azure.client.modules.movement;

import dev.azure.client.modules.Category;
import dev.azure.client.modules.Module;
import dev.azure.client.settings.implement.BooleanSetting;
import dev.azure.client.settings.implement.DoubleSetting;
import dev.azure.client.settings.implement.IntegerSetting;
import dev.azure.client.settings.implement.ModeSetting;
import dev.azure.client.utilities.math.MathUtils;
import net.minecraft.network.play.client.CPacketPlayer;

import java.util.Date;

public class Step extends Module {
    public Step() {
        super("Step", "Step", "Increases your step height.", Category.MOVEMENT);
        addSettings(mode, height, entityStep, timer, speed, wait);
    }

    long stepLast = 0;

    boolean isStepping = false;
    double[] forwardStep;
    double originalHeight;

    ModeSetting mode = new ModeSetting("Mode", "Vanilla", "Vanilla", "Normal");
    DoubleSetting height = new DoubleSetting("Height", 2.5, 0.1, 2.5);
    BooleanSetting entityStep = new BooleanSetting("EntityStep", false);

    BooleanSetting timer = new BooleanSetting("Timer", false);
    DoubleSetting speed = new DoubleSetting("Speed", 0.1, 0.1, 2.0);
    IntegerSetting wait = new IntegerSetting("Wait", 0, 0, 50);

    public void onTick() {
        if (!isStepping && mc.timer.tickLength != 50.0f) {
            mc.timer.tickLength = 50.0f;
        }

        if (mc.player == null || mc.world == null) return;

        if (!mc.player.collidedHorizontally) return;
        if (mc.player.isOnLadder() || mc.player.movementInput.jump) return;
        if ((mc.player.isInWater() || mc.player.isInLava())) return;
        if (!mc.player.onGround) return;

        if (mc.player.isSneaking()) return;
        if (entityStep.getValue() && mc.player.isRiding())
            mc.player.ridingEntity.stepHeight = (float) height.getValue();

        forwardStep = MathUtils.directionSpeed(0.1);

        if (getStepHeight().equals(StepHeight.Unsafe)) return;

        isStepping = true;
        if (!mode.getValue().equalsIgnoreCase("Vanilla")) {
            if (timer.getValue()) mc.timer.tickLength = (float) (50.0f / speed.getValue());

            for (double v : getStepHeight().stepArray) {
                mc.player.connection.sendPacket(new CPacketPlayer.Position(mc.player.posX, mc.player.posY + v, mc.player.posZ, mc.player.onGround));
            }
        }

        mc.player.setPosition(mc.player.posX, mc.player.posY + getStepHeight().height, mc.player.posZ);
        if (new Date().getTime() >= stepLast + (wait.getValue() * 10.0f)) {
            stepLast = new Date().getTime();
            isStepping = false;
        }
    }

    public void onEnable() {
        if (mc.world == null || mc.player == null) return;

        if (mode.equals("Vanilla")) {
            mc.player.stepHeight = (float) height.getValue();
        }

        originalHeight = mc.player.posY;
        mc.timer.tickLength = 50.0f;
    }

    public void onDisable() {
        if (mode.equals("Vanilla")) {
            mc.player.stepHeight = 0.6f;
        }

        mc.timer.tickLength = 50.0f;
    }

    public StepHeight getStepHeight() {
        if (mc.world.getCollisionBoxes(mc.player, mc.player.getEntityBoundingBox().offset(forwardStep[0], 1.0, forwardStep[1])).isEmpty() && !mc.world.getCollisionBoxes(mc.player, mc.player.getEntityBoundingBox().offset(forwardStep[0], 0.6, forwardStep[1])).isEmpty())
            return StepHeight.One;
        else if (mc.world.getCollisionBoxes(mc.player, mc.player.getEntityBoundingBox().offset(forwardStep[0], 1.6, forwardStep[1])).isEmpty() && !mc.world.getCollisionBoxes(mc.player, mc.player.getEntityBoundingBox().offset(forwardStep[0], 1.4, forwardStep[1])).isEmpty())
            return StepHeight.OneHalf;
        else if (mc.world.getCollisionBoxes(mc.player, mc.player.getEntityBoundingBox().offset(forwardStep[0], 2.1, forwardStep[1])).isEmpty() && !mc.world.getCollisionBoxes(mc.player, mc.player.getEntityBoundingBox().offset(forwardStep[0], 1.9, forwardStep[1])).isEmpty())
            return StepHeight.Two;
        else if (mc.world.getCollisionBoxes(mc.player, mc.player.getEntityBoundingBox().offset(forwardStep[0], 2.6, forwardStep[1])).isEmpty() && !mc.world.getCollisionBoxes(mc.player, mc.player.getEntityBoundingBox().offset(forwardStep[0], 2.4, forwardStep[1])).isEmpty())
            return StepHeight.TwoHalf;
        else
            return StepHeight.Unsafe;
    }

    public enum StepHeight {
        One(1, new double[]{0.42, 0.753}),
        OneHalf(1.5, new double[]{0.42, 0.75, 1.0, 1.16, 1.23, 1.2}),
        Two(2, new double[]{0.42, 0.78, 0.63, 0.51, 0.9, 1.21, 1.45, 1.43}),
        TwoHalf(2.5, new double[]{0.425, 0.821, 0.699, 0.599, 1.022, 1.372, 1.652, 1.869, 2.019, 1.907}),
        Unsafe(3, new double[]{0});

        double[] stepArray;
        double height;

        StepHeight(double height, double[] stepArray) {
            this.height = height;
            this.stepArray = stepArray;
        }
    }
}
