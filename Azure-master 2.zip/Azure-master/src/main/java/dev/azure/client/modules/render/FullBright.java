package dev.azure.client.modules.render;

import com.mojang.realmsclient.gui.ChatFormatting;
import dev.azure.client.modules.Category;
import dev.azure.client.modules.Module;
import dev.azure.client.utilities.chat.ChatUtils;

public class FullBright extends Module {
    public FullBright() {
        super("FullBright", "Full Bright", "Makes your world brighter.", Category.RENDER);
        addSettings();
    }

    public void onEnable() {
        mc.gameSettings.gammaSetting = 100.0f;
    }

    public void onDisable() {
        mc.gameSettings.gammaSetting = 1.0f;
    }
}
