package dev.azure.client.utilities.chat;

import com.mojang.realmsclient.gui.ChatFormatting;
import dev.azure.client.modules.client.CommandModule;
import dev.azure.client.utilities.Utility;

public class CommandUtils implements Utility {
    public static ChatFormatting getColor(String value, boolean light) {
        switch (value) {
            case "Black": {
                if (light) {
                    return ChatFormatting.DARK_GRAY;
                } else {
                    return ChatFormatting.BLACK;
                }
            }

            case "Blue": {
                if (light) {
                    return ChatFormatting.BLUE;
                } else {
                    return ChatFormatting.DARK_BLUE;
                }
            }

            case "Green": {
                if (light) {
                    return ChatFormatting.GREEN;
                } else {
                    return ChatFormatting.DARK_GREEN;
                }
            }

            case "Aqua": {
                if (light) {
                    return ChatFormatting.AQUA;
                } else {
                    return ChatFormatting.DARK_AQUA;
                }
            }

            case "Red": {
                if (light) {
                    return ChatFormatting.RED;
                } else {
                    return ChatFormatting.DARK_RED;
                }
            }

            case "Purple": {
                if (light) {
                    return ChatFormatting.LIGHT_PURPLE;
                } else {
                    return ChatFormatting.DARK_PURPLE;
                }
            }

            case "Yellow": {
                if (light) {
                    return ChatFormatting.YELLOW;
                } else {
                    return ChatFormatting.GOLD;
                }
            }

            case "Gray": {
                if (light) {
                    return ChatFormatting.GRAY;
                } else {
                    return ChatFormatting.DARK_GRAY;
                }
            }

            default:
                return ChatFormatting.WHITE;
        }
    }

    public static ChatFormatting getPartOne() {
        return getColor(CommandModule.partOneColor.getValue(), CommandModule.partOneLight.getValue());
    }

    public static ChatFormatting getPartTwo() {
        return getColor(CommandModule.partTwoColor.getValue(), CommandModule.partTwoLight.getValue());
    }
}