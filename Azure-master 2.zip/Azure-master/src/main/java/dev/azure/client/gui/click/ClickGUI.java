package dev.azure.client.gui.click;

import dev.azure.client.gui.click.buttons.ModuleButton;
import dev.azure.client.gui.click.implement.Component;
import dev.azure.client.modules.Category;
import dev.azure.client.modules.Module;
import dev.azure.client.modules.ModuleManager;
import dev.azure.client.modules.client.ColorModule;
import dev.azure.client.utilities.render.RenderUtils;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import org.lwjgl.input.Keyboard;

import java.awt.*;
import java.util.ArrayList;

public class ClickGUI extends GuiScreen {
    public static ArrayList<Panel> panels;

    public ClickGUI() {
        panels = new ArrayList<>();
        int panelX = 5;
        for (Category category : Category.values()) {
            final Panel panel = new Panel(category) {
                @Override
                public void setup() {
                    int tempY = 15;
                    for (Module module : ModuleManager.getModules(category)) {
                        ModuleButton button = new ModuleButton(module, this, tempY);
                        components.add(button);
                        tempY += 14;
                    }
                }
            };
            panel.setX(panelX);
            panels.add(panel);
            panelX += panel.getWidth() + 10;
        }
    }

    public void drawScreen(final int mouseX, final int mouseY, final float partialTicks) {
        ScaledResolution resolution = new ScaledResolution(mc);

        RenderUtils.drawGradientRect(0.0f, 0.0f, (float) resolution.getScaledWidth(), (float) resolution.getScaledHeight(), new Color(0, 0, 0, 0).getRGB(), ColorModule.getColor(130).getRGB());
        for (final Panel panel : panels) {
            panel.drawScreen();
            panel.updatePosition(mouseX, mouseY);
            for (final Component component : panel.getComponents()) {
                component.updateComponent(mouseX, mouseY);
            }
        }
    }

    protected void mouseClicked(final int mouseX, final int mouseY, final int button) {
        for (final Panel panel : panels) {
            if (panel.isWithinHeader(mouseX, mouseY) && button == 0) {
                panel.setDragging(true);
                panel.dragX = mouseX - panel.getX();
                panel.dragY = mouseY - panel.getY();
            }

            if (panel.isWithinHeader(mouseX, mouseY) && button == 1) {
                panel.setOpen(true);
            }

            if (panel.isOpen() && !panel.getComponents().isEmpty()) {
                for (final Component component : panel.getComponents()) {
                    component.mouseClicked(mouseX, mouseY, button);
                }
            }
        }
    }

    protected void mouseReleased(final int mouseX, final int mouseY, final int state) {
        for (final Panel panel : panels) {
            panel.setDragging(false);
            if (panel.isOpen() && !panel.getComponents().isEmpty()) {
                for (final Component component : panel.getComponents()) {
                    component.mouseReleased(mouseX, mouseY, state);
                }
            }
        }
    }

    protected void keyTyped(final char typedChar, final int keyCode) {
        for (final Panel panel : panels) {
            if (panel.isOpen() && !panel.getComponents().isEmpty()) {
                for (final Component component : panel.getComponents()) {
                    component.keyTyped(typedChar, keyCode);
                }
            }
        }

        if (keyCode == Keyboard.KEY_ESCAPE) {
            mc.displayGuiScreen(null);
        }
    }

    public boolean doesGuiPauseGame() {
        return false;
    }

    public void initGui() {
    }

    public static Panel getPanel(String name) {
        for (Panel panel : panels) {
            if (name.equalsIgnoreCase(String.valueOf(panel.category))) {
                return panel;
            }
        }

        return null;
    }
}
