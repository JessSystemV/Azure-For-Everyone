package dev.azure.client.modules.client;

import dev.azure.client.modules.Category;
import dev.azure.client.modules.Module;
import dev.azure.client.settings.implement.BooleanSetting;
import dev.azure.client.settings.implement.DoubleSetting;
import dev.azure.client.settings.implement.IntegerSetting;
import dev.azure.client.utilities.render.ColorUtils;

import java.awt.*;

public class ColorModule extends Module {
    public ColorModule() {
        super("Color", "Color", "Main color module for the whole client.", Category.CLIENT);
        addSettings(sync, rainbow, delay, hue, saturation, brightness);
    }

    public static BooleanSetting sync = new BooleanSetting("Sync", true);
    public static BooleanSetting rainbow = new BooleanSetting("Rainbow", false);
    public static DoubleSetting delay = new DoubleSetting("Delay", 4, 0.1, 10);
    public static IntegerSetting hue = new IntegerSetting("Hue", 356, 0, 356);
    public static IntegerSetting saturation = new IntegerSetting("Saturation", 100, 0, 100);
    public static IntegerSetting brightness = new IntegerSetting("Brightness", 100, 0, 100);

    public static float getHue() {
        return ColorModule.hue.getValue() / 356.0f;
    }

    public static float getSaturation() {
        return ColorModule.saturation.getValue() / 100.0f;
    }

    public static float getBrightness() {
        return ColorModule.brightness.getValue() / 100.0f;
    }

    public static Color getColor() {
        if (rainbow.getValue()) {
            return new Color(ColorUtils.getRainbow((float) delay.getValue(), getSaturation(), getBrightness()));
        } else {
            return new Color(Color.HSBtoRGB(getHue(), getSaturation(), getBrightness()));
        }
    }

    public static Color getColor(int alpha) {
        Color color;
        if (rainbow.getValue()) {
            color = new Color(ColorUtils.getRainbow((float) delay.getValue(), getSaturation(), getBrightness()));
        } else {
            color = new Color(Color.HSBtoRGB(getHue(), getSaturation(), getBrightness()));
        }
        return new Color(color.getRed(), color.getGreen(), color.getBlue(), alpha);
    }
}