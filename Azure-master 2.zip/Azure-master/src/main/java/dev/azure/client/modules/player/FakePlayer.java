package dev.azure.client.modules.player;

import com.mojang.authlib.GameProfile;
import dev.azure.client.modules.Category;
import dev.azure.client.modules.Module;
import dev.azure.client.settings.implement.BooleanSetting;
import dev.azure.client.settings.implement.StringSetting;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.world.GameType;

import java.util.UUID;

public class FakePlayer extends Module {
    public FakePlayer() {
        super("FakePlayer", "Fake Player", "Spawns in a fake player for you to test modules on.", Category.PLAYER);
        addSettings(name, uuid, copyInventory);
    }

    StringSetting name = new StringSetting("Name", "Dummy");
    StringSetting uuid = new StringSetting("UUID", "2b2b320c-e2ae-4da9-bb35-6c57a4fba14d");
    BooleanSetting copyInventory = new BooleanSetting("CopyInventory", false);

    public void onEnable() {
        if (mc.player == null || mc.player.isDead || mc.world == null) {
            disable();
            return;
        }

        EntityOtherPlayerMP clone = new EntityOtherPlayerMP(mc.world, new GameProfile(UUID.fromString(uuid.getValue()), name.getValue()));
        clone.copyLocationAndAnglesFrom(mc.player);
        clone.rotationYawHead = mc.player.rotationYawHead;
        clone.rotationYaw = mc.player.rotationYaw;
        clone.rotationPitch = mc.player.rotationPitch;
        clone.setGameType(GameType.SURVIVAL);
        clone.setHealth(20);
        mc.world.addEntityToWorld(-696969969, clone);
        if (copyInventory.getValue()) {
            clone.inventory.copyInventory(mc.player.inventory);
        }
        clone.onLivingUpdate();
    }

    public void onDisable() {
        if (mc.world != null) {
            mc.world.removeEntityFromWorld(-696969969);
        }
    }
}
