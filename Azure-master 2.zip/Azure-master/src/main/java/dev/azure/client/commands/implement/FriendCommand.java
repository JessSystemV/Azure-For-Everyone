package dev.azure.client.commands.implement;

import dev.azure.client.commands.Command;
import dev.azure.client.social.SocialManager;
import dev.azure.client.social.implement.Friend;
import dev.azure.client.utilities.chat.ChatUtils;
import dev.azure.client.utilities.chat.CommandUtils;

public class FriendCommand extends Command {
    public FriendCommand() {
        super("Friend", "Adds or removes a player from your friends list.", "friend add <name> | del <name> | list | clear", "friends", "f");
    }

    @Override
    public void onCommand(String[] args, String command) {
        if (args.length == 1) {
            if (args[0].equalsIgnoreCase("clear")) {
                ChatUtils.sendMessage("The enemies list has been cleared.", true);
                SocialManager.clearFriends();
            } else {
                ChatUtils.sendMessage(getSyntax(), true);
            }
        } else if (args.length == 2) {
            if (args[1].length() < 3) {
                ChatUtils.sendMessage(CommandUtils.getPartTwo() + args[1] + CommandUtils.getPartOne() + " is not a valid username.", true);
            } else {
                if (args[0].equalsIgnoreCase("add")) {
                    if (SocialManager.isFriend(args[1])) SocialManager.removeFriend(args[1]);
                    SocialManager.addFriend(args[1]);
                    ChatUtils.sendMessage(CommandUtils.getPartTwo() + args[1] + CommandUtils.getPartOne() + " has been put on the friends list.", true);
                } else if (args[0].equalsIgnoreCase("del") || args[0].equalsIgnoreCase("remove") || args[0].equalsIgnoreCase("delete")) {
                    if (!SocialManager.isFriend(args[1])) {
                        ChatUtils.sendMessage(CommandUtils.getPartTwo() + args[1] + CommandUtils.getPartOne() + " is not a friend.", true);
                    } else {
                        SocialManager.removeFriend(args[1]);
                        ChatUtils.sendMessage(CommandUtils.getPartTwo() + args[1] + CommandUtils.getPartOne() + " has been removed from the friends list.", true);
                    }
                } else {
                    ChatUtils.sendMessage(getSyntax(), true);
                }
            }
        } else {
            ChatUtils.sendMessage(getSyntax(), true);
        }
    }
}