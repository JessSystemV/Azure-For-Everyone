package dev.azure.client.settings.implement;

import dev.azure.client.settings.Setting;

public class CategorySetting extends Setting {
    private boolean open;

    public CategorySetting(String name, final boolean open) {
        super(name, true);
        this.open = open;
    }

    public boolean isOpen() {
        return open;
    }

    public void setOpen(final boolean open) {
        this.open = open;
    }
}