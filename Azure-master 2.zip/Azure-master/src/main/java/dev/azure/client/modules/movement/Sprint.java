package dev.azure.client.modules.movement;

import dev.azure.client.modules.Category;
import dev.azure.client.modules.Module;
import dev.azure.client.settings.implement.ModeSetting;
import dev.azure.event.Event;
import dev.azure.event.implement.MotionEvent;
import dev.azure.event.status.Stage;
import dev.azure.event.implement.MoveEvent;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;

public class Sprint extends Module {
    public Sprint() {
        super("Sprint", "Sprint", "Automatically sprints for you.", Category.MOVEMENT);
        addSettings(mode);
    }

    ModeSetting mode = new ModeSetting("Mode", "Rage", "Legit", "Rage");

    public void onTick() {
        switch (mode.getValue()) {
            case "Rage": {
                if (!mc.gameSettings.keyBindForward.isKeyDown() && !mc.gameSettings.keyBindBack.isKeyDown() && !mc.gameSettings.keyBindLeft.isKeyDown() && !mc.gameSettings.keyBindRight.isKeyDown() || mc.player.isSneaking() || mc.player.collidedHorizontally || (float) mc.player.getFoodStats().getFoodLevel() <= 6.0f) break;
                mc.player.setSprinting(true);
                break;
            }
            case "Legit": {
                if (!mc.gameSettings.keyBindForward.isKeyDown() || mc.player.isSneaking() || mc.player.isHandActive() || mc.player.collidedHorizontally || (float) mc.player.getFoodStats().getFoodLevel() <= 6.0f || Sprint.mc.currentScreen != null) break;
                mc.player.setSprinting(true);
            }
        }
    }

    @SuppressWarnings("unused")
    @EventHandler
    private final Listener<MotionEvent> onMotion = new Listener<>(event -> {
        if (event.stage == Stage.POST && mode.getValue().equalsIgnoreCase("Rage") && (mc.player.movementInput.moveForward != 0.0f || mc.player.movementInput.moveStrafe != 0.0f)) {
            event.setCancelled(true);
        }
    });

    public void onDisable() {
        mc.player.setSprinting(mc.gameSettings.keyBindSprint.isKeyDown());
    }
}
