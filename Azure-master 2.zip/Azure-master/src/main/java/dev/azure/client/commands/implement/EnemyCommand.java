package dev.azure.client.commands.implement;

import dev.azure.client.commands.Command;
import dev.azure.client.social.SocialManager;
import dev.azure.client.social.implement.Enemy;
import dev.azure.client.utilities.chat.ChatUtils;
import dev.azure.client.utilities.chat.CommandUtils;

public class EnemyCommand extends Command {
    public EnemyCommand() {
        super("Enemy", "Adds or removes a player from your enemies list.", "enemy <add|del> <name> | list | clear", "enemies", "e");
    }

    @Override
    public void onCommand(String[] args, String command) {
        if (args.length == 1) {
            if (args[0].equalsIgnoreCase("clear")) {
                SocialManager.clearEnemies();
                ChatUtils.sendMessage("The enemies list has been cleared.", true);
            } else {
                ChatUtils.sendMessage(getSyntax(), true);
            }
        } else if (args.length == 2) {
            if (args[1].length() < 3) {
                ChatUtils.sendMessage(CommandUtils.getPartTwo() + args[1] + CommandUtils.getPartOne() + " is not a valid username.", true);
            } else {
                if (args[0].equalsIgnoreCase("add")) {
                    if (SocialManager.isEnemy(args[1])) SocialManager.removeEnemy(args[1]);
                    SocialManager.addEnemy(args[1]);
                    ChatUtils.sendMessage(CommandUtils.getPartTwo() + args[1] + CommandUtils.getPartOne() + " has been put on the enemies list.", true);
                } else if (args[0].equalsIgnoreCase("del") || args[0].equalsIgnoreCase("remove") || args[0].equalsIgnoreCase("delete")) {
                    if (!SocialManager.isEnemy(args[1])) {
                        ChatUtils.sendMessage(CommandUtils.getPartTwo() + args[1] + CommandUtils.getPartOne() + " is not an enemy.", true);
                    } else {
                        SocialManager.removeEnemy(args[1]);
                        ChatUtils.sendMessage(CommandUtils.getPartTwo() + args[1] + CommandUtils.getPartOne() + " has been removed from the enemies list.", true);
                    }
                } else {
                    ChatUtils.sendMessage(getSyntax(), true);
                }
            }
        } else {
            ChatUtils.sendMessage(getSyntax(), true);
        }
    }
}