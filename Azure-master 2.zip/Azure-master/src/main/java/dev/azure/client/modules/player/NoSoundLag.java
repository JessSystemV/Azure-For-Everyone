package dev.azure.client.modules.player;

import com.google.common.collect.Sets;
import dev.azure.client.modules.Category;
import dev.azure.client.modules.Module;
import dev.azure.client.settings.implement.BooleanSetting;
import dev.azure.client.settings.implement.DoubleSetting;
import dev.azure.client.utilities.math.MathUtils;
import dev.azure.event.implement.PacketEvent;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.init.SoundEvents;
import net.minecraft.network.play.server.SPacketSoundEffect;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;

public class NoSoundLag extends Module {
    public NoSoundLag() {
        super("NoSoundLag", "No Sound Lag", "Prevents sounds lag.", Category.PLAYER);
        addSettings(crystals, armor, range);
    }

    private static final Set<SoundEvent> blacklist = Sets.newHashSet(SoundEvents.ITEM_ARMOR_EQUIP_GENERIC, SoundEvents.ITEM_ARMOR_EQIIP_ELYTRA, SoundEvents.ITEM_ARMOR_EQUIP_DIAMOND, SoundEvents.ITEM_ARMOR_EQUIP_IRON, SoundEvents.ITEM_ARMOR_EQUIP_GOLD, SoundEvents.ITEM_ARMOR_EQUIP_CHAIN, SoundEvents.ITEM_ARMOR_EQUIP_LEATHER);

    BooleanSetting crystals = new BooleanSetting("Crystals", true);
    BooleanSetting armor = new BooleanSetting("Armor", true);
    DoubleSetting range = new DoubleSetting("Range", 12.0, 0.1, 12.0);

    @SuppressWarnings("unused")
    @EventHandler
    private final Listener<PacketEvent.Receive> receiveListener = new Listener<>(event -> {
        if (event.isPre()) {
            if (event.getPacket() instanceof SPacketSoundEffect) {
                SPacketSoundEffect packet = (SPacketSoundEffect) event.getPacket();
                if (crystals.getValue() && packet.getCategory() == SoundCategory.BLOCKS && packet.getSound() == SoundEvents.ENTITY_GENERIC_EXPLODE) {
                    removeEntities(packet);
                }

                if (armor.getValue() && blacklist.contains(packet.getSound())) {
                    event.setCancelled(true);
                }
            }
        }
    });

    public void removeEntities(SPacketSoundEffect packet) {
        BlockPos pos = new BlockPos(packet.getX(), packet.getY(), packet.getZ());
        ArrayList<Entity> remove = new ArrayList<>();
        CopyOnWriteArrayList<Entity> copy = new CopyOnWriteArrayList<>(mc.world.loadedEntityList);
        for (Entity entity : copy) {
            if (!(entity instanceof EntityEnderCrystal) || !(entity.getDistanceSq(pos) <= MathUtils.square(range.getValue())))
                continue;
            remove.add(entity);
        }

        for (Entity entity : remove) {
            entity.setDead();
        }
    }
}
