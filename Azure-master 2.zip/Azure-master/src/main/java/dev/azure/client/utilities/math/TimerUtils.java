package dev.azure.client.utilities.math;

import dev.azure.client.utilities.Utility;

public class TimerUtils implements Utility {
    private long time = -1L;

    public boolean hasSecondsElapsed(double seconds) {
        return this.hasTimeElapsed((long) seconds * 1000L);
    }

    public boolean hasTimeElapsed(long milliseconds) {
        return hasNanosecondsElapsed(convertToNano(milliseconds));
    }

    public TimerUtils reset() {
        this.time = System.nanoTime();
        return this;
    }

    public boolean hasNanosecondsElapsed(long ns) {
        return System.nanoTime() - this.time >= ns;
    }

    public long convertToNano(long time) {
        return time * 1000000L;
    }
}
