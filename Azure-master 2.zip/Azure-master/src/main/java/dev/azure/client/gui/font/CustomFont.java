package dev.azure.client.gui.font;

import net.minecraft.client.renderer.texture.DynamicTexture;
import org.lwjgl.opengl.GL11;

import java.awt.*;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;

public abstract class CustomFont {
    private final float imageSize = 512;
    protected CharData[] charData = new CharData[256];
    protected Font font;
    protected boolean antiAlias;
    protected boolean fractionalMetrics;
    protected int fontHeight = -1;
    protected int charOffset = 0;
    protected DynamicTexture texture;

    public CustomFont(final Font font, final boolean antiAlias, final boolean fractionalMetrics) {
        this.font = font;
        this.antiAlias = antiAlias;
        this.fractionalMetrics = fractionalMetrics;
        this.texture = setupTexture(font, antiAlias, fractionalMetrics, charData);
    }

    protected DynamicTexture setupTexture(final Font font, final boolean antiAlias, final boolean fractionalMetrics, final CharData[] chars) {
        final BufferedImage image = generateFontImage(font, antiAlias, fractionalMetrics, chars);

        try {
            return new DynamicTexture(image);
        } catch (Exception exception) {
            exception.printStackTrace();
        }

        return null;
    }

    protected BufferedImage generateFontImage(final Font font, final boolean antiAlias, final boolean fractionalMetrics, final CharData[] chars) {
        final int imageSize = (int) this.imageSize;
        final BufferedImage bufferedImage = new BufferedImage(imageSize, imageSize, BufferedImage.TYPE_INT_ARGB);
        final Graphics2D graphics = (Graphics2D) bufferedImage.getGraphics();

        graphics.setFont(font);
        graphics.setColor(new Color(255, 255, 255, 0));
        graphics.fillRect(0, 0, imageSize, imageSize);
        graphics.setColor(Color.WHITE);
        graphics.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, fractionalMetrics ? RenderingHints.VALUE_FRACTIONALMETRICS_ON : RenderingHints.VALUE_FRACTIONALMETRICS_OFF);
        graphics.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, antiAlias ? RenderingHints.VALUE_TEXT_ANTIALIAS_ON : RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
        graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, antiAlias ? RenderingHints.VALUE_ANTIALIAS_ON : RenderingHints.VALUE_ANTIALIAS_OFF);

        final FontMetrics fontMetrics = graphics.getFontMetrics();
        int charHeight = 0;
        int positionX = 0;
        int positionY = 1;

        for (int i = 0; i < chars.length; i++) {
            final char character = (char) i;
            final CharData charData = new CharData();
            final Rectangle2D dimensions = fontMetrics.getStringBounds(String.valueOf(character), graphics);

            charData.width = (dimensions.getBounds().width + 8);
            charData.height = dimensions.getBounds().height;

            if (positionX + charData.width >= imageSize) {
                positionX = 0;
                positionY += charHeight;
                charHeight = 0;
            }

            if (charData.height > charHeight) {
                charHeight = charData.height;
            }

            charData.storedX = positionX;
            charData.storedY = positionY;

            if (charData.height > fontHeight) {
                fontHeight = charData.height;
            }

            chars[i] = charData;
            graphics.drawString(String.valueOf(character), positionX + 2, positionY + fontMetrics.getAscent());
            positionX += charData.width;
        }

        return bufferedImage;
    }

    public void drawChar(final CharData[] chars, final char character, final float x, final float y) throws ArrayIndexOutOfBoundsException {
        try {
            drawQuad(x, y, chars[character].width, chars[character].height, chars[character].storedX, chars[character].storedY, chars[character].width, chars[character].height);
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    protected void drawQuad(final float x, final float y, final float width, final float height, final float srcX, final float srcY, final float srcWidth, final float srcHeight) {
        final float renderSrcX = srcX / imageSize;
        final float renderSrcY = srcY / imageSize;
        final float renderSrcWidth = srcWidth / imageSize;
        final float renderSrcHeight = srcHeight / imageSize;

        GL11.glTexCoord2f(renderSrcX + renderSrcWidth, renderSrcY);
        GL11.glVertex2d(x + width, y);
        GL11.glTexCoord2f(renderSrcX, renderSrcY);
        GL11.glVertex2d(x, y);
        GL11.glTexCoord2f(renderSrcX, renderSrcY + renderSrcHeight);
        GL11.glVertex2d(x, y + height);
        GL11.glTexCoord2f(renderSrcX, renderSrcY + renderSrcHeight);
        GL11.glVertex2d(x, y + height);
        GL11.glTexCoord2f(renderSrcX + renderSrcWidth, renderSrcY + renderSrcHeight);
        GL11.glVertex2d(x + width, y + height);
        GL11.glTexCoord2f(renderSrcX + renderSrcWidth, renderSrcY);
        GL11.glVertex2d(x + width, y);
    }

    public int getHeight() {
        return (fontHeight - 8) / 2;
    }

    public int getStringWidth(final String text) {
        int width = 0;

        for (final char character : text.toCharArray()) {
            if (character < charData.length) width += charData[character].width - 8 + charOffset;
        }

        return width / 2;
    }

    public boolean isAntiAlias() {
        return antiAlias;
    }

    public boolean isFractionalMetrics() {
        return fractionalMetrics;
    }

    public void setAntiAlias(final boolean antiAlias) {
        if (this.antiAlias != antiAlias) {
            this.antiAlias = antiAlias;
            texture = setupTexture(font, antiAlias, fractionalMetrics, charData);
        }
    }

    public void setFractionalMetrics(final boolean fractionalMetrics) {
        if (this.fractionalMetrics != fractionalMetrics) {
            this.fractionalMetrics = fractionalMetrics;
            texture = setupTexture(font, antiAlias, fractionalMetrics, charData);
        }
    }

    public Font getFont() {
        return font;
    }

    public void setFont(final Font font) {
        this.font = font;
        texture = setupTexture(font, antiAlias, fractionalMetrics, charData);
    }

    protected static class CharData {
        public int width;
        public int height;
        public int storedX;
        public int storedY;

        protected CharData() {

        }
    }
}
