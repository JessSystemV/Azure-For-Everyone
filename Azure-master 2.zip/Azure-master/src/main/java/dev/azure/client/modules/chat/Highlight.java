package dev.azure.client.modules.chat;

import dev.azure.client.modules.Category;
import dev.azure.client.modules.Module;
import dev.azure.client.settings.implement.BooleanSetting;

public class Highlight extends Module {
    public Highlight() {
        super("Highlight", "Highlight", "Highlights certain users.", Category.CHAT);
        addSettings(self, friends, enemies);
    }

    public static BooleanSetting self = new BooleanSetting("Self", true);
    public static BooleanSetting friends = new BooleanSetting("Friends", false);
    public static BooleanSetting enemies = new BooleanSetting("Enemies", false);
}
