package dev.azure.client;

import club.minnced.discord.rpc.DiscordEventHandlers;
import club.minnced.discord.rpc.DiscordRPC;
import club.minnced.discord.rpc.DiscordRichPresence;
import dev.azure.client.modules.client.DiscordModule;
import net.minecraft.client.Minecraft;

public class DiscordPresence {
    protected static final Minecraft mc = Minecraft.getMinecraft();

    public static void start() {
        DiscordRPC library = DiscordRPC.INSTANCE;
        String applicationId = "861679089370005554";
        String steamId = "";
        DiscordEventHandlers handlers = new DiscordEventHandlers();
        handlers.ready = (user) -> Azure.log.info("Discord Presence is ready!");
        library.Discord_Initialize(applicationId, handlers, true, steamId);
        DiscordRichPresence presence = new DiscordRichPresence();

        presence.startTimestamp = System.currentTimeMillis() / 1000;
        presence.largeImageKey = "logo";
        presence.largeImageText = "Azure " + Azure.VERSION;
        if (DiscordModule.status.getValue()) {
            presence.details = "Main Menu";
        } else {
            presence.details = "Using Azure";
        }
        presence.state = "Idle";

        library.Discord_UpdatePresence(presence);
        new Thread(() -> {
            while (!Thread.currentThread().isInterrupted()) {
                library.Discord_RunCallbacks();

                try {
                    if (mc.isIntegratedServerRunning()) {
                        if (DiscordModule.status.getValue()) {
                            presence.details = "Singleplayer";
                        } else {
                            presence.details = "Using Azure";
                        }

                        if (DiscordModule.customState.getValue()) {
                            presence.state = DiscordModule.state.getValue();
                        } else {
                            presence.state = "Playing alone";
                        }
                    } else if (mc.getCurrentServerData() != null) {
                        if (DiscordModule.status.getValue()) {
                            presence.details = "Playing on a Server";
                        } else {
                            presence.details = "Using Azure";
                        }
                        if (DiscordModule.server.getValue()) {
                            presence.state = mc.getCurrentServerData().serverIP;
                        } else {
                            if (DiscordModule.customState.getValue()) {
                                presence.state = DiscordModule.state.getValue();
                            } else {
                                presence.state = "With Friends";
                            }
                        }
                    } else {
                        if (DiscordModule.status.getValue()) {
                            presence.details = "Main Menu";
                        } else {
                            presence.details = "Using Azure";
                        }
                        if (DiscordModule.customState.getValue()) {
                            presence.state = DiscordModule.state.getValue();
                        } else {
                            presence.state = "Idle";
                        }
                    }

                    library.Discord_UpdatePresence(presence);
                } catch (Exception ignored) {
                }

                try {
                    Thread.sleep(2000);
                } catch (InterruptedException ignored) {
                }
            }
        }, "RPC-Callback-Handler").start();
    }

    public static void stop() {
        DiscordRPC library = DiscordRPC.INSTANCE;
        library.Discord_Shutdown();
    }
}
