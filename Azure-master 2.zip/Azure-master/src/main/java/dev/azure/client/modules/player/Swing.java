package dev.azure.client.modules.player;

import dev.azure.client.modules.Category;
import dev.azure.client.modules.Module;
import dev.azure.client.settings.implement.BooleanSetting;
import dev.azure.client.settings.implement.ModeSetting;

public class Swing extends Module {
    public Swing() {
        super("Swing", "Swing", "Changes the hand you swing with.", Category.PLAYER);
        addSettings(hand, silent);
    }

    public static ModeSetting hand = new ModeSetting("Hand", "Offhand", "Mainhand", "Offhand");
    public static BooleanSetting silent = new BooleanSetting("Silent", false);
}
