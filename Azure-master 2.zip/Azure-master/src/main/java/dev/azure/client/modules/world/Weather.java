package dev.azure.client.modules.world;

import dev.azure.client.modules.Category;
import dev.azure.client.modules.Module;
import dev.azure.client.settings.implement.BooleanSetting;
import dev.azure.client.settings.implement.IntegerSetting;
import dev.azure.client.settings.implement.ModeSetting;
import dev.azure.event.implement.WeatherEvent;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;

public class Weather extends Module {
    public Weather() {
        super("Weather", "Weather", "Let's you manage the time and weather client-side.", Category.WORLD);
        addSettings(weather);
    }

    ModeSetting weather = new ModeSetting("Weather", "Clear", "Clear", "Rain", "Thunder");

    public void onTick() {
        if (mc.world == null) {
            return;
        }

        if (weather.getValue().equalsIgnoreCase("Rain")) {
            mc.world.setRainStrength(1.0f);
        } else if (weather.getValue().equalsIgnoreCase("Thunder")) {
            mc.world.setThunderStrength(2.0f);
        }
    }

    @SuppressWarnings("unused")
    @EventHandler
    private final Listener<WeatherEvent> weatherListener = new Listener<>(event -> {
        if (mc.world == null) return;

        if (weather.getValue().equalsIgnoreCase("Clear")) {
            event.setCancelled(true);
        }
    });
}
