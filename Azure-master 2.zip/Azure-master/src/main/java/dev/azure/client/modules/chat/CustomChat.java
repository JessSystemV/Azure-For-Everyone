package dev.azure.client.modules.chat;

import dev.azure.client.modules.Category;
import dev.azure.client.modules.Module;
import dev.azure.client.settings.implement.BooleanSetting;

public class CustomChat extends Module {
    public CustomChat() {
        super("CustomChat", "Custom Chat", "Let's you customize your chat.", Category.CHAT);
        addSettings(clearChat, infinite);
    }

    public static BooleanSetting clearChat = new BooleanSetting("ClearChat", false);
    public static BooleanSetting infinite = new BooleanSetting("Infinite", false);
}
