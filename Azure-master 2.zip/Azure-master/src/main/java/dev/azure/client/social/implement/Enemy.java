package dev.azure.client.social.implement;

public class Enemy {
    public String name;

    public Enemy(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
