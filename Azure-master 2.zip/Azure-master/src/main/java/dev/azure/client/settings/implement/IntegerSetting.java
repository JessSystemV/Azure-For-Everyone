package dev.azure.client.settings.implement;

import dev.azure.client.modules.Module;
import dev.azure.client.settings.Setting;

public class IntegerSetting extends Setting {
    private int value;
    private final int minimum;
    private final int maximum;

    public IntegerSetting(String name, final int value, final int minimum, final int maximum) {
        super(name, true);
        this.value = value;
        this.minimum = minimum;
        this.maximum = maximum;
    }

    public IntegerSetting(String name, final int value, final int minimum, final int maximum, boolean visible) {
        super(name, visible);
        this.value = value;
        this.minimum = minimum;
        this.maximum = maximum;
    }

    public int getValue() {
        return value;
    }

    public void setValue(final int value) {
        this.value = Math.max(minimum, Math.min(maximum, value));
    }

    public int getMinimum() {
        return minimum;
    }

    public int getMaximum() {
        return maximum;
    }
}
