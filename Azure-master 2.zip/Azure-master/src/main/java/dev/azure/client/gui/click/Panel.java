package dev.azure.client.gui.click;

import dev.azure.client.gui.click.buttons.ModuleButton;
import dev.azure.client.gui.click.implement.Component;
import dev.azure.client.modules.Category;
import dev.azure.client.modules.client.ColorModule;
import dev.azure.client.gui.font.FontManager;
import dev.azure.client.utilities.render.RenderUtils;

import java.awt.*;
import java.util.ArrayList;

public class Panel {
    public ArrayList<Component> components;
    public Category category;
    private final int width;
    public int x;
    public int y;
    public int dragX;
    public int dragY;
    private boolean isDragging;
    public boolean open;

    public Panel(final Category category) {
        this.components = new ArrayList<>();
        this.category = category;
        this.open = true;
        this.isDragging = false;
        this.x = 5;
        this.y = 5;
        this.dragX = 0;
        this.width = 90;
        setup();
        refresh();
    }

    public void setup() {

    }

    public ArrayList<Component> getComponents() {
        return components;
    }

    public int getWidth() {
        return width;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public void setX(final int x) {
        this.x = x;
    }

    public void setY(final int y) {
        this.y = y;
    }

    public void drawScreen() {
        RenderUtils.drawRect(x, y - 1, x + width, y + 13, ColorModule.getColor(225).getRGB());
        RenderUtils.drawRect(x, y + 13, x + width, y + 14, new Color(0, 0, 0, 135).getRGB());
        FontManager.drawString(category.getLabel(), x + 3.0f, y + 2.0f, -1);

        int order = 14;

        if (open && !components.isEmpty()) {
            for (final Component component : components) {
                component.renderComponent();
                if (component instanceof ModuleButton) {
                    ModuleButton button = (ModuleButton) component;
                    if (button.open) {
                        for (Component ignored : button.getSubComponents()) {
                            order += 14;
                        }
                    }
                }
                order += 14;
            }
        }

        RenderUtils.drawRect(x, y + order, x + width, y + order + 1, new Color(0, 0, 0, 135).getRGB());
        RenderUtils.drawRect(x, y + order + 1, x + width, y + order + 15, ColorModule.getColor(225).getRGB());
    }

    public void updatePosition(final int mouseX, final int mouseY) {
        if (isDragging) {
            setX(mouseX - dragX);
            setY(mouseY - dragY);
        }
    }

    public boolean isWithinHeader(final int x, final int y) {
        return x >= this.x && x <= this.x + width && y >= this.y && y < this.y + 14;
    }

    public void setDragging(final boolean dragging) {
        this.isDragging = dragging;
    }

    public void setOpen(final boolean open) {
        this.open = open;
    }

    public boolean isOpen() {
        return open;
    }

    public void refresh() {
        int offset = 14;
        for (final Component component : components) {
            component.setOffset(offset);
            offset += component.getHeight();
        }
    }
}
