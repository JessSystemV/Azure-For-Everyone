package dev.azure.client.modules.chat;

import dev.azure.client.modules.Category;
import dev.azure.client.modules.Module;
import dev.azure.client.settings.implement.BooleanSetting;
import dev.azure.client.settings.implement.StringSetting;
import dev.azure.client.social.SocialManager;
import dev.azure.client.social.implement.Friend;
import dev.azure.event.implement.PacketEvent;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.network.play.server.SPacketChat;

public class AutoReply extends Module {
    public AutoReply() {
        super("AutoReply", "Auto Reply", "Automatically replies to messages.", Category.CHAT);
        addSettings(message, friends);
    }

    StringSetting message = new StringSetting("Message", "My messages are closed, sorry!");
    BooleanSetting friends = new BooleanSetting("Friends", false);

    @SuppressWarnings("unused")
    @EventHandler
    private final Listener<PacketEvent.Receive> receiveListener = new Listener<>(event -> {
        if (event.isPre()) {
            if (event.getPacket() instanceof SPacketChat) {
                SPacketChat packet = (SPacketChat) event.getPacket();

                if (packet.getChatComponent().getUnformattedText().contains("whispers:")) {
                    if (!friends.getValue()) {
                        for (Friend friend : SocialManager.getFriends()) {
                            if (packet.getChatComponent().getUnformattedText().contains(friend.getName())) return;
                        }
                    }

                    mc.player.sendChatMessage("/r " + message.getValue());
                }
            }
        }
    });
}
