package dev.azure.event.status;

public enum Direction {
    INCOMING,
    OUTGOING
}
