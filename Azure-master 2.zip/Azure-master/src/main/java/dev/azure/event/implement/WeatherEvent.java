package dev.azure.event.implement;

import dev.azure.event.Event;

public class WeatherEvent extends Event {
}
