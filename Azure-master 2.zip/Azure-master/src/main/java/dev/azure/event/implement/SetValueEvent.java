package dev.azure.event.implement;

import dev.azure.event.Event;

public class SetValueEvent extends Event {
    public String name;

    public SetValueEvent(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
