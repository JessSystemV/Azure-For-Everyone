package dev.azure.event.implement;

import dev.azure.event.Event;
import dev.azure.event.status.Stage;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;

public class BlockEvent extends Event {
    public BlockPos pos;
    public EnumFacing facing;

    public BlockEvent(Stage stage, final BlockPos pos, final EnumFacing facing) {
        super(stage);
        this.pos = pos;
        this.facing = facing;
    }
}