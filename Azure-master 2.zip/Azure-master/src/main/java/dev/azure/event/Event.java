package dev.azure.event;

import dev.azure.event.status.Direction;
import dev.azure.event.status.Stage;

public abstract class Event {
    public boolean cancelled = false;
    public Stage stage;
    public Direction direction;

    public Event() {
        this.stage = Stage.PRE;
        this.direction = Direction.INCOMING;
    }

    public Event(Stage stage) {
        this.stage = stage;
        this.direction = Direction.INCOMING;
    }

    public Event(Direction direction) {
        this.stage = Stage.PRE;
        this.direction = direction;
    }

    public Event(Stage stage, Direction direction) {
        this.stage = stage;
        this.direction = direction;
    }

    public Stage getStage() {
        return stage;
    }

    public boolean isCancelled() {
        return cancelled;
    }

    public void setCancelled(boolean cancelled) {
        this.cancelled = cancelled;
    }

    public boolean isPre() {
        return this.stage == Stage.PRE;
    }

    public boolean isPost() {
        return this.stage == Stage.POST;
    }
}
