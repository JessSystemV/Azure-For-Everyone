package dev.azure.event.implement;

import dev.azure.event.Event;
import dev.azure.event.status.Stage;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;

public class CollisionEvent extends Event {
    public Entity entity;

    public CollisionEvent(Entity entity) {
        super(Stage.PRE);
        this.entity = entity;
    }

    public static class Water extends Event {
        public Water() {
            super(Stage.PRE);
        }
    }

    public static class Blocks extends Event {
        public double x, y, z;

        public Blocks(double x, double y, double z) {
            super(Stage.PRE);
            this.x = x;
            this.y = y;
            this.z = z;
        }
    }

    public static class Liquid extends Event {
        private BlockPos pos;
        private AxisAlignedBB boundingBox;

        public Liquid(BlockPos pos) {
            super(Stage.PRE);
            this.pos = pos;
        }

        public void setBoundingBox(AxisAlignedBB boundingBox) {
            this.boundingBox = boundingBox;
        }

        public void setPos(BlockPos pos) {
            this.pos = pos;
        }

        public BlockPos getPos() {
            return this.pos;
        }

        public AxisAlignedBB getBoundingBox() {
            return this.boundingBox;
        }
    }
}
