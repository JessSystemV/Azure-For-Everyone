package dev.azure.event.implement;

import dev.azure.event.Event;
import net.minecraft.entity.player.EntityPlayer;

import java.util.UUID;

public class LoginEvent extends Event {
    private final UUID uuid;
    private final EntityPlayer entity;
    private final String name;

    public LoginEvent(UUID uuid, String name, EntityPlayer entity) {
        this.uuid = uuid;
        this.name = name;
        this.entity = entity;
    }

    public String getName() {
        return this.name;
    }

    public UUID getUuid() {
        return this.uuid;
    }

    public EntityPlayer getEntity() {
        return this.entity;
    }

    public static class Connect extends LoginEvent {
        public Connect(UUID uuid, String name, EntityPlayer entity) {
            super(uuid, name, entity);
        }
    }

    public static class Disconnect extends LoginEvent {
        public Disconnect(UUID uuid, String name, EntityPlayer entity) {
            super(uuid, name, entity);
        }
    }
}