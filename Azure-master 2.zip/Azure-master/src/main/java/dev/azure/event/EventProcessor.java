package dev.azure.event;

import com.google.common.base.Strings;
import com.mojang.realmsclient.gui.ChatFormatting;
import dev.azure.client.Azure;
import dev.azure.client.commands.Command;
import dev.azure.client.commands.CommandManager;
import dev.azure.client.manager.TotemManager;
import dev.azure.client.modules.Module;
import dev.azure.client.modules.ModuleManager;
import dev.azure.client.modules.chat.AutoHash;
import dev.azure.client.modules.chat.ChatColor;
import dev.azure.client.modules.chat.Highlight;
import dev.azure.client.modules.chat.Suffix;
import dev.azure.client.social.SocialManager;
import dev.azure.client.social.implement.Enemy;
import dev.azure.client.social.implement.Friend;
import dev.azure.client.utilities.chat.ChatUtils;
import dev.azure.client.utilities.entity.PositionUtils;
import dev.azure.client.utilities.entity.RotationUtils;
import dev.azure.event.implement.LoginEvent;
import dev.azure.event.implement.MotionEvent;
import dev.azure.event.implement.PacketEvent;
import dev.azure.event.status.Stage;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listenable;
import me.zero.alpine.listener.Listener;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.play.client.CPacketChatMessage;
import net.minecraft.network.play.server.SPacketChat;
import net.minecraft.network.play.server.SPacketEntityStatus;
import net.minecraft.network.play.server.SPacketPlayerListItem;
import net.minecraft.util.text.ChatType;
import net.minecraft.util.text.TextComponentString;
import net.minecraftforge.client.event.ClientChatEvent;
import net.minecraftforge.client.event.InputUpdateEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.common.network.FMLNetworkEvent;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import java.util.Arrays;
import java.util.Objects;
import java.util.UUID;

public class EventProcessor implements Listenable {
    protected static final Minecraft mc = Minecraft.getMinecraft();

    public void initialize() {
        Azure.EVENT_BUS.subscribe(this);
        MinecraftForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent event) {
        if (mc.player != null) {
            ModuleManager.getModules().stream().filter(Module::isEnabled).forEach(Module::onTick);
            TotemManager.onTick();
        }
    }

    @SubscribeEvent
    public void onRender(RenderGameOverlayEvent.Post event) {
        if (event.getType() == RenderGameOverlayEvent.ElementType.HOTBAR) {
            ModuleManager.getModules().stream().filter(Module::isEnabled).forEach(Module::onRender);
        }
    }

    @SubscribeEvent
    public void onWorldRender(RenderWorldLastEvent event) {
        if (event.isCanceled()) return;
        ModuleManager.renderWorld(event);
    }

    @SubscribeEvent
    public void onClientDisconnect(FMLNetworkEvent.ClientDisconnectionFromServerEvent event) {
        ModuleManager.getModules().stream().filter(Module::isEnabled).forEach(Module::onLogout);
        TotemManager.onLogout();
    }

    @SubscribeEvent
    public void onMouseInput(InputEvent.MouseInputEvent event) {
        if (Mouse.getEventButtonState()) {
            Azure.EVENT_BUS.post(event);
        }
    }

    @SubscribeEvent
    public void onInputUpdate(InputUpdateEvent event) {
        Azure.EVENT_BUS.post(event);
    }

    @SubscribeEvent
    public void onLivingDeath(LivingDeathEvent event) {
        Azure.EVENT_BUS.post(event);
    }

    @SubscribeEvent
    public void onChatSent(ClientChatEvent event) {
        String message = event.getMessage();

        if (message.startsWith(CommandManager.getPrefix())) {
            event.setCanceled(true);
            message = message.substring(CommandManager.getPrefix().length());

            if (message.split(" ").length > 0) {
                String name = message.split(" ")[0];
                boolean found = false;
                for (Command command : CommandManager.getCommands()) {
                    if (command.aliases.contains(name.toLowerCase()) || command.name.equalsIgnoreCase(name)) {
                        mc.ingameGUI.getChatGUI().addToSentMessages(event.getMessage());
                        command.onCommand(Arrays.copyOfRange(message.split(" "), 1, message.split(" ").length), message);
                        found = true;
                        break;
                    }
                }

                if (!found) {
                    ChatUtils.sendMessage("Could not find command.", true);
                }
            }
        }
    }

    @SubscribeEvent
    public void onKeyInput(InputEvent.KeyInputEvent event) {
        if (Keyboard.getEventKeyState()) {
            if (Keyboard.getEventKey() == Keyboard.KEY_NONE) return;

            for (Module module : ModuleManager.getModules()) {
                if (module.getBind() == Keyboard.getEventKey()) module.toggle();
            }
        }
    }

    @SuppressWarnings("unused")
    @EventHandler
    private final Listener<MotionEvent> onMotion = new Listener<>(event -> {
        if (event.getStage() == Stage.PRE) {
            RotationUtils.updateRotations();
            PositionUtils.updatePosition();
        }

        if (event.getStage() == Stage.POST) {
            RotationUtils.restoreRotations();
            PositionUtils.restorePosition();
        }
    });

    @SuppressWarnings("unused")
    @EventHandler
    private final Listener<PacketEvent.Send> sendListener = new Listener<>(event -> {
        if (event.isPre()) {
            if (event.getPacket() instanceof CPacketChatMessage) {
                String message = ((CPacketChatMessage) event.getPacket()).getMessage();

                if (message.startsWith("/")) return;
                if (message.startsWith("!")) return;
                message = ChatColor.getColor() + Suffix.getFirstModifier() + message + Suffix.getSecondModifier() + AutoHash.getHash();
                if (message.length() >= 256) {
                    message = message.substring(0, 256);
                }

                ((CPacketChatMessage) event.getPacket()).message = message;
            }
        }
    });

    @SuppressWarnings("unused")
    @EventHandler
    private final Listener<PacketEvent.Receive> receiveListener = new Listener<>(event -> {
        if (event.isPre()) {
            if (event.getPacket() instanceof SPacketEntityStatus) {
                SPacketEntityStatus packet = (SPacketEntityStatus) event.getPacket();
                if (packet != null) {
                    if (packet.getOpCode() == 35 && packet.getEntity(mc.world) instanceof EntityPlayer) {
                        EntityPlayer player = (EntityPlayer) packet.getEntity(mc.world);
                        TotemManager.onTotemPop(player);
                    }
                }
            }

            if (event.getPacket() instanceof SPacketChat) {
                SPacketChat packet = (SPacketChat) event.getPacket();
                if (packet.getType() == ChatType.GAME_INFO) return;
                String message = packet.chatComponent.getFormattedText();

                if (ModuleManager.isModuleEnabled("Highlight")) {
                    if (Highlight.self.getValue()) {
                        message = message.replace(mc.player.getName(), ChatFormatting.BLUE + mc.player.getName() + ChatFormatting.RESET);
                    }

                    if (Highlight.friends.getValue()) {
                        for (Friend friend : SocialManager.getFriends()) {
                            message = message.replace(friend.getName(), ChatFormatting.AQUA + friend.getName() + ChatFormatting.RESET);
                        }
                    }

                    if (Highlight.enemies.getValue()) {
                        for (Enemy enemy : SocialManager.getEnemies()) {
                            message = message.replace(enemy.getName(), ChatFormatting.RED + enemy.getName() + ChatFormatting.RESET);
                        }
                    }
                }

                packet.chatComponent = new TextComponentString(message);
            }

            if (event.getPacket() instanceof SPacketPlayerListItem && (mc.player != null && mc.world != null)) {
                SPacketPlayerListItem packet = (SPacketPlayerListItem) event.getPacket();
                if (!SPacketPlayerListItem.Action.ADD_PLAYER.equals(packet.getAction()) && !SPacketPlayerListItem.Action.REMOVE_PLAYER.equals(packet.getAction())) {
                    return;
                }

                packet.getEntries().stream().filter(Objects::nonNull).filter(data -> !Strings.isNullOrEmpty(data.getProfile().getName()) || data.getProfile().getId() != null).forEach(data -> {
                    UUID uuid = data.getProfile().getId();
                    switch (packet.getAction()) {
                        case ADD_PLAYER: {
                            String name = data.getProfile().getName();
                            Azure.EVENT_BUS.post(new LoginEvent.Connect(uuid, name, null));
                            break;
                        }

                        case REMOVE_PLAYER: {
                            EntityPlayer entity = mc.world.getPlayerEntityByUUID(uuid);
                            if (entity != null) {
                                String logoutName = entity.getName();
                                Azure.EVENT_BUS.post(new LoginEvent.Disconnect(uuid, logoutName, entity));
                                break;
                            }
                        }
                    }
                });
            }
        }
    });
}
