package dev.azure.event.implement;

import dev.azure.event.Event;
import dev.azure.event.status.Stage;
import net.minecraft.network.Packet;

public class PacketEvent extends Event {
    private final Packet<?> packet;

    public PacketEvent(Stage stage, Packet<?> packet) {
        super(stage);
        this.packet = packet;
    }

    public Packet<?> getPacket() {
        return packet;
    }

    public static class Send extends PacketEvent {
        public Send(Stage stage, Packet<?> packet) {
            super(stage, packet);
        }
    }

    public static class Receive extends PacketEvent {
        public Receive(Stage stage, Packet<?> packet) {
            super(stage, packet);
        }
    }
}
