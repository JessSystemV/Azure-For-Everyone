package dev.azure.event.status;

public enum Stage {
    PRE,
    BY,
    POST
}