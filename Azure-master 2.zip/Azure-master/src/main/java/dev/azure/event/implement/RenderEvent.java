package dev.azure.event.implement;

import dev.azure.event.Event;
import dev.azure.event.status.Stage;

public class RenderEvent extends Event {
    private final float partialTicks;

    public RenderEvent(float ticks) {
        super(Stage.PRE);
        partialTicks = ticks;
    }

    public float getPartialTicks() {
        return partialTicks;
    }
}
