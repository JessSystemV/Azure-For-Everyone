package dev.azure.event.implement;

import dev.azure.event.Event;
import dev.azure.event.status.Stage;

public class MotionEvent extends Event {
    public MotionEvent(Stage stage) {
        super(stage);
    }
}
