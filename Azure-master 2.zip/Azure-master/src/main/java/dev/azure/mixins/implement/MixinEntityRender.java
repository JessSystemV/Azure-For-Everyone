package dev.azure.mixins.implement;

import dev.azure.client.Azure;
import dev.azure.client.modules.ModuleManager;
import dev.azure.client.modules.render.ViewClip;
import dev.azure.event.implement.AspectEvent;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.EntityRenderer;
import org.lwjgl.util.glu.Project;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(value = EntityRenderer.class, priority = 9999)
public class MixinEntityRender {
    @Redirect(method = "setupCameraTransform", at = @At(value = "INVOKE", target = "Lorg/lwjgl/util/glu/Project;gluPerspective(FFFF)V"))
    private void setupCameraTransform(final float fovY, final float aspect, final float zNear, final float zFar) {
        final AspectEvent event = new AspectEvent((float) Minecraft.getMinecraft().displayWidth / Minecraft.getMinecraft().displayHeight);
        Azure.EVENT_BUS.post(event);
        Project.gluPerspective(fovY, event.getAspect(), zNear, zFar);
    }

    @Redirect(method = "renderWorldPass", at = @At(value = "INVOKE", target = "Lorg/lwjgl/util/glu/Project;gluPerspective(FFFF)V"))
    private void renderWorldPass(final float fovY, final float aspect, final float zNear, final float zFar) {
        final AspectEvent event = new AspectEvent((float) Minecraft.getMinecraft().displayWidth / Minecraft.getMinecraft().displayHeight);
        Azure.EVENT_BUS.post(event);
        Project.gluPerspective(fovY, event.getAspect(), zNear, zFar);
    }

    @Redirect(method = "renderCloudsCheck", at = @At(value = "INVOKE", target = "Lorg/lwjgl/util/glu/Project;gluPerspective(FFFF)V"))
    private void renderCloudsCheck(final float fovY, final float aspect, final float zNear, final float zFar) {
        final AspectEvent event = new AspectEvent((float) Minecraft.getMinecraft().displayWidth / Minecraft.getMinecraft().displayHeight);
        Azure.EVENT_BUS.post(event);
        Project.gluPerspective(fovY, event.getAspect(), zNear, zFar);
    }

    @ModifyVariable(method = "orientCamera", ordinal = 3, at = @At(value = "STORE", ordinal = 0), require = 1)
    public double cameraDistance(double range) {
        return ModuleManager.isModuleEnabled("ViewClip") && ViewClip.extend.getValue() ? ViewClip.distance.getValue() : range;
    }

    @ModifyVariable(method = "orientCamera", ordinal = 7, at = @At(value = "STORE", ordinal = 0), require = 1)
    public double orientCamera(double range) {
        return ModuleManager.isModuleEnabled("ViewClip") && ViewClip.extend.getValue() ? ViewClip.distance.getValue() : (ModuleManager.isModuleEnabled("ViewClip") && !ViewClip.extend.getValue() ? 4.0 : range);
    }
}