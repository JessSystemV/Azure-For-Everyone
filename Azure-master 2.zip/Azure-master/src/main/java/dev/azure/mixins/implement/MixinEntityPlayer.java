package dev.azure.mixins.implement;

import dev.azure.client.Azure;
import dev.azure.event.implement.CollisionEvent;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = EntityPlayer.class, priority = 9999)
public class MixinEntityPlayer {
    @Inject(method = "isPushedByWater()Z", at = @At("HEAD"), cancellable = true)
    public void isPushedByWater(CallbackInfoReturnable<Boolean> info) {
        CollisionEvent.Water event = new CollisionEvent.Water();
        Azure.EVENT_BUS.post(event);

        if (event.isCancelled()) {
            info.setReturnValue(false);
        }
    }

    @Inject(method = "applyEntityCollision", at = @At("HEAD"), cancellable = true)
    public void applyEntityCollision(Entity entity, CallbackInfo info) {
        CollisionEvent event = new CollisionEvent(entity);
        Azure.EVENT_BUS.post(event);

        if (event.isCancelled()) {
            info.cancel();
        }
    }
}
