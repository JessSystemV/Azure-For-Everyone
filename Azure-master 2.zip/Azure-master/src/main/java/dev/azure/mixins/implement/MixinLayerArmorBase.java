package dev.azure.mixins.implement;

import dev.azure.client.modules.ModuleManager;
import dev.azure.client.modules.render.EnchantColor;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.layers.LayerArmorBase;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(value = LayerArmorBase.class, priority = 9999)
public class MixinLayerArmorBase {
    @Redirect(method = "renderEnchantedGlint", at = @At(value = "INVOKE", target = "net/minecraft/client/renderer/GlStateManager.color(FFFF)V", ordinal = 1))
    private static void renderEnchantedGlint(float red, float green, float blue, float alpha) {
        GlStateManager.color(ModuleManager.isModuleEnabled("EnchantColor") ? EnchantColor.getColor().getRed() : red, ModuleManager.isModuleEnabled("EnchantColor") ? EnchantColor.getColor().getGreen() : green, ModuleManager.isModuleEnabled("EnchantColor") ? EnchantColor.getColor().getBlue() : blue, ModuleManager.isModuleEnabled("EnchantColor") ? EnchantColor.getColor().getAlpha() : alpha);
    }
}
