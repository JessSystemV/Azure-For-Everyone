package dev.azure.mixins.implement;

import dev.azure.client.Azure;
import dev.azure.client.modules.ModuleManager;
import dev.azure.client.modules.player.Reach;
import dev.azure.event.implement.BlockEvent;
import dev.azure.event.status.Stage;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = PlayerControllerMP.class, priority = 9999)
public class MixinPlayerControllerMP {
    @Inject(method = "onPlayerDamageBlock", at = @At("HEAD"), cancellable = true)
    public void onPlayerDamageBlock(BlockPos pos, EnumFacing facing, CallbackInfoReturnable<Boolean> info) {
        final BlockEvent event = new BlockEvent(Stage.POST, pos, facing);
        Azure.EVENT_BUS.post(event);
        if (event.isCancelled()) {
            info.setReturnValue(false);
        }
    }

    @Inject(method = "clickBlock", at = @At("HEAD"), cancellable = true)
    private void clickBlock(final BlockPos pos, final EnumFacing facing, final CallbackInfoReturnable<Boolean> info) {
        final BlockEvent event = new BlockEvent(Stage.PRE, pos, facing);
        Azure.EVENT_BUS.post(event);
        if (event.isCancelled()) {
            info.setReturnValue(false);
        }
    }

    @Inject(method = "getBlockReachDistance", at = @At("RETURN"), cancellable = true)
    private void getBlockReachDistance(CallbackInfoReturnable<Float> distance) {
        if (ModuleManager.isModuleEnabled("Reach")) {
            float range = distance.getReturnValue();
            distance.setReturnValue((float) (range + Reach.add.getValue()));
        }
    }
}
