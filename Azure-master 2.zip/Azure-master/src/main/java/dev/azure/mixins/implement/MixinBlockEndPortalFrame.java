package dev.azure.mixins.implement;

import dev.azure.client.modules.ModuleManager;
import dev.azure.client.modules.movement.NoSlow;
import net.minecraft.block.BlockEndPortalFrame;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = BlockEndPortalFrame.class, priority = 9999)
public class MixinBlockEndPortalFrame {
    @Inject(method = "getBoundingBox", at = @At("HEAD"), cancellable = true)
    public void getBoundingBox(IBlockState state, IBlockAccess source, BlockPos pos, CallbackInfoReturnable<AxisAlignedBB> info) {
        if (ModuleManager.isModuleEnabled("NoSlow") && NoSlow.endPortals.getValue()) {
            info.setReturnValue(new AxisAlignedBB(0.0, 0.0, 0.0, 1.0, 1.0, 1.0));
        }
    }
}
