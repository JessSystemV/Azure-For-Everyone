package dev.azure.mixins.implement;

import dev.azure.client.Azure;
import dev.azure.client.modules.ModuleManager;
import dev.azure.client.modules.player.PortalTweaks;
import dev.azure.client.modules.player.Swing;
import dev.azure.event.implement.CollisionEvent;
import dev.azure.event.status.Stage;
import dev.azure.event.implement.MotionEvent;
import dev.azure.event.implement.MoveEvent;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.entity.MoverType;
import net.minecraft.network.play.client.CPacketAnimation;
import net.minecraft.util.EnumHand;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = EntityPlayerSP.class, priority = 9999)
public class MixinEntityPlayerSP extends AbstractClientPlayer {
    public MixinEntityPlayerSP() {
        super(null, null);
    }

    @Inject(method = "swingArm", at = @At("HEAD"), cancellable = true)
    public void swingArm(CallbackInfo info) {
        if (ModuleManager.isModuleEnabled("Swing")) {
            info.cancel();
            if (Swing.hand.getValue().equalsIgnoreCase("Offhand")) {
                if (!Swing.silent.getValue()) super.swingArm(EnumHand.OFF_HAND);
                Minecraft.getMinecraft().player.connection.sendPacket(new CPacketAnimation(EnumHand.OFF_HAND));
            } else {
                if (!Swing.silent.getValue()) super.swingArm(EnumHand.MAIN_HAND);
                Minecraft.getMinecraft().player.connection.sendPacket(new CPacketAnimation(EnumHand.MAIN_HAND));
            }
        }
    }

    @Inject(method = "onUpdateWalkingPlayer", at = @At("HEAD"), cancellable = true)
    private void onUpdateWalkingPlayer(CallbackInfo info) {
        MotionEvent event = new MotionEvent(Stage.PRE);
        Azure.EVENT_BUS.post(event);
        if (event.isCancelled()) {
            info.cancel();
        }
    }

    @Inject(method = "onUpdateWalkingPlayer", at = @At("RETURN"), cancellable = true)
    private void onPostUpdateWalkingPlayer(CallbackInfo info) {
        MotionEvent event = new MotionEvent(Stage.POST);
        Azure.EVENT_BUS.post(event);
        if (event.isCancelled()) {
            info.cancel();
        }
    }

    @Inject(method = "move", at = @At("HEAD"), cancellable = true)
    private void move(final MoverType type, final double x, final double y, final double z, final CallbackInfo info) {
        final MoveEvent event = new MoveEvent(Stage.PRE, type, x, y, z);
        Azure.EVENT_BUS.post(event);
        if (event.isCancelled()) {
            super.move(type, event.getX(), event.getY(), event.getZ());
            info.cancel();
        }
    }

    @Inject(method = "move", at = @At("RETURN"), cancellable = true)
    private void moveReturn(final MoverType type, final double x, final double y, final double z, final CallbackInfo info) {
        final MoveEvent event = new MoveEvent(Stage.POST, type, x, y, z);
        Azure.EVENT_BUS.post(event);
    }

    @Redirect(method = "onLivingUpdate", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/entity/EntityPlayerSP;closeScreen()V"))
    public void closeScreen(EntityPlayerSP entityPlayerSP) {
        if (!ModuleManager.isModuleEnabled("PortalTweaks") || !PortalTweaks.chat.getValue()) {
            entityPlayerSP.closeScreen();
        }
    }

    @Redirect(method = "onLivingUpdate", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/Minecraft;displayGuiScreen(Lnet/minecraft/client/gui/GuiScreen;)V"))
    public void displayGuiScreen(Minecraft mc, GuiScreen screen) {
        if (!ModuleManager.isModuleEnabled("PortalTweaks") || !PortalTweaks.chat.getValue()) {
            mc.displayGuiScreen(screen);
        }
    }

    @Inject(method = "pushOutOfBlocks(DDD)Z", at = @At("HEAD"), cancellable = true)
    public void pushOutOfBlocks(double x, double y, double z, CallbackInfoReturnable<Boolean> info) {
        CollisionEvent.Blocks event = new CollisionEvent.Blocks(x, y, z);
        Azure.EVENT_BUS.post(event);

        if (event.isCancelled()) {
            info.setReturnValue(false);
        }
    }
}
