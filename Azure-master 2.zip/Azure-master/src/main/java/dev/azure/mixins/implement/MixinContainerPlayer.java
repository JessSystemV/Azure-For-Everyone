package dev.azure.mixins.implement;

import dev.azure.client.modules.ModuleManager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.ContainerPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = ContainerPlayer.class, priority = 9999)
public class MixinContainerPlayer {
    @Inject(method = "onContainerClosed", at = @At("HEAD"), cancellable = true)
    public void onContainerClosed(final EntityPlayer entity, final CallbackInfo info) {
        if (ModuleManager.isModuleEnabled("XCarry")) {
            info.cancel();
        }
    }
}
