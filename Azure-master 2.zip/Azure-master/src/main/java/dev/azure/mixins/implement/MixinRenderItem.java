package dev.azure.mixins.implement;

import dev.azure.client.modules.ModuleManager;
import dev.azure.client.modules.render.EnchantColor;
import dev.azure.client.modules.render.ViewModel;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderItem;
import net.minecraft.client.renderer.block.model.IBakedModel;
import net.minecraft.client.renderer.block.model.ItemCameraTransforms;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHand;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.awt.*;

@Mixin(value = RenderItem.class, priority = 9999)
public class MixinRenderItem {
    @Shadow
    private void renderModel(IBakedModel model, int color, ItemStack stack) {
    }

    @ModifyArg(method = "renderEffect", at = @At(value = "INVOKE", target = "net/minecraft/client/renderer/RenderItem.renderModel(Lnet/minecraft/client/renderer/block/model/IBakedModel;I)V"), index = 1)
    private int renderEffect(int oldValue) {
        return ModuleManager.isModuleEnabled("EnchantColor") ? EnchantColor.getColor().getRGB() : oldValue;
    }

    @Inject(method = "renderItemModel", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/RenderItem;renderItem(Lnet/minecraft/item/ItemStack;Lnet/minecraft/client/renderer/block/model/IBakedModel;)V", shift = At.Shift.BEFORE))
    private void renderItemModel(ItemStack stack, IBakedModel model, ItemCameraTransforms.TransformType transform, boolean leftHanded, CallbackInfo info) {
        if (ModuleManager.isModuleEnabled("ViewModel") && ViewModel.isRight(leftHanded)) {
            if (!ViewModel.eatPause.getValue() || !Minecraft.getMinecraft().player.isHandActive() || isHandGood(Minecraft.getMinecraft().player.getActiveHand(), leftHanded)) {
                GlStateManager.scale(ViewModel.sizeX.getValue(), ViewModel.sizeY.getValue(), ViewModel.sizeZ.getValue());
                GlStateManager.rotate((float) (ViewModel.rotationX.getValue() * 360), 1.0f, 0.0f, 0.0f);
                GlStateManager.rotate((float) (ViewModel.rotationY.getValue() * 360), 0.0f, 1.0f, 0.0f);
                GlStateManager.rotate((float) (ViewModel.rotationZ.getValue() * 360), 0.0f, 0.0f, 1.0f);
                GlStateManager.translate(ViewModel.posX.getValue(), ViewModel.posY.getValue(), ViewModel.posZ.getValue());
            }
        }
    }

    @Redirect(method = "renderItem(Lnet/minecraft/item/ItemStack;Lnet/minecraft/client/renderer/block/model/IBakedModel;)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/GlStateManager;color(FFFF)V"))
    private void renderItem(float colorRed, float colorGreen, float colorBlue, float colorAlpha) {
        if (ModuleManager.isModuleEnabled("ViewModel")) {
            GlStateManager.color(colorRed, colorGreen, colorBlue, ViewModel.alpha.getValue() / 255.0f);
        } else {
            GlStateManager.color(colorRed, colorGreen, colorBlue, colorAlpha);
        }
    }

    @Redirect(method = "renderItem(Lnet/minecraft/item/ItemStack;Lnet/minecraft/client/renderer/block/model/IBakedModel;)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/RenderItem;renderModel(Lnet/minecraft/client/renderer/block/model/IBakedModel;Lnet/minecraft/item/ItemStack;)V"))
    private void renderModelColor(RenderItem renderItem, IBakedModel model, ItemStack stack) {
        if (ModuleManager.isModuleEnabled("ViewModel")) {
            renderModel(model, new Color(1.0f, 1.0f, 1.0f, ViewModel.alpha.getValue() / 255.0f).getRGB(), stack);
        } else {
            renderModel(model, -1, stack);
        }
    }

    private boolean isHandGood(EnumHand activeHand, boolean leftHandedRenderHand) {
        switch (activeHand) {
            case MAIN_HAND:
                return leftHandedRenderHand;
            case OFF_HAND:
                return !leftHandedRenderHand;
        }
        return false;
    }
}
